import os
from datetime import datetime
import tkinter as tk
from tkinter import filedialog, messagebox

from openpyxl import load_workbook
from openpyxl.styles import PatternFill


# =====================================================
# CREATE HIDDEN TKINTER WINDOW
# =====================================================

root = tk.Tk()
root.withdraw()

# =====================================================
# SELECT PAYSLIP FOLDER
# =====================================================

messagebox.showinfo(
    "Browse Folder",
    "Please Select Leaver Payslip Folder"
)

payslip_folder = filedialog.askdirectory(
    title="Select Leaver Payslip Folder"
)

if not payslip_folder:
    raise SystemExit

# =====================================================
# SELECT CALCULATION FILE
# =====================================================

messagebox.showinfo(
    "Browse File",
    "Please Select Leavers Calculation Workbook"
)

calc_file = filedialog.askopenfilename(
    title="Select Leavers Calculation Workbook",
    filetypes=[("Excel Files", "*.xlsx *.xlsm")]
)

if not calc_file:
    raise SystemExit

# =====================================================
# SELECT OUTPUT STATUS FILE
# =====================================================

messagebox.showinfo(
    "Browse File",
    "Please Select Output Status File"
)

output_file = filedialog.askopenfilename(
    title="Select Output Status File",
    filetypes=[("Excel Files", "*.xlsx *.xlsm")]
)

if not output_file:
    raise SystemExit

# =====================================================
# OPEN WORKBOOKS
# =====================================================

calc_wb = load_workbook(calc_file, data_only=True)

output_wb = load_workbook(output_file)
output_ws = output_wb.active

# =====================================================
# GREY FILL
# =====================================================

grey_fill = PatternFill(
    fill_type="solid",
    start_color="D9D9D9",
    end_color="D9D9D9"
)

# =====================================================
# SHEET / CELL MAPPING
# =====================================================

sheet_mapping = {
    "Leaver Form": "D6",
    "Calculations": "I6",
    "T&A": "A3",
    "ExcelPaySlip": "B3"
}

# =====================================================
# FIND LAST USED ROW IN COLUMN A
# =====================================================

last_row = 1

for row in range(output_ws.max_row, 0, -1):
    if output_ws.cell(row, 1).value not in [None, ""]:
        last_row = row
        break

next_row = last_row + 1

# =====================================================
# PROCESS ALL PDF FILES
# =====================================================

for pdf_file in os.listdir(payslip_folder):

    if not pdf_file.lower().endswith(".pdf"):
        continue

    employee_id = os.path.splitext(pdf_file)[0].strip()

    for sheet_name, cell_ref in sheet_mapping.items():

        process_start = datetime.now()

        status = "Incomplete"
        reason = "Emp ID mismatch"

        try:

            if sheet_name not in calc_wb.sheetnames:

                status = "Incomplete"
                reason = "Sheet Missing"

            else:

                ws = calc_wb[sheet_name]

                cell_value = ws[cell_ref].value

                excel_emp_id = ""

                if cell_value is not None:
                    excel_emp_id = str(cell_value).strip()

                    if excel_emp_id.endswith(".0"):
                        excel_emp_id = excel_emp_id[:-2]

                pdf_emp_id = employee_id

                if pdf_emp_id == excel_emp_id:

                    status = "Completed"
                    reason = ""

        except Exception as e:

            status = "Incomplete"
            reason = str(e)

        process_end = datetime.now()

        # =================================================
        # WRITE RESULTS
        # =================================================

        output_ws.cell(next_row, 1).value = employee_id
        output_ws.cell(next_row, 2).value = sheet_name
        output_ws.cell(next_row, 3).value = process_start.strftime("%d/%m/%Y")
        output_ws.cell(next_row, 4).value = process_start.strftime("%H:%M:%S")
        output_ws.cell(next_row, 5).value = process_end.strftime("%H:%M:%S")
        output_ws.cell(next_row, 6).value = status
        output_ws.cell(next_row, 7).value = reason

        # Grey highlight for mismatch

        if reason == "Emp ID mismatch":

            output_ws.cell(next_row, 7).fill = grey_fill

        next_row += 1

# =====================================================
# SAVE & CLOSE
# =====================================================

output_wb.save(output_file)

output_wb.close()
calc_wb.close()

messagebox.showinfo(
    "Completed",
    "Output Status File Updated Successfully."
)