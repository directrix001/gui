import { useEffect, useState } from 'react'
import {
  ResponsiveContainer, ComposedChart, Line, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, Legend, ReferenceLine,
} from 'recharts'
import { api } from '../api/client.js'
import { COLORS, Loading, ErrorBox, usd, tooltipStyle } from '../components/ui.jsx'

const STATUS = {
  linked: { cls: 'ok', label: 'Linked' },
  pending_validation: { cls: 'warn', label: 'Pending validation' },
  failed: { cls: 'err', label: 'Failed' },
  pass: { cls: 'ok', label: 'Pass' },
  warning: { cls: 'warn', label: 'Warning' },
  fail: { cls: 'err', label: 'Fail' },
}

const VARIANCE_FILL = 'rgba(180, 83, 9, 0.85)'   // deep amber

export default function Validation() {
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)
  const [cmpRange, setCmpRange] = useState(60)
  const [cmp, setCmp] = useState(null)

  useEffect(() => { api.validation().then(setData).catch(setError) }, [])

  useEffect(() => {
    const q = cmpRange ? `?months=${cmpRange}` : ''
    fetch(`/api/comparison${q}`).then(r => r.json()).then(setCmp).catch(() => {})
  }, [cmpRange])

  if (error) return <div className="page"><ErrorBox error={error} /></div>
  if (!data) return <div className="page"><Loading label="Checking sources…" /></div>

  const cmpData = cmp
    ? cmp.labels.map((m, i) => ({
        month: m,
        'FRED (PALUMUSDM)': cmp.fred[i],
        'LME 3-month': cmp.lme_3m[i],
        'Variance %': cmp.variance_pct[i],
      }))
    : []

  return (
    <div className="page">
      {/* ── two-source cross-check: CSV → SQLite → API → chart ── */}
      <div className="card">
        <div className="card-head">
          <h3>Source Cross-Check — FRED vs LME 3-month</h3>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
            {cmp && (
              <span className="badge info" title="Data pipeline currently serving this chart">
                {cmp.source_mode === 'sql' ? 'SQL pipeline · API-ready' : cmp.source_mode}
              </span>
            )}
            <div className="seg" role="tablist" aria-label="Comparison range">
              {[[24, '24M'], [60, '5Y'], [null, 'All']].map(([m, label]) => (
                <button key={label} className={cmpRange === m ? 'active' : ''}
                  onClick={() => setCmpRange(m)}>{label}</button>
              ))}
            </div>
          </div>
        </div>
        <div className="card-body">
          {!cmp ? (
            <div className="loading" style={{ padding: 40 }}>
              <div className="spinner" />Loading comparison…
            </div>
          ) : (
            <>
              <div style={{ display: 'flex', gap: 22, flexWrap: 'wrap', marginBottom: 10 }}>
                <div><span style={{ fontSize: 11.5, color: COLORS.slate }}>Latest FRED</span>
                  <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontWeight: 700, fontSize: 18 }}>
                    {usd(cmp.stats.latest_fred)}</div></div>
                <div><span style={{ fontSize: 11.5, color: COLORS.slate }}>Latest LME 3-month</span>
                  <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontWeight: 700, fontSize: 18 }}>
                    {usd(cmp.stats.latest_lme_3m)}</div></div>
                <div><span style={{ fontSize: 11.5, color: COLORS.slate }}>Latest variance</span>
                  <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontWeight: 700, fontSize: 18 }}>
                    {cmp.stats.latest_variance_pct != null ? `${cmp.stats.latest_variance_pct}%` : '—'}</div></div>
                <div><span style={{ fontSize: 11.5, color: COLORS.slate }}>Avg |variance| ({cmp.stats.rows} months)</span>
                  <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontWeight: 700, fontSize: 18 }}>
                    {cmp.stats.avg_abs_variance_pct}%</div></div>
              </div>
              <div style={{ height: 330 }}>
                <ResponsiveContainer>
                  <ComposedChart data={cmpData}>
                    <CartesianGrid stroke={COLORS.grid} vertical={false} />
                    <XAxis dataKey="month" tick={{ fontSize: 11 }} minTickGap={34} />
                    <YAxis yAxisId="price" tick={{ fontSize: 11 }} tickFormatter={usd}
                      width={64} domain={['auto', 'auto']} />
                    <YAxis yAxisId="pct" orientation="right" tick={{ fontSize: 11 }}
                      tickFormatter={(v) => `${v}%`} width={46} />
                    <Tooltip {...tooltipStyle}
                      formatter={(v, name) =>
                        name === 'Variance %'
                          ? [v != null ? `${v}%` : '—', name]
                          : [usd(v), name]} />
                    <Legend wrapperStyle={{ fontSize: 12 }} />
                    <ReferenceLine yAxisId="pct" y={0} stroke={COLORS.slate} strokeDasharray="3 3" />
                    <Bar yAxisId="pct" dataKey="Variance %" fill={VARIANCE_FILL} />
                    <Line yAxisId="price" dataKey="FRED (PALUMUSDM)" stroke={COLORS.coral}
                      strokeWidth={2} dot={false} connectNulls={false} />
                    <Line yAxisId="price" dataKey="LME 3-month" stroke={COLORS.navy}
                      strokeWidth={2} dot={false} connectNulls={false} />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
              <p style={{ marginTop: 12, fontSize: 12.5, color: COLORS.slate, lineHeight: 1.55 }}>
                Monthly aluminum price from two independent sources with variance %
                ((FRED − LME) ÷ LME × 100) on the right axis. Ingested into SQLite and served
                from SQL; set <span className="mono">PRICE_SOURCE_MODE=api</span> and{' '}
                <span className="mono">PRICE_API_URL</span> to switch to a live feed with no code
                changes (automatic SQL fallback). Gaps are months where one source has no
                published value.
              </p>
            </>
          )}
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <h3>Source links</h3>
          <span className="hint">Last checked {data.last_checked}</span>
        </div>
        <div className="card-body" style={{ overflowX: 'auto' }}>
          <table>
            <thead>
              <tr><th>Source</th><th>Feeds</th><th>URL</th><th>Status</th><th>Latency</th></tr>
            </thead>
            <tbody>
              {data.sources.map(s => (
                <tr key={s.name}>
                  <td style={{ fontWeight: 600 }}>{s.name}</td>
                  <td>{s.field}</td>
                  <td className="mono" style={{ color: COLORS.slate, maxWidth: 280, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{s.url}</td>
                  <td><span className={`badge ${STATUS[s.status].cls}`}>{STATUS[s.status].label}</span></td>
                  <td className="mono">{s.latency_ms != null ? `${s.latency_ms} ms` : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <h3>Validation rules</h3>
          <span className="hint">Automated checks run on every refresh</span>
        </div>
        <div className="card-body" style={{ overflowX: 'auto' }}>
          <table>
            <thead><tr><th>Rule</th><th>Status</th><th>Detail</th></tr></thead>
            <tbody>
              {data.rules.map(r => (
                <tr key={r.rule}>
                  <td style={{ fontWeight: 500 }}>{r.rule}</td>
                  <td><span className={`badge ${STATUS[r.status].cls}`}>{STATUS[r.status].label}</span></td>
                  <td style={{ color: COLORS.slate }}>{r.detail || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
