import { useEffect, useState } from 'react'
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
} from 'recharts'
import { COLORS, tooltipStyle, Delta } from '../components/ui.jsx'

const SERIES_COLORS = {
  lme: COLORS.coral, midwest_premium: '#B45309', gas: '#0E7490', labour: '#5B21B6',
}

export default function Dashboard() {
  const [data, setData] = useState(null)
  const [err, setErr] = useState(null)

  useEffect(() => {
    fetch('/api/real/drivers').then(r => r.json()).then(setData).catch(e => setErr(e.message))
  }, [])

  if (err) return <div className="loading">⚠️ {err}</div>
  if (!data) return <div className="loading">Loading real driver data…</div>

  const drivers = data.drivers

  return (
    <div className="page">
      <section>
        <div className="section-label">01 · Pricing formula</div>
        <div className="equation-hero">
          <div className="eq-title">New Price Computation</div>
          <div className="eq-formula">
            P<sub>New</sub> = P<sub>Current</sub> + [(AMS<sub>Q</sub> − AMS<sub>Q−1</sub>) × PWt]
            + (PPI<sub>Factor</sub> × P<sub>Current</sub>)
          </div>
          <div className="eq-sub">
            AMS = (MC × DF<sub>c</sub>) + CNG&nbsp;&nbsp;·&nbsp;&nbsp;
            MC = LME + Midwest Premium&nbsp;&nbsp;·&nbsp;&nbsp;
            PPI<sub>Factor</sub> = (PPI<sub>Q</sub> − PPI<sub>Q−1</sub>) / PPI<sub>Q−1</sub>
          </div>
          <div className="eq-note">
            Try it with your own inputs in the <a href="/calculator">Price Calculator</a> —
            single entry or Excel batch.
          </div>
        </div>
        <div className="kpi-grid" style={{ marginTop: 16 }}>
          {drivers.map(d => (
            <div className="kpi-card" key={d.key}>
              <div className="kpi-label">{d.name} ({d.unit})</div>
              <div className="kpi-value">
                {d.latest ? d.latest.value.toLocaleString('en-US', { maximumFractionDigits: 4 }) : '—'}
              </div>
              <div className="kpi-foot">
                <Delta value={d.mom_pct} /> <span className="hint">MoM · {d.latest?.month || '—'} · {d.db}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <div className="section-label">02 · Input drivers — real data</div>
        <div className="grid-2">
          {drivers.map(d => (
            <div className="card" key={d.key}>
              <div className="card-head">
                <h3>{d.name} <span className="hint">({d.unit})</span></h3>
                <span className="badge ok">real · {d.rows} months</span>
              </div>
              <div className="card-body" style={{ height: 230 }}>
                <ResponsiveContainer>
                  <LineChart data={d.series}>
                    <CartesianGrid stroke={COLORS.grid} vertical={false} />
                    <XAxis dataKey="month" tick={{ fontSize: 10 }} minTickGap={26} />
                    <YAxis tick={{ fontSize: 10.5 }} width={52}
                      domain={['auto', 'auto']}
                      tickFormatter={v => v.toLocaleString('en-US', { maximumFractionDigits: 2 })} />
                    <Tooltip {...tooltipStyle}
                      formatter={v => [v.toLocaleString('en-US', { maximumFractionDigits: 4 }), d.name]} />
                    <Line dataKey="value" stroke={SERIES_COLORS[d.key] || COLORS.coral}
                      strokeWidth={2.2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div className="card-foot hint" style={{ padding: '0 18px 14px' }}>
                {d.from} → {d.to} · month is PRIMARY KEY in {d.db} · series includes
                forward values published by the source sites
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}
