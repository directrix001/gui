import { useEffect, useRef, useState } from 'react'

const FACTOR_META = {
  lme: { label: 'LME Price', unit: '$/lb' },
  midwest_premium: { label: 'Midwest Premium', unit: '$/lb' },
  gas: { label: 'CNG Cost', unit: '$/lb' },
  labour: { label: 'PPI Index', unit: 'index' },
}

function FactorCard({ d, onDone }) {
  const [month, setMonth] = useState('')
  const [value, setValue] = useState('')
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState(null)
  const fileRef = useRef(null)

  async function saveManual() {
    if (!month || value === '') return
    setBusy(true); setMsg(null)
    try {
      const r = await fetch(`/api/real/manual/${d.key}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ month, value: parseFloat(value) }),
      })
      const j = await r.json()
      setMsg({ ok: r.ok, text: j.message || j.detail })
      if (r.ok) { setMonth(''); setValue(''); onDone() }
    } catch (e) { setMsg({ ok: false, text: e.message }) }
    finally { setBusy(false) }
  }

  async function uploadFile(f) {
    if (!f) return
    setBusy(true); setMsg(null)
    const fd = new FormData()
    fd.append('file', f)
    try {
      const r = await fetch(`/api/real/upload/${d.key}`, { method: 'POST', body: fd })
      const j = await r.json()
      setMsg({ ok: r.ok, text: j.message || j.detail })
      if (r.ok) onDone()
    } catch (e) { setMsg({ ok: false, text: e.message }) }
    finally { setBusy(false); if (fileRef.current) fileRef.current.value = '' }
  }

  const meta = FACTOR_META[d.key] || { label: d.name, unit: d.unit }
  return (
    <div className="card">
      <div className="card-head">
        <h3>{meta.label} <span className="hint">({meta.unit})</span></h3>
        <span className="badge info">{d.db}</span>
      </div>
      <div className="card-body">
        <div className="hint" style={{ marginBottom: 10 }}>
          {d.rows} rows · {d.from || '—'} → {d.to || '—'} · month = PRIMARY KEY
          (re-adding a month overwrites it)
        </div>
        <div className="ingest-row">
          <input type="month" value={month} onChange={e => setMonth(e.target.value)} />
          <input type="number" step="any" placeholder={`value (${meta.unit})`}
            value={value} onChange={e => setValue(e.target.value)} />
          <button className="btn" onClick={saveManual}
            disabled={busy || !month || value === ''}>Add</button>
        </div>
        <div className="ingest-row" style={{ marginTop: 8 }}>
          <input ref={fileRef} type="file" accept=".csv,.txt,.tsv,.xlsx,.xls"
            onChange={e => uploadFile(e.target.files?.[0])} disabled={busy} />
        </div>
        <div className="hint" style={{ marginTop: 6 }}>
          File needs 2 columns: month (YYYY-MM) + value — Excel/CSV/TSV, $ signs OK.
        </div>
        {msg && (
          <div className={`calc-alert ${msg.ok ? 'ok' : 'err'}`} style={{ marginTop: 8 }}>
            {msg.text}
          </div>
        )}
      </div>
    </div>
  )
}

export default function DataManager() {
  const [drivers, setDrivers] = useState(null)

  function load() {
    fetch('/api/real/drivers').then(r => r.json())
      .then(j => setDrivers(j.drivers)).catch(() => {})
  }
  useEffect(() => { load() }, [])

  if (!drivers) return <div className="loading">Loading factor databases…</div>

  return (
    <div className="page">
      <section>
        <div className="section-label">Factor databases — real data ingestion</div>
        <div className="hint" style={{ marginBottom: 12 }}>
          Each driver lives in its own SQLite database with <b>month as PRIMARY KEY</b>.
          Add a single month manually, or upload an Excel/CSV file per factor — rows are
          pushed straight into the matching database and the dashboard, chatbot and
          calculator see them immediately.
        </div>
        <div className="grid-2">
          {drivers.map(d => <FactorCard key={d.key} d={d} onDone={load} />)}
        </div>
      </section>
    </div>
  )
}
