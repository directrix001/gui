"""
Aluminum Price Intelligence — FastAPI backend
Genpact | Metals Analytics

Serves mock (deterministic) data for:
  • LME Aluminum base price + US Midwest Premium  →  All-in price = LME + MWP
  • 12-month monthly ML forecast with confidence bands
  • 4 input drivers (historical + forecast)
  • Feature importance, model backtest metrics
  • Data-source validation (link health checks)
  • CSV/XLSX upload endpoint (replace mock data with real data later)
"""
from datetime import date
from io import BytesIO
from typing import Optional

import numpy as np
from dateutil.relativedelta import relativedelta
from fastapi import FastAPI, File, UploadFile, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(
    title="Aluminum Price Intelligence API",
    version="1.0.0",
    description="Backend for the Genpact aluminum price forecasting platform (LME + Midwest Premium).",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

RNG = np.random.default_rng(42)
TODAY = date.today().replace(day=1)
HIST_MONTHS = 36
FCST_MONTHS = 12

# ---------------------------------------------------------------- data build
def _month_labels(start: date, n: int) -> list[str]:
    return [(start + relativedelta(months=i)).strftime("%Y-%m") for i in range(n)]

def _series(base: float, drift: float, vol: float, n: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    shocks = rng.normal(0, vol, n).cumsum()
    trend = np.linspace(0, drift, n)
    season = 0.02 * base * np.sin(np.linspace(0, 3 * np.pi, n))
    return base + trend + shocks + season

HIST_START = TODAY - relativedelta(months=HIST_MONTHS - 1)
HIST_LABELS = _month_labels(HIST_START, HIST_MONTHS)
FCST_LABELS = _month_labels(TODAY + relativedelta(months=1), FCST_MONTHS)

import os

LME_HIST = _series(2350, 280, 45, HIST_MONTHS, 1)          # USD / tonne
MWP_HIST = _series(420, 160, 18, HIST_MONTHS, 2)           # USD / tonne (duty-paid premium)

# ---- extended pricing components (all USD/t contributions) -----------------
# Aluminum cost = LME + Midwest Premium + Gas Coefficient + Labour Index
#                 − Macro-economic factor (supply − demand) + External factor
GAS_HIST   = _series(95, 28, 6, HIST_MONTHS, 31)     # gas/energy pass-through coefficient
LABOUR_HIST = _series(150, 20, 4, HIST_MONTHS, 32)   # labour cost index contribution
MACRO_HIST = _series(70, 15, 9, HIST_MONTHS, 33)     # supply–demand balance (surplus lowers price)
EXT_HIST   = _series(48, 12, 7, HIST_MONTHS, 34)     # external factor (tariffs, freight, geopolitics)

ALLIN_HIST = LME_HIST + MWP_HIST + GAS_HIST + LABOUR_HIST - MACRO_HIST + EXT_HIST

# Input drivers (historical only → each forecast first, then price is predicted)
DRIVERS = {
    "gas_coeff":    {"name": "Gas Coefficient (USD/t)",          "series": GAS_HIST,
                     "effect": "+", "desc": "Energy pass-through into smelting cost"},
    "labour_index": {"name": "Labour Index (USD/t)",             "series": LABOUR_HIST,
                     "effect": "+", "desc": "Labour cost contribution"},
    "macro_sd":     {"name": "Macro Factor — Supply − Demand",   "series": MACRO_HIST,
                     "effect": "−", "desc": "Market balance; surplus pulls price down"},
    "external":     {"name": "External Factor (USD/t)",          "series": EXT_HIST,
                     "effect": "+", "desc": "Tariffs, freight, geopolitics"},
}

def _forecast(hist: np.ndarray, n: int, seed: int, widen: float = 1.0):
    rng = np.random.default_rng(seed)
    slope = (hist[-1] - hist[-9]) / 9.0
    last = hist[-1]
    mean = last + slope * np.arange(1, n + 1) * 0.85 + rng.normal(0, np.std(hist) * 0.05, n).cumsum()
    band = np.std(np.diff(hist)) * np.sqrt(np.arange(1, n + 1)) * 1.28 * widen
    return mean, mean - band, mean + band

LME_F, LME_LO, LME_HI = _forecast(LME_HIST, FCST_MONTHS, 11)
MWP_F, MWP_LO, MWP_HI = _forecast(MWP_HIST, FCST_MONTHS, 12)
GAS_F, GAS_LO, GAS_HI = _forecast(GAS_HIST, FCST_MONTHS, 13)
LAB_F, LAB_LO, LAB_HI = _forecast(LABOUR_HIST, FCST_MONTHS, 14)
MAC_F, MAC_LO, MAC_HI = _forecast(MACRO_HIST, FCST_MONTHS, 15)
EXT_F, EXT_LO, EXT_HI = _forecast(EXT_HIST, FCST_MONTHS, 16)

ALLIN_F = LME_F + MWP_F + GAS_F + LAB_F - MAC_F + EXT_F
# macro subtracts, so its band flips when combining bounds
ALLIN_LO = LME_LO + MWP_LO + GAS_LO + LAB_LO - MAC_HI + EXT_LO
ALLIN_HI = LME_HI + MWP_HI + GAS_HI + LAB_HI - MAC_LO + EXT_HI

def _round(a): return [round(float(x), 2) for x in a]

# ------------------------------------------------------------------- routes
@app.get("/api/summary")
def summary():
    def chg(s): return round(float((s[-1] - s[-2]) / s[-2] * 100), 2)
    return {
        "as_of": HIST_LABELS[-1],
        "lme": {"value": round(float(LME_HIST[-1]), 2), "mom_pct": chg(LME_HIST)},
        "midwest_premium": {"value": round(float(MWP_HIST[-1]), 2), "mom_pct": chg(MWP_HIST)},
        "gas_coeff": {"value": round(float(GAS_HIST[-1]), 2), "mom_pct": chg(GAS_HIST)},
        "labour_index": {"value": round(float(LABOUR_HIST[-1]), 2), "mom_pct": chg(LABOUR_HIST)},
        "macro_sd": {"value": round(float(MACRO_HIST[-1]), 2), "mom_pct": chg(MACRO_HIST)},
        "external": {"value": round(float(EXT_HIST[-1]), 2), "mom_pct": chg(EXT_HIST)},
        "all_in": {"value": round(float(ALLIN_HIST[-1]), 2), "mom_pct": chg(ALLIN_HIST)},
        "formula": "All-in = LME + Midwest Premium + Gas Coefficient + Labour Index − Macro (Supply−Demand) + External Factor",
        "forecast_12m_avg": round(float(np.mean(ALLIN_F)), 2),
        "forecast_peak": {"month": FCST_LABELS[int(np.argmax(ALLIN_F))],
                          "value": round(float(np.max(ALLIN_F)), 2)},
        "model": {"name": "GBM-Ensemble v2.3", "mape_pct": 3.7, "last_trained": str(TODAY)},
    }

@app.get("/api/history")
def history(months: int = Query(36, ge=6, le=HIST_MONTHS)):
    s = HIST_MONTHS - months
    return {
        "labels": HIST_LABELS[s:],
        "lme": _round(LME_HIST[s:]),
        "midwest_premium": _round(MWP_HIST[s:]),
        "all_in": _round(ALLIN_HIST[s:]),
    }

@app.get("/api/forecast")
def forecast(component: str = Query("all_in", pattern="^(all_in|lme|midwest_premium)$")):
    comp = {
        "all_in": (ALLIN_F, ALLIN_LO, ALLIN_HI, ALLIN_HIST),
        "lme": (LME_F, LME_LO, LME_HI, LME_HIST),
        "midwest_premium": (MWP_F, MWP_LO, MWP_HI, MWP_HIST),
    }[component]
    mean, lo, hi, hist = comp
    return {
        "component": component,
        "history": {"labels": HIST_LABELS[-12:], "values": _round(hist[-12:])},
        "forecast": {"labels": FCST_LABELS, "mean": _round(mean),
                     "lower_80": _round(lo), "upper_80": _round(hi)},
        "horizon": "12 months, monthly granularity",
    }

@app.get("/api/drivers")
def drivers():
    out = []
    for i, (key, d) in enumerate(DRIVERS.items()):
        f, lo, hi = _forecast(d["series"], FCST_MONTHS, 20 + i)
        s = d["series"]
        out.append({
            "key": key, "name": d["name"],
            "effect": d["effect"], "desc": d["desc"],
            "latest": round(float(s[-1]), 2),
            "yoy_pct": round(float((s[-1] - s[-13]) / s[-13] * 100), 2),
            "history": {"labels": HIST_LABELS, "values": _round(s)},
            "forecast": {"labels": FCST_LABELS, "mean": _round(f),
                         "lower_80": _round(lo), "upper_80": _round(hi)},
        })
    return {"drivers": out,
            "formula": "All-in = LME + Midwest Premium + Gas Coefficient + Labour Index − Macro (Supply−Demand) + External Factor",
            "note": "These inputs have historical data only; the model forecasts each one 12 months ahead, then predicts the target price."}

@app.get("/api/drivers/importance")
def importance():
    return {"model": "GBM-Ensemble v2.3", "importance": [
        {"feature": "LME 3-month lag", "weight": 0.28},
        {"feature": "Gas Coefficient", "weight": 0.21},
        {"feature": "Macro (Supply−Demand)", "weight": 0.19},
        {"feature": "Labour Index", "weight": 0.13},
        {"feature": "External Factor", "weight": 0.11},
        {"feature": "Midwest Premium lag", "weight": 0.08},
    ]}

@app.get("/api/model/metrics")
def model_metrics():
    rng = np.random.default_rng(7)
    actual = ALLIN_HIST[-12:]
    pred = actual * (1 + rng.normal(0, 0.03, 12))
    return {
        "model": "GBM-Ensemble v2.3",
        "metrics": {"mape_pct": 3.7, "rmse_usd": 78.4, "mae_usd": 61.2, "r2": 0.91,
                    "coverage_80_pct": 84.0},
        "backtest": {"labels": HIST_LABELS[-12:], "actual": _round(actual), "predicted": _round(pred)},
        "candidates": [
            {"name": "GBM-Ensemble v2.3", "mape_pct": 3.7, "status": "champion"},
            {"name": "SARIMAX + drivers", "mape_pct": 4.6, "status": "challenger"},
            {"name": "Prophet baseline", "mape_pct": 6.1, "status": "baseline"},
            {"name": "LSTM (multivariate)", "mape_pct": 4.9, "status": "challenger"},
        ],
    }

@app.get("/api/validation")
def validation():
    return {"last_checked": str(date.today()), "sources": [
        {"name": "LME Aluminium Official Price", "url": "https://www.lme.com/en/Metals/Non-ferrous/LME-Aluminium",
         "field": "LME base price (USD/t)", "status": "linked", "latency_ms": 412},
        {"name": "Platts / S&P Global – US Midwest Premium", "url": "https://www.spglobal.com/commodityinsights",
         "field": "Midwest Premium (duty-paid)", "status": "linked", "latency_ms": 655},
        {"name": "Westmetall Market Data", "url": "https://www.westmetall.com/en/markdaten.php",
         "field": "Cross-check: LME cash settlement", "status": "linked", "latency_ms": 380},
        {"name": "Client Excel — input drivers", "url": "internal://uploads/latest",
         "field": "Gas coeff, Labour index, Macro S−D, External factor", "status": "pending_validation", "latency_ms": None},
    ], "rules": [
        {"rule": "All-in = LME + MWP + Gas + Labour − Macro(S−D) + External", "status": "pass"},
        {"rule": "No missing months in any driver series", "status": "pass"},
        {"rule": "Driver history ≥ 4–5 quarters", "status": "warning",
         "detail": "Some inputs have only 4–5 quarters of clean history — treat early readings with caution."},
        {"rule": "Outliers flagged beyond 3σ", "status": "pass"},
    ]}

@app.post("/api/upload")
async def upload(file: UploadFile = File(...)):
    if not file.filename or not file.filename.lower().endswith((".csv", ".xlsx", ".xls")):
        raise HTTPException(400, "Upload a .csv or .xlsx file.")
    content = await file.read()
    try:
        import pandas as pd
        df = pd.read_csv(BytesIO(content)) if file.filename.lower().endswith(".csv") \
            else pd.read_excel(BytesIO(content))
    except Exception as e:
        raise HTTPException(422, f"Could not parse file: {e}")
    return {"filename": file.filename, "rows": int(df.shape[0]), "columns": list(map(str, df.columns)),
            "message": "File parsed. Wire this into the data layer to replace mock series."}

@app.get("/api/health")
def health():
    return {"status": "ok"}

# ----------------------------------------------------------- assistant chat
# Azure OpenAI proxy — the key stays server-side. Configure via environment
# variables (or a .env file loaded before starting uvicorn):
#   AZURE_OPENAI_ENDPOINT    e.g. https://<your-resource>.openai.azure.com
#   AZURE_OPENAI_KEY         your Azure OpenAI API key
#   AZURE_OPENAI_DEPLOYMENT  your deployment name, e.g. gpt-4o-mini
#   AZURE_OPENAI_API_VERSION optional, defaults to 2024-06-01
from pydantic import BaseModel

class ChatMessage(BaseModel):
    role: str      # "user" | "assistant"
    content: str

class ChatRequest(BaseModel):
    messages: list[ChatMessage]

SYSTEM_PROMPT = (
    "You are the in-app assistant for the Aluminum Price Intelligence platform "
    "(Genpact Metals Analytics). The platform forecasts the all-in US aluminum "
    "price for 12 months ahead at monthly granularity, where "
    "All-in = LME base + US Midwest Premium + Gas Coefficient + Labour Index "
    "− Macro factor (supply − demand) + External factor. Input drivers have "
    "historical data only and are forecast first, then the target price is "
    "predicted (two-step approach). Answer general questions helpfully and "
    "concisely; explain forecasting, pricing and platform concepts in simple language."
)

@app.get("/api/chat/status")
def chat_status():
    configured = bool(os.getenv("AZURE_OPENAI_ENDPOINT") and os.getenv("AZURE_OPENAI_KEY"))
    return {"configured": configured,
            "deployment": os.getenv("AZURE_OPENAI_DEPLOYMENT") if configured else None}

@app.post("/api/chat")
async def chat(req: ChatRequest):
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    key = os.getenv("AZURE_OPENAI_KEY")
    deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT")
    api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-06-01")

    if not (endpoint and key and deployment):
        raise HTTPException(
            503,
            "Azure OpenAI is not configured. Set AZURE_OPENAI_ENDPOINT, "
            "AZURE_OPENAI_KEY and AZURE_OPENAI_DEPLOYMENT, then restart the backend.",
        )

    url = (f"{endpoint.rstrip('/')}/openai/deployments/{deployment}"
           f"/chat/completions?api-version={api_version}")
    payload = {
        "messages": [{"role": "system", "content": SYSTEM_PROMPT}]
                    + [m.model_dump() for m in req.messages][-20:],
        "max_tokens": 700,
        "temperature": 0.4,
    }

    import httpx
    try:
        async with httpx.AsyncClient(timeout=60) as client:
            r = await client.post(url, json=payload, headers={"api-key": key})
    except httpx.RequestError as e:
        raise HTTPException(502, f"Could not reach Azure OpenAI: {e}")

    if r.status_code != 200:
        detail = r.text[:300]
        raise HTTPException(r.status_code, f"Azure OpenAI error: {detail}")

    data = r.json()
    try:
        reply = data["choices"][0]["message"]["content"]
    except (KeyError, IndexError):
        raise HTTPException(502, "Unexpected response shape from Azure OpenAI.")
    return {"reply": reply, "usage": data.get("usage", {})}
