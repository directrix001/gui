import { useEffect, useState } from 'react'
import {
  ResponsiveContainer, ComposedChart, Area, Line, XAxis, YAxis,
  CartesianGrid, Tooltip, Legend,
} from 'recharts'
import { api } from '../api/client.js'
import { COLORS, Loading, ErrorBox, Delta, usd, tooltipStyle } from '../components/ui.jsx'

function SectionLabel({ n, title, sub }) {
  return (
    <div className="sec-label">
      <span className="sec-n">{n}</span>
      <div>
        <h2>{title}</h2>
        {sub && <p>{sub}</p>}
      </div>
    </div>
  )
}

function DriverCard({ d }) {
  const merged = [
    ...d.history.labels.map((m, i) => ({ month: m, actual: d.history.values[i] })),
    ...d.forecast.labels.map((m, i) => ({
      month: m, mean: d.forecast.mean[i],
      band: [d.forecast.lower_80[i], d.forecast.upper_80[i]],
    })),
  ]
  const up = d.yoy_pct >= 0
  return (
    <div className="card">
      <div className="card-head">
        <h3>{d.name}</h3>
        <div style={{ display: 'flex', gap: 8 }}>
          <span className={`badge ${d.effect === '+' ? 'info' : 'warn'}`}>
            {d.effect === '+' ? 'adds to price' : 'reduces price'}
          </span>
          <span className={`badge ${up ? 'ok' : 'err'}`}>
            {up ? '▲' : '▼'} {Math.abs(d.yoy_pct).toFixed(1)}% YoY
          </span>
        </div>
      </div>
      <div className="card-body">
        <div style={{ display: 'flex', gap: 20, alignItems: 'baseline', marginBottom: 8 }}>
          <span style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 22, fontWeight: 700 }}>
            {d.latest.toLocaleString('en-US')}
          </span>
          <span style={{ fontSize: 12, color: COLORS.slate }}>{d.desc}</span>
        </div>
        <div style={{ height: 170 }}>
          <ResponsiveContainer>
            <ComposedChart data={merged}>
              <CartesianGrid stroke={COLORS.grid} vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 10 }} minTickGap={40} />
              <YAxis tick={{ fontSize: 10 }} width={52} domain={['auto', 'auto']} />
              <Tooltip {...tooltipStyle}
                formatter={(v, name) =>
                  Array.isArray(v)
                    ? [`${v[0].toLocaleString()} – ${v[1].toLocaleString()}`, '80% band']
                    : [Number(v).toLocaleString(), name === 'actual' ? 'Actual' : 'Forecast']} />
              <Area dataKey="band" fill={COLORS.band} stroke="none" connectNulls />
              <Line dataKey="actual" stroke={COLORS.navy} strokeWidth={1.8} dot={false} />
              <Line dataKey="mean" stroke={COLORS.coral} strokeWidth={1.8}
                strokeDasharray="5 4" dot={false} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  )
}

export default function Dashboard() {
  const [state, setState] = useState({ loading: true })
  const [months, setMonths] = useState(24)
  const [history, setHistory] = useState(null)
  const [drivers, setDrivers] = useState(null)

  useEffect(() => {
    Promise.all([api.summary(), api.importance(), api.drivers()])
      .then(([summary, imp, drv]) =>
        setState({ loading: false, summary, imp, drv }))
      .catch((error) => setState({ loading: false, error }))
  }, [])

  useEffect(() => {
    api.history(months).then(setHistory).catch(() => {})
  }, [months])

  if (state.loading) return <div className="page"><Loading /></div>
  if (state.error) return <div className="page"><ErrorBox error={state.error} /></div>

  const { summary, imp, drv } = state
  const chartData = history
    ? history.labels.map((m, i) => ({
        month: m, LME: history.lme[i],
        'Midwest Premium': history.midwest_premium[i],
        'All-in': history.all_in[i],
      }))
    : []

  return (
    <div className="page">
      {/* ───────────────── 01 · price overview ───────────────── */}
      <SectionLabel n="01" title="Price Overview"
        sub="The full pricing identity with live component values" />

      <section className="equation" aria-label="Aluminum pricing formula">
        <div className="eq-term">
          <span className="t-label">LME Base</span>
          <span className="t-value" style={{ fontSize: 24 }}>{usd(summary.lme.value)}</span>
        </div>
        <span className="eq-op">+</span>
        <div className="eq-term">
          <span className="t-label">Midwest Premium</span>
          <span className="t-value" style={{ fontSize: 24 }}>{usd(summary.midwest_premium.value)}</span>
        </div>
        <span className="eq-op">+</span>
        <div className="eq-term">
          <span className="t-label">Gas Coeff.</span>
          <span className="t-value" style={{ fontSize: 24 }}>{usd(summary.gas_coeff.value)}</span>
        </div>
        <span className="eq-op">+</span>
        <div className="eq-term">
          <span className="t-label">Labour Index</span>
          <span className="t-value" style={{ fontSize: 24 }}>{usd(summary.labour_index.value)}</span>
        </div>
        <span className="eq-op">−</span>
        <div className="eq-term">
          <span className="t-label">Macro (S−D)</span>
          <span className="t-value" style={{ fontSize: 24 }}>{usd(summary.macro_sd.value)}</span>
        </div>
        <span className="eq-op">+</span>
        <div className="eq-term">
          <span className="t-label">External</span>
          <span className="t-value" style={{ fontSize: 24 }}>{usd(summary.external.value)}</span>
        </div>
        <span className="eq-op">=</span>
        <div className="eq-term eq-result">
          <span className="t-label">All-in Aluminum Price</span>
          <span className="t-value" style={{ fontSize: 30 }}>{usd(summary.all_in.value)}</span>
          <span className="t-sub">As of {summary.as_of}</span>
        </div>
      </section>

      <div className="grid-kpi">
        <div className="card kpi">
          <div className="label">LME Aluminum</div>
          <div className="value">{usd(summary.lme.value)} <small>/t</small></div>
          <Delta value={summary.lme.mom_pct} />
        </div>
        <div className="card kpi">
          <div className="label">Midwest Premium</div>
          <div className="value">{usd(summary.midwest_premium.value)} <small>/t</small></div>
          <Delta value={summary.midwest_premium.mom_pct} />
        </div>
        <div className="card kpi">
          <div className="label">12-Month Forecast Avg</div>
          <div className="value">{usd(summary.forecast_12m_avg)} <small>/t</small></div>
          <div className="delta flat">All-in, next 12 months</div>
        </div>
        <div className="card kpi">
          <div className="label">Forecast Peak</div>
          <div className="value">{usd(summary.forecast_peak.value)} <small>/t</small></div>
          <div className="delta flat">Expected {summary.forecast_peak.month}</div>
        </div>
        <div className="card kpi">
          <div className="label">Model Accuracy</div>
          <div className="value">{summary.model.mape_pct}% <small>MAPE</small></div>
          <div className="delta up">▲ {summary.model.name}</div>
        </div>
      </div>

      {/* ───────────────── 02 · market history ───────────────── */}
      <SectionLabel n="02" title="Market History & Model"
        sub="Component price history and what the model weighs most" />

      <div className="grid-2">
        <div className="card">
          <div className="card-head">
            <h3>Price History — components and all-in</h3>
            <div className="seg" role="tablist" aria-label="History range">
              {[12, 24, 36].map(m => (
                <button key={m} className={months === m ? 'active' : ''}
                  onClick={() => setMonths(m)}>{m}M</button>
              ))}
            </div>
          </div>
          <div className="card-body" style={{ height: 320 }}>
            <ResponsiveContainer>
              <ComposedChart data={chartData}>
                <CartesianGrid stroke={COLORS.grid} vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} minTickGap={28} />
                <YAxis tick={{ fontSize: 11 }} tickFormatter={usd} width={64} />
                <Tooltip {...tooltipStyle} formatter={(v) => usd(v)} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Area dataKey="LME" fill="rgba(4,28,44,0.08)" stroke={COLORS.navy} strokeWidth={1.6} />
                <Line dataKey="Midwest Premium" stroke={COLORS.blue} strokeWidth={1.6} dot={false} />
                <Line dataKey="All-in" stroke={COLORS.coral} strokeWidth={2.4} dot={false} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <h3>What moves the price</h3>
            <span className="hint">{imp.model}</span>
          </div>
          <div className="card-body">
            {imp.importance.map((f) => (
              <div className="imp-row" key={f.feature}>
                <span className="f">{f.feature}</span>
                <div className="imp-bar"><span style={{ width: `${f.weight * 100 * 2.6}%` }} /></div>
                <span className="w">{(f.weight * 100).toFixed(0)}%</span>
              </div>
            ))}
            <p style={{ marginTop: 14, fontSize: 12.5, color: COLORS.slate, lineHeight: 1.55 }}>
              Feature weights from the champion model. Each driver is forecast for the next 12
              months first, then the target price is predicted from those forecasts — the
              two-step approach.
            </p>
          </div>
        </div>
      </div>

      {/* ───────────────── 03 · input drivers ───────────────── */}
      <SectionLabel n="03" title="Input Drivers"
        sub="Historical inputs, each forecast 12 months ahead before the price is predicted" />

      <div className="card" style={{ padding: '14px 20px' }}>
        <span style={{ fontFamily: 'Space Grotesk, sans-serif', fontWeight: 600 }}>
          All-in = LME + Midwest Premium + Gas Coefficient + Labour Index
          − Macro (Supply−Demand) + External Factor.
        </span>{' '}
        <span style={{ color: COLORS.slate }}>
          Solid navy = history · dashed coral = the driver's own forecast with its 80% band.
        </span>
      </div>

      <div className="grid-2e">
        {drv.drivers.map(d => <DriverCard key={d.key} d={d} />)}
      </div>
    </div>
  )
}
