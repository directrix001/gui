"""
Master database layer — ONE SQLite database (master.db) holding every table the
platform and the SQL agent need, built from data/master_data.csv (long format:
month, factor_key, value, source).

Tables & relationships (all joins live inside one file → perfect for text-to-SQL):

    factors(key PK, name, effect, unit)
        1 ─── * monthly_values(month, factor_key FK→factors.key, value, source)
                 PRIMARY KEY (month, factor_key)   -- month format 'YYYY-MM'
    events(id PK, month, title, category, impact, note)
        * ─── * factors  via  event_factors(event_id FK, factor_key FK)
    price_comparison(month PK, fred_palumusdm, lme_3m)   -- real two-source data

`monthly_values` is the heart: one row per (month, factor). Pivot with
MAX(CASE WHEN ...) or self-joins to put factors side by side.
"""
import csv
import sqlite3
from pathlib import Path

DATA_DIR = Path(__file__).parent / "data"
MASTER_DB = DATA_DIR / "master.db"
MASTER_CSV = DATA_DIR / "master_data.csv"
LME_CSV = DATA_DIR / "lme_comparison.csv"

FACTORS = {
    "lme":             {"name": "LME Base Price",        "effect": "+", "unit": "USD/t"},
    "midwest_premium": {"name": "US Midwest Premium",    "effect": "+", "unit": "USD/t"},
    "gas":             {"name": "Gas Coefficient",       "effect": "+", "unit": "USD/t"},
    "labour":          {"name": "Labour Index",          "effect": "+", "unit": "USD/t"},
    "macro":           {"name": "Macro (Supply−Demand)", "effect": "-", "unit": "USD/t"},
    "external":        {"name": "External Factor",       "effect": "+", "unit": "USD/t"},
}

EVENTS = [
    ("2008-10", "Global financial crisis demand collapse", "macro_shock", "down",
     "Industrial demand fell sharply worldwide; aluminum sold off with all commodities.", ["lme", "macro"]),
    ("2014-11", "Warehouse-queue premium spike", "logistics", "up",
     "LME warehouse queues pushed the US Midwest Premium to record levels.", ["midwest_premium"]),
    ("2018-03", "US Section 232 tariffs (10% on aluminum imports)", "tariff", "up",
     "Import tariffs pushed the US Midwest Premium sharply higher.", ["midwest_premium", "external"]),
    ("2018-04", "Rusal sanctions", "geopolitical", "up",
     "Sanctions on a major producer squeezed global supply expectations.", ["lme", "external"]),
    ("2020-03", "COVID-19 demand shock", "macro_shock", "down",
     "Lockdowns cut transport and construction demand; prices slid to multi-year lows.", ["lme", "macro"]),
    ("2021-09", "China dual-control energy curbs on smelters", "china_supply", "up",
     "Power rationing curtailed Chinese smelter output, tightening supply.", ["lme", "macro", "gas"]),
    ("2021-10", "European energy crisis smelter curtailments", "energy", "up",
     "Record gas/power prices forced EU smelters to cut output.", ["gas", "lme"]),
    ("2022-02", "Russia invades Ukraine", "geopolitical", "up",
     "War risk on Russian metal plus energy spike drove LME to record highs.", ["lme", "gas", "external"]),
    ("2022-03", "LME price spike to all-time highs", "geopolitical", "up",
     "Peak of the supply-fear rally; freight and premiums surged too.", ["lme", "midwest_premium"]),
    ("2022-06", "Global rate hikes cool demand", "macro_shock", "down",
     "Aggressive central-bank tightening hit industrial demand expectations.", ["macro", "lme"]),
    ("2023-08", "Soft China recovery weighs on prices", "china_demand", "down",
     "Weaker-than-hoped Chinese construction demand kept prices subdued.", ["macro", "lme"]),
    ("2024-04", "US/UK ban Russian metal on LME", "geopolitical", "up",
     "New deliveries of Russian aluminum barred from LME warehouses.", ["lme", "external"]),
    ("2025-04", "Tariff escalation to 25-50% on aluminum", "tariff", "up",
     "Sharply higher US tariffs re-priced the Midwest Premium upward.", ["midwest_premium", "external"]),
    ("2026-01", "Supply deficit narrative builds", "macro_shock", "up",
     "Reports of a widening supply deficit and restocking lifted prices.", ["macro", "lme"]),
    ("2026-04", "Energy cost pass-through accelerates", "energy", "up",
     "Higher gas benchmarks fed directly into smelting cost curves.", ["gas", "lme"]),
]

SCHEMA_DOC = """SQLite database `master.db`. Months are TEXT 'YYYY-MM'.

TABLE factors(key TEXT PK, name TEXT, effect TEXT('+' adds to price,'-' subtracts), unit TEXT)
  keys: lme, midwest_premium, gas, labour, macro, external
TABLE monthly_values(month TEXT, factor_key TEXT FK->factors.key, value REAL, source TEXT,
  PRIMARY KEY(month, factor_key))  -- one row per month per factor, 2008-01..2026-06
TABLE events(id INTEGER PK, month TEXT, title TEXT, category TEXT,
  impact TEXT('up'/'down'), note TEXT)
TABLE event_factors(event_id INTEGER FK->events.id, factor_key TEXT FK->factors.key)
TABLE price_comparison(month TEXT PK, fred_palumusdm REAL, lme_3m REAL)

Pivot example (factors side by side per month):
  SELECT month,
    MAX(CASE WHEN factor_key='lme' THEN value END) AS lme,
    MAX(CASE WHEN factor_key='midwest_premium' THEN value END) AS premium
  FROM monthly_values GROUP BY month;
Events for a factor:
  SELECT e.* FROM events e JOIN event_factors ef ON ef.event_id=e.id
  WHERE ef.factor_key='lme';"""


def _conn(readonly: bool = False) -> sqlite3.Connection:
    if readonly:
        c = sqlite3.connect(f"file:{MASTER_DB}?mode=ro", uri=True)
    else:
        c = sqlite3.connect(MASTER_DB)
    c.row_factory = sqlite3.Row
    return c


def build_master() -> dict:
    """(Re)build master.db from master_data.csv (+ lme_comparison.csv)."""
    from . import data_builder
    if not MASTER_CSV.exists():
        data_builder.build_csv()

    conn = _conn()
    try:
        conn.executescript("""
            DROP TABLE IF EXISTS factors;
            DROP TABLE IF EXISTS monthly_values;
            DROP TABLE IF EXISTS events;
            DROP TABLE IF EXISTS event_factors;
            DROP TABLE IF EXISTS price_comparison;
            CREATE TABLE factors(key TEXT PRIMARY KEY, name TEXT, effect TEXT, unit TEXT);
            CREATE TABLE monthly_values(
                month TEXT, factor_key TEXT REFERENCES factors(key),
                value REAL, source TEXT, PRIMARY KEY(month, factor_key));
            CREATE TABLE events(id INTEGER PRIMARY KEY, month TEXT, title TEXT,
                category TEXT, impact TEXT, note TEXT);
            CREATE TABLE event_factors(
                event_id INTEGER REFERENCES events(id),
                factor_key TEXT REFERENCES factors(key),
                PRIMARY KEY(event_id, factor_key));
            CREATE TABLE price_comparison(
                month TEXT PRIMARY KEY, fred_palumusdm REAL, lme_3m REAL);
            CREATE INDEX idx_mv_factor ON monthly_values(factor_key, month);
        """)
        conn.executemany("INSERT INTO factors VALUES (?,?,?,?)",
            [(k, m["name"], m["effect"], m["unit"]) for k, m in FACTORS.items()])
        with open(MASTER_CSV) as f:
            rows = [(r["month"], r["factor_key"], float(r["value"]), r["source"])
                    for r in csv.DictReader(f)]
        conn.executemany("INSERT OR REPLACE INTO monthly_values VALUES (?,?,?,?)", rows)
        for i, (month, title, cat, impact, note, fks) in enumerate(EVENTS, start=1):
            conn.execute("INSERT INTO events VALUES (?,?,?,?,?,?)",
                         (i, month, title, cat, impact, note))
            conn.executemany("INSERT INTO event_factors VALUES (?,?)",
                             [(i, fk) for fk in fks])
        if LME_CSV.exists():
            with open(LME_CSV) as f:
                cmp_rows = [(r["observation_date"],
                             float(r["palumusdm"]) if r["palumusdm"] else None,
                             float(r["lme_3m"]) if r["lme_3m"] else None)
                            for r in csv.DictReader(f)]
            conn.executemany("INSERT OR REPLACE INTO price_comparison VALUES (?,?,?)",
                             cmp_rows)
        conn.commit()
        n = conn.execute("SELECT COUNT(*) FROM monthly_values").fetchone()[0]
        return {"monthly_values": n, "events": len(EVENTS)}
    finally:
        conn.close()


def run_sql(sql: str, limit: int = 200) -> dict:
    """Execute a validated read-only query. Returns columns + rows."""
    conn = _conn(readonly=True)
    try:
        cur = conn.execute(sql)
        cols = [d[0] for d in cur.description] if cur.description else []
        rows = [list(r) for r in cur.fetchmany(limit)]
        return {"columns": cols, "rows": rows, "row_count": len(rows)}
    finally:
        conn.close()


# ---- helpers kept API-compatible with the old per-factor layer ----
def get_factor_value(key: str, month: str):
    conn = _conn(readonly=True)
    try:
        r = conn.execute("SELECT value FROM monthly_values WHERE factor_key=? AND month=?",
                         (key, month)).fetchone()
        return r["value"] if r else None
    finally:
        conn.close()


def month_snapshot(month: str) -> dict:
    conn = _conn(readonly=True)
    try:
        rows = conn.execute("""
            SELECT f.key, f.name, f.effect,
                   cur.value AS value, prev.value AS prev
            FROM factors f
            LEFT JOIN monthly_values cur
                   ON cur.factor_key = f.key AND cur.month = ?
            LEFT JOIN monthly_values prev
                   ON prev.factor_key = f.key
                  AND prev.month = (SELECT MAX(month) FROM monthly_values
                                    WHERE factor_key = f.key AND month < ?)
        """, (month, month)).fetchall()
    finally:
        conn.close()
    out = {}
    for r in rows:
        cv, pv = r["value"], r["prev"]
        out[r["key"]] = {
            "name": r["name"], "effect": r["effect"], "value": cv, "prev": pv,
            "change": round(cv - pv, 2) if cv is not None and pv is not None else None,
            "change_pct": round((cv - pv) / pv * 100, 2)
                          if cv is not None and pv not in (None, 0) else None,
        }
    return out


def events_near(month: str, window: int = 1) -> list[dict]:
    y, m = int(month[:4]), int(month[5:7])
    keep = set()
    for d in range(-window, window + 1):
        mm = m + d
        yy = y + (mm - 1) // 12
        mm = (mm - 1) % 12 + 1
        keep.add(f"{yy:04d}-{mm:02d}")
    conn = _conn(readonly=True)
    try:
        rows = conn.execute(
            f"""SELECT e.*, GROUP_CONCAT(ef.factor_key) AS factor_keys
                FROM events e LEFT JOIN event_factors ef ON ef.event_id = e.id
                WHERE e.month IN ({','.join('?' * len(keep))})
                GROUP BY e.id ORDER BY e.month""", list(keep)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def db_inventory() -> list[dict]:
    conn = _conn(readonly=True)
    try:
        inv = []
        for r in conn.execute("""
            SELECT f.key, f.name, COUNT(mv.month) rows_n,
                   MIN(mv.month) lo, MAX(mv.month) hi,
                   (SELECT source FROM monthly_values WHERE factor_key=f.key LIMIT 1) src
            FROM factors f LEFT JOIN monthly_values mv ON mv.factor_key=f.key
            GROUP BY f.key""").fetchall():
            inv.append({"key": r["key"], "db": "master.db", "name": r["name"],
                        "rows": r["rows_n"], "from": r["lo"], "to": r["hi"],
                        "primary_source": r["src"]})
        return inv
    finally:
        conn.close()
