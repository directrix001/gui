# Leaver Payroll Calculation Script — Full Logic Documentation

## 1. Purpose

The Python script is a **desktop payroll "leaver calculation" tool**. It opens an Excel workbook chosen by the user (Tkinter file dialog), reads data from several sheets, computes ~30 payroll figures for an employee who is leaving the company (final pay, overtime, shift premiums, absences, PILON, holiday balance, deductions, prorated allowances), writes the results back into specific cells, and saves the same workbook.

## 2. Workbook Structure the Script Expects

| Sheet | Role |
|---|---|
| `Calculations` (`ws_calc`) | Output sheet. Results are written to columns C, D, I, J. Also holds inputs: `I4` (leave date / LWD), `C3` (hourly rate), `C4` (basic/monthly rate). |
| `ExcelPaySlip` (`ws_pay`) | Pasted payslip. Col A = pay elements + entity/paygroup text (e.g. "NMUK", "SHIFT DL"), Col B = amounts for Col A items, Col E = deduction/benefit names (ECSF, HOUSING, CAR DRAW…), Col G (index 7) = their amounts, Col C = shift rate. |
| `T&A` (`ws_ta`) | Time & Attendance rows starting at row 3. Col C = date, Col D = time-entry code, Col E = quantity/hours, Col F = script writes paid/unpaid values here, Col G = tag/description, Col H = approval status, Col J/K = holiday FT code and days. |
| `Leaver Form` | `D18` = notice period ("4 weeks" / "1 Month"), `D19` = "YES/NO" (shift uplift applies). |
| `Holidays` | Holiday lookup tables (A:B and D:E), `B31`, `E36`, `C36`, `F36`; script writes L2–L10, L14, L15. |

## 3. Step-by-Step Logic

### 3.1 File selection & load
- Tkinter yes/no dialog → file picker (`.xlsx` only).
- `load_workbook(file_path)` **without** `data_only=True` so saving preserves formulas (but this also means formula cells read as formula strings, not values — see §5.9).

### 3.2 BASIC block
- `Calculations!I5 = ExcelPaySlip!A2` (employee name), `I6 = ExcelPaySlip!B3` (employee number).
- **Hourly rate (`J3`)**: `ExcelPaySlip!A11` is text like `"BASIC PAY (160 X 14.71)"`. The script splits on `"X"`, takes the part after it, strips `")"` → `"14.71"` (stored as **string**). If no `"X"` → 0.
- **Working days**: counts Mon–Fri from the 1st of the month of `Calculations!I4` up to and including `I4`.
- **Entity factor** from `ExcelPaySlip!A4`: contains NMUK/NTCE/NITCO/NMPC → **7.8** h/day; NMGB/NDE → **7.5**; else 0.
- `J4 = round(J3 × factor × working_days, 2)` → basic pay for days worked.

### 3.3 OVERTIME (`J6`–`J8`)
Scan `T&A` rows 3→end; if Col D contains `OVERTIME X1.0` / `X1.5` / `X2.0`, add Col E (comma-stripped float) to the matching bucket. Then:
- `J6 = x10 + (J3 × x10 × 1.0)`
- `J7 = x15 + (J3 × x15 × 1.5)`
- `J8 = x20 + (J3 × x20 × 2.0)`

> Note the odd formula shape: hours + (rate × hours × multiplier). This is what the code literally does.

### 3.4 SHIFT-BASED OVERTIME (`J9`–`J11`)
For rows where Col D == `"UK - OVERTIME X1.5"` exactly, split Col E by tag (Col G):
- `LATE SHIFT OVERTIME 1.5X` → `late_sum`
- `NIGHT SHIFT OVERTIME 1.5X` → `night_sum`
- `EARLY SHIFT OVERTIME 1.5X` → `early_sum`

Intended results:
- `J9 = late_sum × (J3 × 0.20)`
- `J10 = night_sum × (J3 × 0.3333)`
- `J11 = early_sum × (J3 × 0.1333)`

### 3.5 DAY-TO-X shift-change premiums (`J12`–`J14`)
Rows where Col D is **blank**, Col C is a **weekday**, and Col G contains:
- `DAY TO EARLY` → sum Col E → `J12`
- `DAY TO LATE` → sum → `J13`
- `DAY TO NIGHT` → sum → `J14`

### 3.6 Shift type detection
Scans **every cell** of `ExcelPaySlip` for `SHIFT DL`/`SH DL` → `DL`, `SHIFT DF`/`SH DF` → `DF`, `SHIFT MF`/`SH MF` → `MF`.

### 3.7 PAID absence rules → T&A Col F + `J22`
For each T&A row with tag (G) + date (C), by weekday (Mon=0…Sun=6):

| Shift | Tag contains | Mon–Thu | Fri | Sat | Sun |
|---|---|---|---|---|---|
| DL | ABSENCE (PAID) + LATE SHIFT | 1.58 | 1.49 | 0 | 0 |
| DF | ABSENCE (PAID) + LATE SHIFT | 1.48 | 1.45 | 0 | 0 |
| DF | ABSENCE (PAID) + NIGHT SHIFT | 2.47 | 0 | 0 | 3.19 |
| MF | ABSENCE (PAID) + DAY SHIFT | 0 | 0 | 4.58 | 11.83 |
| MF | ABSENCE (PAID) + NIGHT SHIFT | 3.94 | 9.86 | 12.89 | 3.94 |

The per-row value is written into **T&A Col F**; the total → `Calculations!J22`.

### 3.8 UNPAID absence rules → T&A Col F + `J23`

| Shift | Tag contains | Mon–Thu | Fri | Sat | Sun |
|---|---|---|---|---|---|
| DL | ABSENCE (UNPAID) + LATE SHIFT | 9.46 | 8.96 | 0 | 0 |
| DL | ABSENCE (UNPAID) + DAY SHIFT | 0 | 7.88 | 0 | 0 |
| DF | ABSENCE (UNPAID) + LATE SHIFT | 8.9 | 8.7 | 0 | 0 |
| DF | ABSENCE (UNPAID) + NIGHT SHIFT | 9.89 | 0 | 0 | 12.77 |
| MF | ABSENCE (UNPAID) + DAY SHIFT | 11.83 | 11.83 | 14.25 | 23.86 |
| MF | ABSENCE (UNPAID) + NIGHT SHIFT | 15.77 | 21.69 | 22.56 | 15.77 |

Total → `J23`.

### 3.9 ABSENCE COUNT (`J25`)
Count T&A rows where Col H == `APPROVED`, Col G contains `ABSENCE`, and Col C is a weekday. First 3 are free: `remaining = max(count − 3, 0)`. `J25 = round((118.75 / 5) × remaining, 2)`.

### 3.10 DEPUTISING (`J17`)
Find "DEPUTISING" in `ExcelPaySlip` Col A → amount from Col B. `J17 = round(amount × 12 / 260 × working_days, 2)` (same working-day count as §3.2).

### 3.11 PILON (`C20`)
1. Weeks = first token of `Leaver Form!D18` (e.g. "4 weeks" → 4). `weekdays = weeks × 5`.
2. Pay factor = entity factor (7.8 / 7.5) from `ExcelPaySlip!A4`.
3. `pilon = round(weekdays × factor × Calculations!C3, 2)`.
4. If `Leaver Form!D19 == "YES"`, find the shift line in payslip Col A and uplift: DL 12%, DF 22%, DT 22%, MF 38%, RT 38%. `C20 = pilon × (1 + pct/100)`, else `C20 = pilon`.

### 3.12 LIEU (`C21`)
Only if `D18` contains `MONTH`: `lieu = Calculations!C4`; apply the same D19 shift uplift; write `C21`. Otherwise skipped entirely.

### 3.13 ECSF (`D27`, `C27`) & ESSF (`D28`, `C28`)
Find "ECSF"/"ESSF" in payslip Col E, amount from Col G (code comment says F, the code reads **column 7 = G**). Monthly value → `D27`/`D28`. `month_count = max(month(I4) − 2, 0)` (Feb=0? No: Mar=1 …; i.e. months elapsed since Feb). Clawback: `C27/C28 = round(amount × month_count × −1, 2)`.

### 3.14 NMUK-gated payslip items (amount from Col G unless noted)

| Item | Gate (Col A) | Leave-day rule | Written to |
|---|---|---|---|
| CAR DRAW | NMUK | day 6–24 → 0, else amount | `C32` |
| FIT CENT | NMUK or NTCE | none | `C29`, `D29` (comments wrongly say C36/D36) |
| NSSC GYM | NMUK | none | `C30`, `D30` |
| HOL DRAW | NMUK | day ≤5 or ≥25 → amount, else 0 | `C33`, `D33` |
| SAFCDRAW | NMUK | day 7–24 → 0, else amount | `C18` **and `D19`** (bug, should be `D18`) |
| NUFCDRAW | NMUK | day 7–24 → 0, else amount | `C19`, `D19` (overwrites SAFCDRAW's D19) |
| GOODS | NMUK | `C31 = amount/12 × month(I4)`; raw amount → `D31` | `C31`, `D31` |

### 3.15 Shift rate & allowance (`D5`, `C5`)
Find payslip Col A row starting with `SHIFT `; code after "SHIFT" must **exactly equal** one of: DL 12%, DF 22%, DT 22%, MF 38%, RT 38%, WE A 30%, WE B 10%, WE 23%, ES 13%, MN 19%, SP 19%, WEC 20%, TS 27%. Shift rate = that row's **Col C** → `D5`. `C5 = round(C4 × pct × C3, 2)`.

### 3.16 Date copy (`C40`)
`I4` formatted `dd-MMM-yyyy` → `C40`.

### 3.17 Prorated monthly items
`Housing` (→ `D36`, prorated → `C36`), `London Allowance` (→ `D35`/`C35`), `Lump Sum` (NDE-gated, amount from Col A/B, → `D34`/`C34`).
Proration: `amount ÷ total working days in month × working days from 1st to leave date`.

### 3.18 HOLIDAYS sheet (`L2`–`L10`)
- `L2`: look up LWD (`I4`) in Holidays Col A → return Col B; else Col D → Col E.
- `L3 = MIN(INT(B31/5), 6)`.
- `L4`: if payslip has `SHIFT` + `MF` → `E36 − 1`, else 0.
- `L5 = 1` if LWD is 25–29 May; `L8 = 1` if 7–27 Aug; `L9 = 1` if 21 Dec–2 Jan 2027.
- `L6 = C36`; `L7 = −F36`; `L10 = SUM(L2:L9)`.

### 3.19 Holiday balance pay (`L14`, `L15`, `Calculations!C15`)
- `L14 = C3 (hourly) × entity_rate (7.8/7.5) × L10`, rounded to 3 dp.
- `L15 = L14 × shift %` — **different percentage table here**: DL 12, DF/DT 22, MF/RT 38, WE A 30, WE B 10, WEC 20, ES **13.33**, MN/SP **18.5**, TS 27, WE **22.5** (inconsistent with §3.15's 13/19/23).
- `C15 = L14 + L15` if any SHIFT line exists, else `L14`.

### 3.20 Holiday overtime (`C24`)
`C24 = round((Σ ColE where ColD == "UK - OVERTIME X1.5") ÷ 2028 × entity_rate × (Σ ColK where ColJ == "UK-NMUK HOLIDAY FT") + HOLIDAY EXTRA, 2)` where HOLIDAY EXTRA comes from payslip Col E/G.

### 3.21 Save
`wb.save(file_path)` — overwrites the original file in place.

## 4. Full Output Cell Map

| Cell | Meaning |
|---|---|
| Calc I5/I6 | Name / employee no |
| Calc J3 | Hourly rate (string!) |
| Calc J4 | Basic pay for days worked |
| Calc J6/J7/J8 | OT ×1.0 / ×1.5 / ×2.0 |
| Calc J9/J10/J11 | Late / Night / Early shift OT premium |
| Calc J12/J13/J14 | Day→Early / Late / Night |
| Calc J17 | Deputising |
| Calc J22/J23 | Paid / Unpaid absence totals |
| Calc J25 | Absence deduction (>3 approved) |
| Calc C5/D5 | Shift allowance / shift rate |
| Calc C15 | Holiday balance pay |
| Calc C18/C19 (+D18/D19) | SAFCDRAW / NUFCDRAW |
| Calc C20/C21 | PILON / LIEU |
| Calc C24 | Holiday overtime |
| Calc C27–C36, D27–D36 | ECSF, ESSF, FIT CENT, NSSC GYM, GOODS, CAR DRAW, HOL DRAW, LUMP SUM, LONDON, HOUSING |
| Calc C40 | LWD as dd-MMM-yyyy |
| Holidays L2–L10, L14, L15 | Holiday balance build-up |
| T&A Col F | Per-row paid/unpaid values |

## 5. Bugs / Quirks in the Current Script (as written)

1. **Broken indentation — the biggest issue.** The "SHIFT BASED CALCULATION" block is dedented out of the `if answer:` scope, so it runs even when no file is selected (→ `NameError` on `ws_ta`). Worse, the J9–J14 final formulas, shift-type detection, and the whole PAID/UNPAID (J22/J23) machinery are nested **inside the `elif clean_tag == "EARLY SHIFT OVERTIME 1.5X":` branch** — they only execute if an *early-shift* row is found, and they execute mid-loop with **partial sums**.
2. `J3` is written as a **string**, then re-parsed with `float()`.
3. `SAFCDRAW` writes its D-column copy to `D19` instead of `D18`; NUFCDRAW then overwrites `D19`.
4. FIT CENT / NSSC GYM comments claim C36/C37 but the code writes C29/C30 (comments stale; Housing correctly owns C36).
5. ECSF/ESSF comments say "Column F" but read `column=7` (G) — consistent with all other Col G reads, so the comments are wrong, not the code.
6. Two conflicting shift-percentage tables (13% vs 13.33% for ES, 19% vs 18.5% for MN/SP, 23% vs 22.5% for WE).
7. Bare `except:` everywhere silently swallows real errors.
8. `working_days` computed 4+ separate times with copy-pasted loops.
9. Loading without `data_only=True` means any *formula* cell (e.g. `C3`, `C4`, `B31`) reads as the formula string, and `float(...)` fails → silently becomes 0.
10. Saves over the original file with no backup.

The NestJS conversion implements the **intended** logic (bugs 1–3 fixed, constants kept as-is per table, both shift tables preserved where each is used) — see `FIXES_APPLIED.md` notes inside the testing guide.
