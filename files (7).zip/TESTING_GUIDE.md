# Testing Guide — Payroll NestJS Backend (VS Code)

## 1. Setup & Run

```bash
cd payroll-backend
npm install
npm run start:dev        # http://localhost:3000, hot reload
```

You should see: `Payroll backend running on http://localhost:3000`.

## 2. API Surface

| Method | URL | What it does |
|---|---|---|
| GET | `/payroll/sections` | Lists every calculation section name + run order |
| POST | `/payroll/process` | Upload `.xlsx` (field name **`file`**), runs ALL sections, saves processed copy, returns JSON of every result + logs + download link |
| POST | `/payroll/process?sections=overtime,pilon` | Runs only the named sections (`basic` and `shift-type` auto-run as prerequisites) |
| POST | `/payroll/process?save=false` | Compute-only — JSON results, no output file written |
| GET | `/payroll/download/:name` | Downloads the processed workbook (name comes back in the process response) |

Section names (exactly as the API expects):
`basic, overtime, shift-overtime, day-shift-change, shift-type, paid-absence, unpaid-absence, absence-count, deputising, pilon, lieu, ecsf-essf, car-draw, fit-cent, nssc-gym, hol-draw, safcdraw, nufcdraw, shift-allowance, goods, date-copy, housing, london-allowance, lump-sum, holidays-requirements, holiday-balance, holiday-overtime`

## 3. Testing inside VS Code — 3 options

### Option A — REST Client extension (recommended)
1. Install the **REST Client** extension (`humao.rest-client`).
2. Open `test.http` in this project.
3. Put a sample workbook at `./sample.xlsx` (same structure as your leaver file: Calculations, ExcelPaySlip, T&A, Leaver Form, Holidays).
4. Click **Send Request** above any block.

### Option B — Thunder Client extension
1. Install **Thunder Client**, New Request → POST `http://localhost:3000/payroll/process`.
2. Body → **Form** → type **File**, key `file`, pick your `.xlsx`.
3. Send. Response JSON shows every section's numbers.

### Option C — curl (VS Code terminal)
```bash
# full run
curl -F "file=@sample.xlsx" http://localhost:3000/payroll/process | jq .

# one functionality only (e.g. PILON)
curl -F "file=@sample.xlsx" "http://localhost:3000/payroll/process?sections=pilon&save=false" | jq .results.pilon

# download the processed workbook (name from previous response)
curl -O http://localhost:3000/payroll/download/<outputFile-from-response>
```

## 4. How to test EACH functionality (what to send, what to check)

For every row below: `curl -F "file=@sample.xlsx" "http://localhost:3000/payroll/process?sections=<name>&save=false"` and inspect `results.<name>`.

| Section | Prepare in the workbook | Expect in JSON / cells |
|---|---|---|
| `basic` | `ExcelPaySlip!A11` = `BASIC PAY (160 X 14.71)`, `A4` = `NMUK ...`, `Calculations!I4` = a date | `J3=14.71`, `workingDays` = Mon–Fri count 1st→I4, `J4 = 14.71 × 7.8 × workingDays` |
| `overtime` | T&A rows with D = `UK - OVERTIME X1.0/X1.5/X2.0`, hours in E | `hoursX10/15/20` sums; `J6/J7/J8` per formula `h + j3·h·mult` |
| `shift-overtime` | D = `UK - OVERTIME X1.5` **exactly**, G = `LATE/NIGHT/EARLY SHIFT OVERTIME 1.5X` | `J9 = late·j3·0.20`, `J10 = night·j3·0.3333`, `J11 = early·j3·0.1333` |
| `day-shift-change` | Rows with **blank D**, weekday date in C, G contains `Day to Early/Late/Night`, value in E | Sums in `J12/J13/J14`; weekend rows ignored |
| `shift-type` | Put `SHIFT DL` (or DF/MF) anywhere in ExcelPaySlip | `shiftType: "DL"` |
| `paid-absence` | G = `Absence (Paid) - Late Shift` etc. with dates | Per-row values in T&A col F, total in `J22` (e.g. DL Mon–Thu → 1.58/row) |
| `unpaid-absence` | G = `Absence (Unpaid) - ...` | Total in `J23` (e.g. DL Late Mon–Thu → 9.46/row) |
| `absence-count` | ≥4 rows: H=`Approved`, G contains `Absence`, weekday dates | `chargeable = matched−3`, `J25 = 23.75 × chargeable` |
| `deputising` | Col A row `DEPUTISING`, amount in B | `J17 = amt×12/260×workingDays` |
| `pilon` | Leaver Form `D18` = `4 weeks`, `D19` = `YES`, `Calculations!C3` set, shift line in payslip | `C20 = 4·5·factor·C3 × (1+pct/100)` |
| `lieu` | `D18` = `1 Month`, `D19` = `YES`, `Calculations!C4` set | `C21 = C4 × (1+pct/100)`; with `D18=4 weeks` → `skipped: true` |
| `ecsf-essf` | Col E `ECSF`/`ESSF`, amount in G; I4 e.g. October | `monthCount = 8`, `C27 = −ecsf×8`, `D27 = ecsf` (same for ESSF→C28/D28) |
| `car-draw` | `NMUK` in col A, `CAR DRAW` in E, amount in G | I4 day 6–24 → `C32=0`; day 1–5 / 25–31 → amount |
| `fit-cent` | `NMUK` or `NTCE` + `FIT CENT` | Amount in `C29` & `D29` |
| `nssc-gym` | `NMUK` + `NSSC GYM` | `C30` & `D30` |
| `hol-draw` | `NMUK` + `HOL DRAW` | Day ≤5 or ≥25 → amount in `C33/D33`, else 0 |
| `safcdraw` | `NMUK` + `SAFCDRAW` | Day 7–24 → 0, else amount → `C18/D18` |
| `nufcdraw` | `NMUK` + `NUFCDRAW` | Day 7–24 → 0, else amount → `C19/D19` |
| `shift-allowance` | Col A row `SHIFT DL` with rate in col C; `C3`, `C4` set | `D5` = rate, `C5 = C4×0.12×C3` |
| `goods` | `NMUK` + `GOODS` in E/G; I4 = October | `C31 = amt/12×10`, `D31 = amt` |
| `date-copy` | Valid date in I4 | `C40` = `14-Oct-2026` style |
| `housing` | `HOUSING` in E/G | `D36` = amount, `C36` = prorated by working days |
| `london-allowance` | `LONDON ALLOWANCE` in E/G | `D35`/`C35` same pattern |
| `lump-sum` | `NDE` in col A + `LUMP SUM` row (amount col B) | `D34`/`C34`; without NDE → `skipped: true` |
| `holidays-requirements` | Holidays sheet with lookup tables, `B31`, `E36`, `C36`, `F36`; LWD in a shutdown window | `L2…L9` individually, `L10` = sum |
| `holiday-balance` | Needs `L10` (auto-runs if you also pass `holidays-requirements`) | `L14 = C3×entity×L10`, `L15 = L14×shift%`, `C15` |
| `holiday-overtime` | D = `UK - OVERTIME X1.5`, J = `UK-NMUK HOLIDAY FT` (days in K), `HOLIDAY EXTRA` in payslip | `C24 = ot/2028×entity×ftDays + extra` |

> Tip: chained sections — e.g. `?sections=holidays-requirements,holiday-balance` — run in registry order, so dependencies resolve as long as you include them.

## 5. Verifying the written cells
Every `process` call (without `save=false`) writes a copy to `outputs/` and returns `downloadUrl`. Download it and check the exact cells (`Calculations!J4`, `Holidays!L10`, `T&A` col F, …) against the JSON. The original upload is never modified — unlike the Python script, which saved over the source file.

## 6. Error cases to test
```bash
curl -X POST http://localhost:3000/payroll/process            # 400: no file
curl -F "file=@notanexcel.txt" http://localhost:3000/payroll/process   # 400: invalid xlsx
curl -F "file=@sample.xlsx" "http://localhost:3000/payroll/process?sections=nope"  # 400: unknown section
curl http://localhost:3000/payroll/download/missing.xlsx      # 404
```

## 7. Fixes applied vs the Python script
1. Indentation bugs fixed: J9–J14, shift detection, and J22/J23 now always run on **complete** sums (Python only ran them inside the EARLY-shift branch).
2. `J3` written as a number, not a string.
3. `SAFCDRAW` mirrors to `D18` (Python wrote `D19`, which NUFCDRAW then overwrote).
4. Original file is preserved; output is a timestamped copy.
5. Silent bare `except:` replaced with per-section error objects in the JSON (`results.<section>.error`).
Constants (7.8/7.5, absence tables, both shift-percentage tables) are kept exactly as in the script.
