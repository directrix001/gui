require("dotenv").config();
const fs = require("fs");
const path = require("path");
const express = require("express");
const cors = require("cors");
const multer = require("multer");
const XLSX = require("xlsx");
const archiver = require("archiver");
const { v4: uuid } = require("uuid");

const data = require("./services/data");
const { renderDocx } = require("./services/docx");
const { docxToPdf } = require("./services/pdf");
const { createLog } = require("./services/logger");

const { cols } = data;
const app = express();
app.use(cors());
app.use(express.json({ limit: "10mb" }));

const upload = multer({ dest: path.join(__dirname, "..", "tmp_uploads") });
const jobs = new Map(); // jobId -> { percent, status, message, errors, zips, done }

const wrap = (fn) => (req, res) => Promise.resolve(fn(req, res)).catch((e) => {
  console.error(e);
  res.status(400).json({ error: e.message });
});

// ---------------------------------------------------------------- session
app.post("/api/session", wrap((req, res) => {
  const s = data.initSession();
  const regions = [...new Set(s.hroRows.map((r) => r[cols.REGION_COL]).filter(Boolean))].sort();
  res.json({ ok: true, regions, paths: s.paths });
}));

// ------------------------------------------------------- cascading options
app.get("/api/options", wrap((req, res) => {
  const s = data.requireSession();
  const { region, entity, category } = req.query;
  let rows = s.hroRows;
  if (region) rows = rows.filter((r) => String(r[cols.REGION_COL]).trim() === String(region).trim());
  if (entity) rows = rows.filter((r) => String(r[cols.ENTITY_COL]).trim() === String(entity).trim());
  if (category) rows = rows.filter((r) => String(r[cols.CATEGORY_COL]).trim() === String(category).trim());
  const pick = (c) => [...new Set(rows.map((r) => r[c]).filter(Boolean))].sort();
  res.json({
    entities: region ? pick(cols.ENTITY_COL) : [],
    categories: region && entity ? pick(cols.CATEGORY_COL) : [],
    letters: region && entity && category ? pick(cols.LETTER_COL) : [],
  });
}));

// ---------------------------------------------------------- letter fields
app.post("/api/letter/fields", wrap((req, res) => {
  const hroRow = data.findHroRow(req.body);
  if (!hroRow) throw new Error("Selected letter template was not found in the repository");
  res.json({ fields: data.letterFields(hroRow) });
}));

// -------------------------------------------------------------- employee
app.get("/api/employee/:id", wrap((req, res) => {
  const row = data.findEmployee(req.params.id);
  if (!row) throw new Error("Employee ID not found");
  const values = {};
  for (const k of Object.keys(row)) values[k.trim()] = row[k];
  res.json({
    employee: values,
    title: data.titleFromGender(data.wdGet(row, "Gender")),
  });
}));

// Prefill values for the dynamic-field screen (single mode)
app.post("/api/single/prefill", wrap((req, res) => {
  const { selection, empId } = req.body;
  const hroRow = data.findHroRow(selection);
  if (!hroRow) throw new Error("Letter template not found");
  const emp = data.findEmployee(empId);
  if (!emp) throw new Error("Employee ID not found");
  const fields = data.letterFields(hroRow).filter((f) => !f.isSignatory);
  const title = data.titleFromGender(data.wdGet(emp, "Gender"));
  const out = fields.map((f) => {
    let value = "";
    let readonly = false;
    if (f.isEffectiveDate) { value = data.todayDDMMYYYY(); readonly = true; }
    else if (f.isTitle) { value = title; readonly = true; }
    else if (f.source === "WORKDAY") {
      const v = data.wdGet(emp, f.name);
      value = f.isDate || v instanceof Date ? data.ddmmyyyy(v) : String(v ?? "");
      const n = data.normalize(f.name);
      readonly = ["forename", "surname", "employeeid"].includes(n);
      if (v === undefined) value = "";
    }
    return { ...f, value, readonly };
  });
  res.json({ fields: out, hasSignatory: data.letterFields(hroRow).some((f) => f.isSignatory) });
}));

// ------------------------------------------------------- single generation
app.post("/api/generate/single", upload.single("signatory"), wrap(async (req, res) => {
  const s = data.requireSession();
  const payload = JSON.parse(req.body.payload);
  const { selection, empId, managerName, fieldValues, isPdf, passwordMode, customPassword } = payload;

  const hroRow = data.findHroRow(selection);
  if (!hroRow) throw new Error("Letter template not found");
  const emp = data.findEmployee(empId);
  if (!emp) throw new Error("Employee ID not found");

  // Validation: mandatory + date format
  const missing = [];
  const badDates = [];
  for (const [field, value] of Object.entries(fieldValues)) {
    const v = String(value ?? "").trim();
    if (!v) { missing.push(field); continue; }
    if (field.toLowerCase().includes("date") && !data.validDDMMYYYY(v)) badDates.push(field);
  }
  if (missing.length) throw new Error("Please fill all mandatory fields:\n" + missing.join(", "));
  if (badDates.length) throw new Error("These date fields must be DD-MM-YYYY:\n" + badDates.join(", "));

  // Auto title override
  const title = data.titleFromGender(data.wdGet(emp, "Gender"));
  const values = { ...fieldValues, "Ms. / Mr.": title, "Ms./Mr.": title, Title: title, Salutation: title };
  for (const key of Object.keys(values)) {
    if (["ms./mr.", "ms./mr", "title", "salutation"].includes(data.normalize(key))) values[key] = title;
  }

  const templatePath = path.join(s.paths.templateFolder, `${hroRow[cols.UNIQUE_TEMPLATE_COL]}.docx`);
  if (!fs.existsSync(templatePath)) throw new Error(`Template file not found:\n${templatePath}`);

  const stamp = timestamp();
  const entity = data.cleanFilename(hroRow[cols.ENTITY_COL]);
  const letterType = data.cleanFilename(hroRow[cols.LETTER_COL]);
  const empName = data.cleanFilename(`${data.wdGet(emp, "Forename") ?? ""} ${data.wdGet(emp, "Surname") ?? ""}`.trim());
  const baseName = `${entity}_${letterType}_${String(empId).trim()}_${empName}`;
  const managerFolder = path.join(s.paths.outputFolder, `Single_Output_${stamp}`, entity, String(managerName).trim());
  fs.mkdirSync(managerFolder, { recursive: true });

  const docxBuf = await renderDocx(templatePath, values, req.file ? req.file.path : null);

  let outFile;
  if (!isPdf) {
    outFile = path.join(managerFolder, `${baseName}.docx`);
    fs.writeFileSync(outFile, docxBuf);
  } else {
    let password;
    if (passwordMode === "system") password = data.systemPassword(emp);
    else {
      password = String(customPassword ?? "").trim();
      if (!password) throw new Error("Please enter a custom password");
    }
    const pdfBuf = await docxToPdf(docxBuf, password);
    outFile = path.join(managerFolder, `${baseName}.pdf`);
    fs.writeFileSync(outFile, pdfBuf);
  }
  if (req.file) fs.unlink(req.file.path, () => {});

  createLog({
    outputFile: outFile, empId, managerName,
    generationMode: "single", hroRow, passwordProtected: !!isPdf,
  });
  res.json({ ok: true, file: outFile });
}));

// ------------------------------------------------------------- bulk: template
app.post("/api/bulk/template", wrap((req, res) => {
  const hroRow = data.findHroRow(req.body);
  if (!hroRow) throw new Error("No letter template selected");
  const fields = bulkColumns(hroRow);
  if (fields.length === cols.MANDATORY_BULK_FIELDS.length) {
    throw new Error("No MANUAL fields found for this letter.");
  }
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([fields]), "Bulk Input");
  const buf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
  res.setHeader("Content-Disposition", 'attachment; filename="HELIX_Bulk_Input_Template.xlsx"');
  res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  res.send(buf);
}));

function bulkColumns(hroRow) {
  const s = data.requireSession();
  const fields = [...cols.MANDATORY_BULK_FIELDS];
  for (const col of s.dynamicFields) {
    const raw = hroRow[col];
    if (raw === "" || raw === null || raw === undefined) continue;
    const clean = String(raw).trim().toUpperCase();
    const norm = col.trim().toLowerCase().replace(/_/g, " ");
    if (clean === "NA" || clean === "WORKDAY") continue;
    if (norm === "signatory" || norm === "letter effective date") continue;
    if (clean.includes("MANUAL") && !fields.includes(col)) fields.push(col);
  }
  return fields;
}

// ------------------------------------------------------------ bulk: validate
app.post("/api/bulk/validate", upload.single("file"), wrap((req, res) => {
  const selection = JSON.parse(req.body.selection);
  const isPdf = req.body.isPdf === "true";
  const hroRow = data.findHroRow(selection);
  if (!hroRow) throw new Error("Letter template not found");

  const wb = XLSX.readFile(req.file.path, { cellDates: true });
  const sheet = wb.Sheets[wb.SheetNames[0]];
  const uploadedCols = (XLSX.utils.sheet_to_json(sheet, { header: 1 })[0] || []).map(String);
  const rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });

  const expected = bulkColumns(hroRow);
  const nExp = expected.map(data.normalize);
  const nUp = uploadedCols.map(data.normalize);
  const missing = expected.filter((c, i) => !nUp.includes(nExp[i]));
  const extra = uploadedCols.filter((c, i) => !nExp.includes(nUp[i]));
  const sameOrder = JSON.stringify(nExp) === JSON.stringify(nUp);
  if (!sameOrder) {
    fs.unlink(req.file.path, () => {});
    let msg = "Invalid template uploaded.\n\n";
    if (missing.length) msg += "Missing columns: " + missing.join(", ") + "\n";
    if (extra.length) msg += "Unexpected columns: " + extra.join(", ") + "\n";
    msg += "Please use the original downloaded template without any changes.";
    throw new Error(msg);
  }

  // Detect rows missing folder / password (uncategorized handling)
  const missingDetails = [];
  for (const row of rows) {
    const folder = String(row[cols.OUTPUT_FOLDER_COL] ?? "").trim();
    const pwd = String(row[cols.FOLDER_PASSWORD_COL] ?? "").trim();
    if (!folder || (isPdf && !pwd)) {
      const empId = String(row[cols.EMP_ID_COL] ?? "").trim();
      const emp = data.findEmployee(empId);
      const name = emp
        ? `${data.wdGet(emp, "Forename") ?? ""} ${data.wdGet(emp, "Surname") ?? ""}`.trim()
        : "Unknown Employee";
      missingDetails.push({ empId, name: name || empId });
    }
  }

  res.json({ ok: true, token: req.file.filename, rowCount: rows.length, missingDetails });
}));

// ------------------------------------------------------------ bulk: generate
app.post("/api/bulk/generate", upload.single("signatory"), wrap((req, res) => {
  const payload = JSON.parse(req.body.payload);
  const jobId = uuid();
  jobs.set(jobId, { percent: 0, status: "running", message: "Starting…", errors: [], zips: [], successCount: 0, done: false });
  runBulkJob(jobId, payload, req.file ? req.file.path : null).catch((e) => {
    const j = jobs.get(jobId);
    j.status = "error"; j.message = e.message; j.done = true;
  });
  res.json({ jobId });
}));

app.get("/api/bulk/progress/:jobId", (req, res) => {
  const j = jobs.get(req.params.jobId);
  if (!j) return res.status(404).json({ error: "Job not found" });
  res.json(j);
});

async function runBulkJob(jobId, payload, signatoryPath) {
  const s = data.requireSession();
  const job = jobs.get(jobId);
  const { selection, fileToken, isPdf, pdfPasswordEnabled, overrides } = payload;
  const hroRow = data.findHroRow(selection);
  if (!hroRow) throw new Error("Letter template not found");

  const bulkPath = path.join(__dirname, "..", "tmp_uploads", fileToken);
  if (!fs.existsSync(bulkPath)) throw new Error("Bulk template upload expired — please upload it again");
  const wb = XLSX.readFile(bulkPath, { cellDates: true });
  const rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { defval: "" });

  const stamp = timestamp();
  const runFolder = path.join(s.paths.outputFolder, `Bulk_Output_${stamp}`);
  const entity = data.cleanFilename(String(hroRow[cols.ENTITY_COL]).trim());
  const letterType = data.cleanFilename(String(hroRow[cols.LETTER_COL]).trim());
  const templatePath = path.join(s.paths.templateFolder, `${hroRow[cols.UNIQUE_TEMPLATE_COL]}.docx`);
  if (!fs.existsSync(templatePath)) throw new Error(`Template file not found:\n${templatePath}`);

  const zipBuckets = new Map(); // key: manager||folder -> {zipPath, files: [{name, buf}]}
  const errors = [];
  let success = 0;
  const total = rows.length || 1;
  let processed = 0;

  for (const row of rows) {
    processed++;
    job.percent = Math.round((processed / total) * (isPdf ? 50 : 90));
    job.message = `Creating documents (${processed}/${total})…`;
    try {
      const empId = String(row[cols.EMP_ID_COL] ?? "").trim();
      if (!empId) { errors.push("Blank Employee ID in bulk template"); continue; }
      const managerName = String(row["Manager Name"] ?? "").trim() || "Unknown Manager";

      const emp = data.findEmployee(empId);
      if (!emp) { errors.push(`${empId} – Employee ID not found in Workday file`); continue; }

      let folderName = String(row[cols.OUTPUT_FOLDER_COL] ?? "").trim();
      let folderPassword = String(row[cols.FOLDER_PASSWORD_COL] ?? "").trim();
      const ov = overrides && overrides[empId];
      if (ov) {
        folderName = ov.folderName || folderName;
        if (isPdf) folderPassword = ov.password || folderPassword;
      }
      if (!folderName) folderName = "Uncategorized";
      if (isPdf && pdfPasswordEnabled && !folderPassword) folderPassword = data.systemPassword(emp);

      // Validate WORKDAY fields
      const workdayValues = {};
      let wdError = null;
      for (const col of s.dynamicFields) {
        const raw = hroRow[col];
        if (raw === "" || raw === null || raw === undefined) continue;
        if (String(raw).trim().toUpperCase() !== "WORKDAY") continue;
        if (["ms./mr.", "ms./mr", "title", "salutation"].includes(data.normalize(col))) continue; // auto title
        const v = data.wdGet(emp, col);
        if (v === undefined) { wdError = `${col} column is missing from Workday file`; break; }
        if (v === null || String(v).trim() === "") { wdError = `${col} value is missing in Workday file for Employee ID ${empId}`; break; }
        workdayValues[col] = v instanceof Date ? data.ddmmyyyy(v) : String(v);
      }
      if (wdError) { errors.push(`${empId} – ${wdError}`); continue; }

      // Merge manual + workday values
      const values = {};
      for (const col of s.dynamicFields) {
        const raw = hroRow[col];
        if (raw === "" || raw === null || raw === undefined) continue;
        const clean = String(raw).trim().toUpperCase();
        if (clean === "NA") continue;
        const norm = col.trim().toLowerCase().replace(/_/g, " ");
        if (norm === "signatory") continue;
        if (norm === "letter effective date") { values[col] = data.todayDDMMYYYY(); continue; }
        if (["ms./mr.", "ms./mr", "title", "salutation"].includes(data.normalize(col))) continue; // auto title, set below
        if (clean === "WORKDAY") { values[col] = workdayValues[col] ?? ""; continue; }
        const v = row[col];
        if (v === "" || v === null || v === undefined) values[col] = "";
        else if (col.toLowerCase().includes("date")) values[col] = data.ddmmyyyy(v);
        else values[col] = String(v);
      }

      // Auto title
      const title = data.titleFromGender(data.wdGet(emp, "Gender"));
      Object.assign(values, { "Ms. / Mr.": title, "Ms./Mr.": title, Title: title, Salutation: title });
      for (const k of Object.keys(values)) {
        if (["ms./mr.", "ms./mr", "title", "salutation"].includes(data.normalize(k))) values[k] = title;
      }

      const empName = data.cleanFilename(`${data.wdGet(emp, "Forename") ?? ""} ${data.wdGet(emp, "Surname") ?? ""}`.trim());
      const baseName = `${entity}_${letterType}_${empId}_${empName}`;

      const docxBuf = await renderDocx(templatePath, values, signatoryPath);

      const managerFolder = path.join(runFolder, entity, data.cleanFilename(managerName));
      fs.mkdirSync(managerFolder, { recursive: true });
      const bucketKey = `${managerFolder}||${folderName}`;
      if (!zipBuckets.has(bucketKey)) {
        zipBuckets.set(bucketKey, {
          zipPath: path.join(managerFolder, `${data.cleanFilename(folderName)}.zip`),
          files: [],
        });
      }

      if (!isPdf) {
        zipBuckets.get(bucketKey).files.push({ name: `${baseName}.docx`, buf: docxBuf });
        createLog({ outputFile: `${baseName}.docx`, empId, managerName, generationMode: "bulk", hroRow, passwordProtected: false });
        success++;
      } else {
        job.message = `Converting to PDF (${processed}/${total})…`;
        const pdfBuf = await docxToPdf(docxBuf, pdfPasswordEnabled ? folderPassword : "");
        zipBuckets.get(bucketKey).files.push({ name: `${baseName}.pdf`, buf: pdfBuf });
        createLog({ outputFile: `${baseName}.pdf`, empId, managerName, generationMode: "bulk", hroRow, passwordProtected: !!pdfPasswordEnabled });
        success++;
        job.percent = 50 + Math.round((processed / total) * 40);
      }
    } catch (e) {
      errors.push(`${String(row[cols.EMP_ID_COL] ?? "?").trim()} – ${e.message}`);
    }
  }

  // Finalise zips
  job.message = "Packaging ZIP files…";
  job.percent = 95;
  const zips = [];
  for (const { zipPath, files } of zipBuckets.values()) {
    await writeZip(zipPath, files);
    zips.push(zipPath);
  }
  try { fs.unlinkSync(bulkPath); } catch (_) {}
  if (signatoryPath) { try { fs.unlinkSync(signatoryPath); } catch (_) {} }

  job.percent = 100;
  job.status = errors.length ? "completed_with_errors" : "completed";
  job.message = "Done";
  job.errors = errors;
  job.zips = zips;
  job.successCount = success;
  job.done = true;
}

function writeZip(zipPath, files) {
  return new Promise((resolve, reject) => {
    const out = fs.createWriteStream(zipPath);
    const archive = archiver("zip", { zlib: { level: 9 } });
    out.on("close", resolve);
    archive.on("error", reject);
    archive.pipe(out);
    for (const f of files) archive.append(f.buf, { name: f.name });
    archive.finalize();
  });
}

function timestamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

const PORT = process.env.PORT || 5001;
app.listen(PORT, () => {
  console.log(`HELIX API server running at http://localhost:${PORT}`);
});
