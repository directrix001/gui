const fs = require("fs");
const path = require("path");
const os = require("os");
const XLSX = require("xlsx");

// ------------- Column constants (mirrors the original app) -------------
const REGION_COL = "Region";
const ENTITY_COL = "Entity";
const CATEGORY_COL = "Grouping";
const LETTER_COL = "Original Letter Name";
const UNIQUE_TEMPLATE_COL = "Unique Letter Template Name";
const START_FIELD = "Forename";
const EMP_ID_COL = "Employee ID";
const OUTPUT_FOLDER_COL = "Output Folder Name";
const FOLDER_PASSWORD_COL = "Folder Password";
const MANDATORY_BULK_FIELDS = [EMP_ID_COL, "Manager Name", OUTPUT_FOLDER_COL, FOLDER_PASSWORD_COL];

const state = {
  userId: null,
  paths: null,
  hroRows: [],        // repository rows (Letter Data sheet)
  workdayRows: [],    // workday input rows
  workdayCols: [],
  dynamicFields: [],  // repository columns from "Forename" onward
};

function normalize(text) {
  return String(text ?? "").toLowerCase().replace(/_/g, "").replace(/\s+/g, "");
}

function currentUser() {
  try { return os.userInfo().username; } catch (_) { return "HELIX"; }
}

function resolveRoot() {
  if (process.env.HELIX_ROOT && process.env.HELIX_ROOT.trim()) {
    return process.env.HELIX_ROOT.trim();
  }
  // Same convention as the original tool, using the logged-in Windows user
  if (process.platform === "win32") {
    return path.join("C:\\Users", currentUser(), "OneDrive - Nissan Motor Corporation", "HELIX");
  }
  return path.join(os.homedir(), "OneDrive - Nissan Motor Corporation", "HELIX");
}

function buildPaths() {
  const root = resolveRoot();
  const db = path.join(root, "Database");
  return {
    root,
    hroFile: path.join(db, "All Templates Repository.xlsx"),
    workdayFile: path.join(db, "Workday Input.xlsx"),
    templateFolder: path.join(db, "Letter Template Docx"),
    outputFolder: path.join(root, "Output"),
    logFolder: path.join(root, "Generation Logs"),
  };
}

function sheetToRows(wb, sheetName) {
  const name = sheetName && wb.SheetNames.includes(sheetName) ? sheetName : wb.SheetNames[0];
  return XLSX.utils.sheet_to_json(wb.Sheets[name], { defval: "", raw: true });
}

function initSession() {
  const paths = buildPaths();
  if (!fs.existsSync(paths.hroFile)) {
    throw new Error(`Repository file not found:\n${paths.hroFile}`);
  }
  if (!fs.existsSync(paths.workdayFile)) {
    throw new Error(`Workday input file not found:\n${paths.workdayFile}`);
  }
  fs.mkdirSync(paths.outputFolder, { recursive: true });
  fs.mkdirSync(paths.logFolder, { recursive: true });

  const hroWb = XLSX.readFile(paths.hroFile, { cellDates: true });
  const hroRows = sheetToRows(hroWb, "Letter Data");
  const hroCols = XLSX.utils.sheet_to_json(hroWb.Sheets["Letter Data"] || hroWb.Sheets[hroWb.SheetNames[0]], { header: 1 })[0] || [];

  const startIdx = hroCols.findIndex((c) => String(c).trim() === START_FIELD);
  if (startIdx < 0) throw new Error(`Column "${START_FIELD}" not found in All Templates Repository.xlsx`);
  const dynamicFields = hroCols.slice(startIdx).map(String);

  const wdWb = XLSX.readFile(paths.workdayFile, { cellDates: true });
  const workdayRows = sheetToRows(wdWb);
  const workdayCols = Object.keys(workdayRows[0] || {});

  Object.assign(state, { userId: currentUser(), paths, hroRows, workdayRows, workdayCols, dynamicFields });
  return state;
}

function requireSession() {
  if (!state.paths) throw new Error("Data folder not loaded. Check HELIX_ROOT in backend/.env and restart.");
  return state;
}

// Tolerant column lookup on a workday row (the source file has columns like " Date of Birth")
function wdGet(row, colName) {
  if (colName in row) return row[colName];
  const want = normalize(colName);
  for (const k of Object.keys(row)) {
    if (normalize(k) === want) return row[k];
  }
  return undefined;
}

function findEmployee(empId) {
  const { workdayRows } = requireSession();
  const id = String(empId).trim();
  return workdayRows.find((r) => String(wdGet(r, EMP_ID_COL) ?? "").trim() === id) || null;
}

function findHroRow({ region, entity, category, letter }) {
  const { hroRows } = requireSession();
  return (
    hroRows.find(
      (r) =>
        String(r[REGION_COL]).trim() === String(region).trim() &&
        String(r[ENTITY_COL]).trim() === String(entity).trim() &&
        String(r[CATEGORY_COL]).trim() === String(category).trim() &&
        String(r[LETTER_COL]).trim() === String(letter).trim()
    ) || null
  );
}

// Field metadata for a selected letter template
function letterFields(hroRow) {
  const { dynamicFields } = requireSession();
  const fields = [];
  for (const col of dynamicFields) {
    const raw = hroRow[col];
    if (raw === "" || raw === null || raw === undefined) continue;
    const clean = String(raw).trim().toUpperCase();
    if (clean === "NA") continue;
    const norm = normalize(col);
    fields.push({
      name: col,
      source: clean.includes("MANUAL") ? "MANUAL" : clean === "WORKDAY" ? "WORKDAY" : clean,
      isSignatory: norm === "signatory",
      isEffectiveDate: col.trim().toLowerCase().replace(/_/g, " ") === "letter effective date",
      isDate: col.toLowerCase().includes("date"),
      isTitle: ["ms./mr.", "ms./mr", "title", "salutation"].includes(norm),
    });
  }
  return fields;
}

function titleFromGender(gender) {
  const g = String(gender ?? "").trim().toLowerCase();
  if (g === "male" || g === "m") return "Mr.";
  if (g === "female" || g === "f") return "Ms./Mrs.";
  return "";
}

function ddmmyyyy(value) {
  if (value === null || value === undefined || value === "") return "";
  // Already in DD-MM-YYYY? Keep it as typed (avoids MM/DD misparsing).
  if (typeof value === "string" && validDDMMYYYY(value)) return value.trim();
  let d = value;
  if (!(d instanceof Date)) {
    if (typeof d === "number") {
      // Excel serial date
      const parsed = XLSX.SSF.parse_date_code(d);
      if (parsed) d = new Date(parsed.y, parsed.m - 1, parsed.d);
    } else {
      const t = new Date(d);
      d = isNaN(t.getTime()) ? null : t;
    }
  }
  if (!(d instanceof Date) || isNaN(d.getTime())) return String(value);
  const p = (n) => String(n).padStart(2, "0");
  return `${p(d.getDate())}-${p(d.getMonth() + 1)}-${d.getFullYear()}`;
}

function todayDDMMYYYY() {
  return ddmmyyyy(new Date());
}

function validDDMMYYYY(s) {
  const m = /^(\d{2})-(\d{2})-(\d{4})$/.exec(String(s).trim());
  if (!m) return false;
  const [, dd, mm, yyyy] = m.map(Number);
  const d = new Date(yyyy, mm - 1, dd);
  return d.getFullYear() === yyyy && d.getMonth() === mm - 1 && d.getDate() === dd;
}

// System-generated password: first 4 letters of Forename (padded with X) + birth year
function systemPassword(employeeRow) {
  const first = String(wdGet(employeeRow, "Forename") ?? "").trim().replace(/\s+/g, "").toUpperCase();
  const firstFour = first.length >= 4 ? first.slice(0, 4) : first.padEnd(4, "X");
  const dob = wdGet(employeeRow, "Date of Birth");
  if (dob === undefined || dob === null || dob === "") {
    throw new Error("Date of Birth is missing in Workday Input.xlsx for this employee");
  }
  const formatted = ddmmyyyy(dob); // DD-MM-YYYY
  const year = formatted.slice(-4);
  if (!/^\d{4}$/.test(year)) throw new Error("Could not read a valid birth year from Workday Input.xlsx");
  return firstFour + year;
}

function cleanFilename(text) {
  return String(text).replace(/[\\/*?:"<>|]/g, "").trim();
}

module.exports = {
  state,
  initSession,
  requireSession,
  findEmployee,
  findHroRow,
  letterFields,
  titleFromGender,
  ddmmyyyy,
  todayDDMMYYYY,
  validDDMMYYYY,
  systemPassword,
  cleanFilename,
  normalize,
  wdGet,
  cols: {
    REGION_COL, ENTITY_COL, CATEGORY_COL, LETTER_COL, UNIQUE_TEMPLATE_COL,
    EMP_ID_COL, OUTPUT_FOLDER_COL, FOLDER_PASSWORD_COL, MANDATORY_BULK_FIELDS,
  },
};
