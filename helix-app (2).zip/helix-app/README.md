# HELIX — Human Experience Letter Information eXchange

An internal HR letter generation tool of **Nissan Motor Corporation**, rebuilt as a
local web app: **React (Vite)** frontend + **Node.js (Express)** backend.

It replicates the original desktop tool end-to-end:

- No sign-in — the data folder comes from `HELIX_ROOT` in `backend/.env` (or your OneDrive HELIX folder by default)
- Cascading letter selection: Region → Entity → Letter Category → Letter Template
- **Single generation**: employee lookup from `Workday Input.xlsx`, pre-filled Workday
  fields, manual fields with DD-MM-YYYY validation, auto title from gender
  (Mr. / Ms./Mrs.), auto Letter Effective Date, signatory image upload
- **Bulk generation**: download the input template (mandatory + MANUAL fields only),
  upload with strict column validation, missing folder/password ("Uncategorized")
  handling with per-employee overrides or Skip, per-folder ZIPs under
  `Entity / Manager`, live progress bar
- Output as **Word (.docx)** or **password-protected PDF** (system password =
  first 4 letters of forename + birth year, or a custom password)
- Excel generation log written to `Generation Logs/`

---

## 1. Prerequisites

| Requirement | Why | Notes |
|---|---|---|
| **Node.js 18+** | runs backend and frontend | https://nodejs.org |
| **LibreOffice** | Word → PDF conversion | Only needed for PDF output. Install from https://www.libreoffice.org and make sure `soffice` is on your PATH, or set `LIBREOFFICE_PATH` in `backend/.env` (on Windows this is typically `C:\Program Files\LibreOffice\program\soffice.exe`). Word output works without it. |

## 2. Install

Open two terminals (or run these one after the other):

```bash
cd backend
npm install
copy .env.example .env        # Windows  (use `cp` on macOS/Linux)
```

```bash
cd frontend
npm install
```

## 3. Point HELIX at your data

The backend expects the same folder structure as the original tool:

```
<HELIX root>/
├─ Database/
│  ├─ All Templates Repository.xlsx    (sheet "Letter Data")
│  ├─ Workday Input.xlsx
│  └─ Letter Template Docx/            (one .docx per Unique Letter Template Name)
├─ Output/                              (created automatically)
└─ Generation Logs/                     (created automatically)
```

**Option A — real data:** leave `HELIX_ROOT` empty in `backend/.env`. The path is
built automatically from your Windows username:
`C:\Users\<your Windows username>\OneDrive - Nissan Motor Corporation\HELIX`

**Option B — any local folder:** set `HELIX_ROOT` in `backend/.env` to the folder
that contains `Database/`.

**Option C — try it instantly with sample data:**

```bash
cd backend
node scripts/make-sample-data.js
```

This creates `backend/sample-data/HELIX` with a repository, three sample
employees (IDs `1001`, `1002`, `1003`), and two working letter templates, and
prints the exact `HELIX_ROOT` line to paste into `backend/.env`.

## 4. Run it

Terminal 1 — API server:

```bash
cd backend
npm start
```
→ `HELIX API server running at http://localhost:5001`

Terminal 2 — web app:

```bash
cd frontend
npm run dev
```
→ open **http://localhost:5173** in your browser.

The frontend proxies all `/api` calls to the backend, so nothing else needs configuring.

## 5. Using the app

1. **Welcome** — click *Let's get started* (the app loads the repository from your configured folder).
2. **Letter** — pick Region, Entity, Category, Template.
3. **Mode** — Single or Bulk.
4. **Single:** enter Employee ID + Manager Name → review/fill fields → upload
   signatory (optional) → choose Word or PDF (+ password option) → Generate.
5. **Bulk:** download template → fill → upload (validated strictly) → signatory →
   Word or PDF (+ password option) → fix any missing folder/password rows or
   Skip → watch the progress bar → done. ZIPs land in
   `Output/Bulk_Output_<timestamp>/<Entity>/<Manager>/<Folder>.zip`.

## 6. Placeholder conventions in templates

- `{{Field Name}}` placeholders (case-insensitive) — recommended
- Plain field names in text are also replaced (case-insensitive), matching the original tool
- Two-column tables where the left cell equals a field name get the value written into the right cell
- A paragraph containing the word `Signatory` is replaced with the uploaded
  signature image (1.8″ wide), or cleared if no image is uploaded

## 7. Troubleshooting

- **"Repository file not found"** — check `HELIX_ROOT` in `backend/.env`, or run the sample-data script.
- **PDF conversion fails** — install LibreOffice and/or set `LIBREOFFICE_PATH` in `backend/.env`, then restart the backend. Word output does not need LibreOffice.
- **Port already in use** — change `PORT` in `backend/.env` and the proxy target in `frontend/vite.config.js`.

---

© Nissan Motor Corporation — internal use.
