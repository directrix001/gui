import React, { useState } from "react";
import { api } from "../api.js";

export default function Welcome({ update, onStart }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const start = async () => {
    setBusy(true);
    setError("");
    try {
      const res = await api.session();
      update({ regions: res.regions, rootPath: res.paths.root });
      onStart();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="card">
      <div className="welcome">
        <div className="roundel-lg" aria-hidden="true"><span>HELIX</span></div>
        <h2>Welcome to HELIX</h2>
        <p className="lede">
          Generate employee letters — singly or in bulk — from approved Nissan
          templates, with Workday data, signatory images, and password-protected PDFs.
        </p>
        {error && <div className="alert error">{error}</div>}
        <button className="btn primary" onClick={start} disabled={busy}>
          {busy ? "Loading data…" : "Let's get started"}
        </button>
      </div>
    </div>
  );
}
