import React, { useState } from "react";
import Welcome from "./steps/Welcome.jsx";
import TemplateSelect from "./steps/TemplateSelect.jsx";
import ModeSelect from "./steps/ModeSelect.jsx";
import { EmployeeStep, FieldsStep, SingleOutputStep } from "./steps/SingleFlow.jsx";
import { BulkTemplateStep, BulkSignatoryStep, BulkOutputStep, UncategorizedStep, BulkProgressStep } from "./steps/BulkFlow.jsx";
import Done from "./steps/Done.jsx";

const RAIL = [
  { key: "welcome", label: "Welcome" },
  { key: "template", label: "Letter" },
  { key: "mode", label: "Mode" },
  { key: "details", label: "Details" },
  { key: "output", label: "Output" },
  { key: "done", label: "Done" },
];

const railIndex = (step) => {
  const map = {
    welcome: 0, template: 1, mode: 2,
    employee: 3, fields: 3, bulkTemplate: 3, bulkSignatory: 3,
    singleOutput: 4, bulkOutput: 4, uncategorized: 4, bulkProgress: 4,
    done: 5,
  };
  return map[step] ?? 0;
};

export default function App() {
  const [step, setStep] = useState("welcome");
  const [ctx, setCtx] = useState({
    regions: [],
    selection: null,       // { region, entity, category, letter }
    mode: "single",
    // single flow
    empId: "",
    managerName: "",
    fields: [],
    hasSignatory: false,
    signatoryFile: null,
    // bulk flow
    bulkToken: null,
    bulkMissing: [],
    bulkIsPdf: true,
    overrides: {},
    // result
    result: null,
  });

  const update = (patch) => setCtx((c) => ({ ...c, ...patch }));
  const go = (s) => setStep(s);
  const active = railIndex(step);

  const steps = {
    welcome: <Welcome update={update} onStart={() => go("template")} />,
    template: (
      <TemplateSelect ctx={ctx} update={update}
        onBack={() => go("welcome")} onNext={() => go("mode")} />
    ),
    mode: (
      <ModeSelect ctx={ctx} update={update} onBack={() => go("template")}
        onNext={(mode) => go(mode === "single" ? "employee" : "bulkTemplate")} />
    ),
    employee: (
      <EmployeeStep ctx={ctx} update={update}
        onBack={() => go("mode")} onNext={() => go("fields")} />
    ),
    fields: (
      <FieldsStep ctx={ctx} update={update}
        onBack={() => go("employee")} onNext={() => go("singleOutput")} />
    ),
    singleOutput: (
      <SingleOutputStep ctx={ctx} update={update}
        onBack={() => go("fields")} onDone={(result) => { update({ result }); go("done"); }} />
    ),
    bulkTemplate: (
      <BulkTemplateStep ctx={ctx} update={update}
        onBack={() => go("mode")} onNext={() => go("bulkSignatory")} />
    ),
    bulkSignatory: (
      <BulkSignatoryStep ctx={ctx} update={update}
        onBack={() => go("bulkTemplate")} onNext={() => go("bulkOutput")} />
    ),
    bulkOutput: (
      <BulkOutputStep ctx={ctx} update={update} onBack={() => go("bulkSignatory")}
        onNext={(needsUncat) => go(needsUncat ? "uncategorized" : "bulkProgress")} />
    ),
    uncategorized: (
      <UncategorizedStep ctx={ctx} update={update}
        onBack={() => go("bulkOutput")} onNext={() => go("bulkProgress")} />
    ),
    bulkProgress: (
      <BulkProgressStep ctx={ctx}
        onDone={(result) => { update({ result }); go("done"); }} />
    ),
    done: <Done ctx={ctx} onRestart={() => window.location.reload()} />,
  };

  return (
    <div className="shell">
      <header className="topbar">
        <div className="mark">
          <div className="roundel" aria-hidden="true">N</div>
          <div>
            <h1>HELIX</h1>
            <div className="sub">Human Experience Letter Information eXchange</div>
          </div>
        </div>
        <div className="spacer" />
        <div className="session">
          Nissan Motor Corporation
        </div>
      </header>

      <nav className="rail" aria-label="Progress">
        {RAIL.map((s, i) => (
          <div key={s.key}
            className={"step" + (i === active ? " active" : i < active ? " done" : "")}>
            {s.label}
          </div>
        ))}
      </nav>

      <main className="main">{steps[step]}</main>

      <footer className="footer">
        <b>HELIX</b> · An internal HR letter generation tool of <b>Nissan Motor Corporation</b>
      </footer>
    </div>
  );
}
