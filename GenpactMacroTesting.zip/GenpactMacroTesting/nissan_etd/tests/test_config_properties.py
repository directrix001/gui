"""Property-based tests for ConfigManager using Hypothesis.

Validates correctness properties for configuration loading with environment
variable overrides and configuration validation error reporting.
"""

import os
import tempfile

import yaml
from hypothesis import given, settings, assume
from hypothesis import strategies as st

import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from config_manager import ConfigManager, ConfigError


# --- Strategies ---

# Strategy for valid config key segments (lowercase alphanumeric, no double underscores)
key_segment_st = st.from_regex(r"[a-z][a-z0-9_]{0,15}", fullmatch=True).filter(
    lambda s: "__" not in s and s.strip("_") == s
)

# Strategy for config values (non-empty strings)
config_value_st = st.text(
    alphabet=st.characters(whitelist_categories=("L", "N", "P", "S"),
                           blacklist_characters="\x00"),
    min_size=1,
    max_size=50,
)


# --- Property 1: Configuration loading with environment override ---
# Feature: bluezone-macro-to-python, Property 1: Configuration loading with environment override
# **Validates: Requirements 1.1, 1.2**

@given(
    section=key_segment_st,
    key=key_segment_st,
    yaml_value=config_value_st,
    env_value=config_value_st,
)
@settings(max_examples=100)
def test_env_override_takes_precedence_over_yaml(section, key, yaml_value, env_value):
    """For any config key present in a YAML file, if a corresponding env var
    (NISSAN_ETD__ prefix, double underscore nesting) is set, ConfigManager.get()
    returns the env var value."""
    # Ensure env_value differs from yaml_value so override is meaningful
    assume(env_value != yaml_value)

    # Build a YAML config with the key
    config_data = {section: {key: yaml_value}}

    # Build the environment variable name: NISSAN_ETD__{SECTION}__{KEY}
    env_var_name = f"NISSAN_ETD__{section.upper()}__{key.upper()}"

    # Write YAML to a temp file
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".yaml", delete=False, encoding="utf-8"
    ) as f:
        yaml.dump(config_data, f)
        tmp_path = f.name

    try:
        # Set the environment variable
        os.environ[env_var_name] = env_value
        try:
            mgr = ConfigManager(tmp_path)
            dotted_key = f"{section}.{key}"
            result = mgr.get(dotted_key)
            assert result == env_value, (
                f"Expected env override '{env_value}' for key '{dotted_key}', "
                f"got '{result}'"
            )
        finally:
            # Clean up env var
            del os.environ[env_var_name]
    finally:
        os.unlink(tmp_path)


@given(
    section=key_segment_st,
    key=key_segment_st,
    yaml_value=config_value_st,
)
@settings(max_examples=100)
def test_yaml_value_returned_when_no_env_override(section, key, yaml_value):
    """For any config key present in a YAML file, if no corresponding env var
    is set, ConfigManager.get() returns the YAML file value."""
    config_data = {section: {key: yaml_value}}

    # Ensure the env var is NOT set
    env_var_name = f"NISSAN_ETD__{section.upper()}__{key.upper()}"

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".yaml", delete=False, encoding="utf-8"
    ) as f:
        yaml.dump(config_data, f)
        tmp_path = f.name

    try:
        # Remove env var if it happens to exist
        os.environ.pop(env_var_name, None)

        mgr = ConfigManager(tmp_path)
        dotted_key = f"{section}.{key}"
        result = mgr.get(dotted_key)
        assert result == yaml_value, (
            f"Expected YAML value '{yaml_value}' for key '{dotted_key}', "
            f"got '{result}'"
        )
    finally:
        os.unlink(tmp_path)


# --- Property 2: Configuration validation rejects incomplete configs ---
# Feature: bluezone-macro-to-python, Property 2: Configuration validation rejects incomplete configs
# **Validates: Requirements 1.3**

@given(
    keys_to_include=st.lists(
        st.sampled_from(ConfigManager.REQUIRED_KEYS),
        min_size=0,
        max_size=len(ConfigManager.REQUIRED_KEYS) - 1,
        unique=True,
    )
)
@settings(max_examples=100)
def test_validate_raises_config_error_listing_all_missing_keys(keys_to_include):
    """For any config dict missing at least one required key from
    ConfigManager.REQUIRED_KEYS, calling validate() raises ConfigError whose
    message contains the name of every missing key."""
    # Build a config that only includes a subset of required keys
    config_data = {}
    for dotted_key in keys_to_include:
        parts = dotted_key.split(".")
        current = config_data
        for part in parts[:-1]:
            current = current.setdefault(part, {})
        current[parts[-1]] = "test_value"

    # Determine which keys are missing
    missing_keys = set(ConfigManager.REQUIRED_KEYS) - set(keys_to_include)
    # There must be at least one missing key (max_size ensures this)
    assume(len(missing_keys) > 0)

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".yaml", delete=False, encoding="utf-8"
    ) as f:
        yaml.dump(config_data, f)
        tmp_path = f.name

    # Clean any NISSAN_ETD__ env vars that could interfere
    env_vars_to_restore = {}
    for env_key in list(os.environ.keys()):
        if env_key.startswith("NISSAN_ETD__"):
            env_vars_to_restore[env_key] = os.environ.pop(env_key)

    try:
        mgr = ConfigManager(tmp_path)

        try:
            mgr.validate()
            # Should not reach here
            assert False, (
                f"validate() did not raise ConfigError. "
                f"Missing keys: {missing_keys}"
            )
        except ConfigError as e:
            error_message = str(e)
            # Every missing key name must appear in the error message
            for missing_key in missing_keys:
                assert missing_key in error_message, (
                    f"Missing key '{missing_key}' not found in error message: "
                    f"'{error_message}'"
                )
    finally:
        os.unlink(tmp_path)
        # Restore env vars
        for env_key, env_val in env_vars_to_restore.items():
            os.environ[env_key] = env_val


@given(
    extra_values=st.fixed_dictionaries({
        key: config_value_st for key in ConfigManager.REQUIRED_KEYS
    })
)
@settings(max_examples=100)
def test_validate_passes_when_all_required_keys_present(extra_values):
    """For any config dict containing all required keys, validate() does not
    raise ConfigError."""
    # Build a config with all required keys present
    config_data = {}
    for dotted_key, value in extra_values.items():
        parts = dotted_key.split(".")
        current = config_data
        for part in parts[:-1]:
            current = current.setdefault(part, {})
        current[parts[-1]] = value

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".yaml", delete=False, encoding="utf-8"
    ) as f:
        yaml.dump(config_data, f)
        tmp_path = f.name

    # Clean any NISSAN_ETD__ env vars that could interfere
    env_vars_to_restore = {}
    for env_key in list(os.environ.keys()):
        if env_key.startswith("NISSAN_ETD__"):
            env_vars_to_restore[env_key] = os.environ.pop(env_key)

    try:
        mgr = ConfigManager(tmp_path)
        # Should not raise
        mgr.validate()
    finally:
        os.unlink(tmp_path)
        # Restore env vars
        for env_key, env_val in env_vars_to_restore.items():
            os.environ[env_key] = env_val
