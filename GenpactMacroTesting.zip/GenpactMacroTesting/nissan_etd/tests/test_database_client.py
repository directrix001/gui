"""Unit tests for DatabaseClient.

Requirements: 2.4, 2.5, 2.6
"""

from unittest.mock import MagicMock, patch, PropertyMock

import pytest
import pyodbc

from src.database_client import DatabaseClient, DatabaseError


class TestConnectionFailure:
    """Test that connection failure raises DatabaseError with details."""

    @patch("src.database_client.pyodbc.connect")
    def test_connection_error_raises_database_error(self, mock_connect):
        """DatabaseError is raised with details when pyodbc.connect fails."""
        mock_connect.side_effect = pyodbc.Error("HY000", "Could not connect to server")

        with pytest.raises(DatabaseError) as exc_info:
            DatabaseClient("Driver={SQL Server};Server=bad_host")

        assert "Failed to connect" in str(exc_info.value)
        assert "Could not connect to server" in str(exc_info.value)

    @patch("src.database_client.pyodbc.connect")
    def test_connection_error_preserves_original_exception(self, mock_connect):
        """DatabaseError chains the original pyodbc.Error as __cause__."""
        original_error = pyodbc.Error("08001", "Network error")
        mock_connect.side_effect = original_error

        with pytest.raises(DatabaseError) as exc_info:
            DatabaseClient("Driver={ODBC};Server=unreachable")

        assert exc_info.value.__cause__ is original_error


class TestQueryFailureRollback:
    """Test that query failure triggers rollback and raises DatabaseError."""

    @patch("src.database_client.pyodbc.connect")
    def test_execute_query_rolls_back_on_failure(self, mock_connect):
        """Rollback is called on the connection when execute_query fails."""
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_cursor.execute.side_effect = pyodbc.Error("42S02", "Table not found")
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn

        client = DatabaseClient("Driver={SQL Server};Server=localhost")

        with pytest.raises(DatabaseError) as exc_info:
            client.execute_query("SELECT * FROM missing_table")

        mock_conn.rollback.assert_called_once()
        assert "missing_table" in str(exc_info.value)
        assert "Table not found" in str(exc_info.value)

    @patch("src.database_client.pyodbc.connect")
    def test_execute_query_raises_database_error_on_failure(self, mock_connect):
        """DatabaseError is raised when the query execution encounters an error."""
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_cursor.execute.side_effect = pyodbc.Error("HY000", "Syntax error")
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn

        client = DatabaseClient("Driver={SQL Server};Server=localhost")

        with pytest.raises(DatabaseError):
            client.execute_query("INVALID SQL")


class TestExecuteQueryReturnsDicts:
    """Test that execute_query returns correct list-of-dicts structure."""

    @patch("src.database_client.pyodbc.connect")
    def test_returns_list_of_dicts_with_column_names(self, mock_connect):
        """execute_query maps rows to dicts using column names as keys."""
        mock_conn = MagicMock()
        mock_cursor = MagicMock()

        # Simulate cursor.description with column metadata
        mock_cursor.description = [
            ("part_number", None, None, None, None, None, None),
            ("quantity", None, None, None, None, None, None),
            ("status", None, None, None, None, None, None),
        ]
        # Simulate fetchall returning row tuples
        mock_cursor.fetchall.return_value = [
            ("ABC123", 10, "Active"),
            ("DEF456", 5, "Pending"),
        ]
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn

        client = DatabaseClient("Driver={SQL Server};Server=localhost")
        results = client.execute_query("SELECT part_number, quantity, status FROM parts")

        assert len(results) == 2
        assert results[0] == {"part_number": "ABC123", "quantity": 10, "status": "Active"}
        assert results[1] == {"part_number": "DEF456", "quantity": 5, "status": "Pending"}

    @patch("src.database_client.pyodbc.connect")
    def test_returns_empty_list_for_no_rows(self, mock_connect):
        """execute_query returns an empty list when no rows are returned."""
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_cursor.description = [("id", None, None, None, None, None, None)]
        mock_cursor.fetchall.return_value = []
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn

        client = DatabaseClient("Driver={SQL Server};Server=localhost")
        results = client.execute_query("SELECT id FROM empty_table")

        assert results == []


class TestStoredProcedureParameterPassing:
    """Test stored procedure parameter passing with mocked pyodbc."""

    @patch("src.database_client.pyodbc.connect")
    def test_stored_proc_uses_call_syntax_with_placeholders(self, mock_connect):
        """execute_stored_proc uses {CALL proc (?, ...)} format with params tuple."""
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_cursor.description = None  # No result set
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn

        client = DatabaseClient("Driver={SQL Server};Server=localhost")
        params = {"dealer_id": "D001", "part": "ABC123", "qty": 10}
        client.execute_stored_proc("sp_update_etd", params)

        # Verify the SQL uses {CALL} syntax with correct number of placeholders
        call_args = mock_cursor.execute.call_args
        sql_used = call_args[0][0]
        params_used = call_args[0][1]

        assert sql_used == "{CALL sp_update_etd (?, ?, ?)}"
        assert params_used == ("D001", "ABC123", 10)

    @patch("src.database_client.pyodbc.connect")
    def test_stored_proc_without_params(self, mock_connect):
        """execute_stored_proc uses {CALL proc} syntax when no params given."""
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_cursor.description = None
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn

        client = DatabaseClient("Driver={SQL Server};Server=localhost")
        client.execute_stored_proc("sp_refresh_cache")

        call_args = mock_cursor.execute.call_args
        sql_used = call_args[0][0]

        assert sql_used == "{CALL sp_refresh_cache}"

    @patch("src.database_client.pyodbc.connect")
    def test_stored_proc_returns_result_set(self, mock_connect):
        """execute_stored_proc returns list of dicts when procedure has results."""
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_cursor.description = [
            ("name", None, None, None, None, None, None),
            ("value", None, None, None, None, None, None),
        ]
        mock_cursor.fetchall.return_value = [("setting1", "val1")]
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn

        client = DatabaseClient("Driver={SQL Server};Server=localhost")
        result = client.execute_stored_proc("sp_get_settings", {"category": "etd"})

        assert result == [{"name": "setting1", "value": "val1"}]


class TestExecuteActionCommit:
    """Test that execute_action commits on success."""

    @patch("src.database_client.pyodbc.connect")
    def test_commit_called_on_successful_action(self, mock_connect):
        """Connection.commit() is called after a successful execute_action."""
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_cursor.rowcount = 3
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn

        client = DatabaseClient("Driver={SQL Server};Server=localhost")
        affected = client.execute_action(
            "UPDATE parts SET status = ? WHERE dealer = ?",
            ("Active", "D001"),
        )

        mock_conn.commit.assert_called_once()
        assert affected == 3

    @patch("src.database_client.pyodbc.connect")
    def test_returns_affected_row_count(self, mock_connect):
        """execute_action returns the number of affected rows."""
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_cursor.rowcount = 7
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn

        client = DatabaseClient("Driver={SQL Server};Server=localhost")
        affected = client.execute_action("DELETE FROM temp_data WHERE expired = 1")

        assert affected == 7


class TestExecuteActionRollback:
    """Test that execute_action rolls back on failure."""

    @patch("src.database_client.pyodbc.connect")
    def test_rollback_called_on_failure(self, mock_connect):
        """Connection.rollback() is called when execute_action fails."""
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_cursor.execute.side_effect = pyodbc.Error("23000", "Constraint violation")
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn

        client = DatabaseClient("Driver={SQL Server};Server=localhost")

        with pytest.raises(DatabaseError):
            client.execute_action(
                "INSERT INTO parts (id) VALUES (?)", ("duplicate_id",)
            )

        mock_conn.rollback.assert_called_once()

    @patch("src.database_client.pyodbc.connect")
    def test_commit_not_called_on_failure(self, mock_connect):
        """Connection.commit() is NOT called when execute_action fails."""
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_cursor.execute.side_effect = pyodbc.Error("HY000", "Disk full")
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn

        client = DatabaseClient("Driver={SQL Server};Server=localhost")

        with pytest.raises(DatabaseError):
            client.execute_action("INSERT INTO logs (msg) VALUES (?)", ("test",))

        mock_conn.commit.assert_not_called()

    @patch("src.database_client.pyodbc.connect")
    def test_database_error_raised_with_details(self, mock_connect):
        """DatabaseError message includes failure context."""
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_cursor.execute.side_effect = pyodbc.Error("22001", "String truncated")
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn

        client = DatabaseClient("Driver={SQL Server};Server=localhost")

        with pytest.raises(DatabaseError) as exc_info:
            client.execute_action("UPDATE t SET col = ?", ("x" * 500,))

        assert "Action failed" in str(exc_info.value)
        assert "String truncated" in str(exc_info.value)


class TestContextManagerClosesConnection:
    """Test that the context manager closes the connection on exit."""

    @patch("src.database_client.pyodbc.connect")
    def test_connection_closed_on_context_exit(self, mock_connect):
        """Connection.close() is called when exiting the with block."""
        mock_conn = MagicMock()
        mock_connect.return_value = mock_conn

        with DatabaseClient("Driver={SQL Server};Server=localhost") as client:
            pass  # use the client within the context

        mock_conn.close.assert_called_once()

    @patch("src.database_client.pyodbc.connect")
    def test_connection_closed_even_on_exception(self, mock_connect):
        """Connection.close() is called even when an exception occurs inside the with block."""
        mock_conn = MagicMock()
        mock_connect.return_value = mock_conn

        with pytest.raises(ValueError):
            with DatabaseClient("Driver={SQL Server};Server=localhost") as client:
                raise ValueError("something went wrong")

        mock_conn.close.assert_called_once()

    @patch("src.database_client.pyodbc.connect")
    def test_context_manager_returns_client_instance(self, mock_connect):
        """The context manager yields the DatabaseClient instance itself."""
        mock_conn = MagicMock()
        mock_connect.return_value = mock_conn

        with DatabaseClient("Driver={SQL Server};Server=localhost") as client:
            assert isinstance(client, DatabaseClient)
