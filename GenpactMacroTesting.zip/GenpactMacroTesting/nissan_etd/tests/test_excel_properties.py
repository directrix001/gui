"""Property-based tests for ExcelHandler.

# Feature: bluezone-macro-to-python, Property 5: Excel write-then-read round trip
# Feature: bluezone-macro-to-python, Property 6: ETD data reading with stop condition
"""

import os
import tempfile

from hypothesis import given, settings, strategies as st
from openpyxl import Workbook

from src.excel_handler import ETDRecord, ExcelHandler


# --- Strategies ---

# Strategy for cell values that round-trip cleanly through openpyxl
cell_value_st = st.one_of(
    st.text(
        alphabet=st.characters(blacklist_categories=("Cs",)),
        min_size=1,
        max_size=50,
    ),
    st.integers(min_value=-1_000_000, max_value=1_000_000),
    st.floats(allow_nan=False, allow_infinity=False, min_value=-1e6, max_value=1e6),
)

# Strategy for a single record tuple (1-5 columns of cell values)
record_tuple_st = st.tuples(cell_value_st, cell_value_st, cell_value_st)

# Strategy for a list of record tuples (1-20 records)
records_list_st = st.lists(record_tuple_st, min_size=1, max_size=20)

# Strategy for non-empty part number strings (no whitespace-only)
part_number_st = st.text(
    alphabet=st.characters(
        whitelist_categories=("L", "N"),
        whitelist_characters="-_",
    ),
    min_size=1,
    max_size=20,
)

# Strategy for ETD date strings
etd_date_st = st.text(
    alphabet=st.characters(whitelist_categories=("N",)),
    min_size=6,
    max_size=6,
)

# Strategy for quantity strings
quantity_st = st.text(
    alphabet=st.characters(whitelist_categories=("N",)),
    min_size=1,
    max_size=5,
)

# Strategy for a single ETD data row (part_number, etd_date, quantity)
etd_row_st = st.tuples(part_number_st, etd_date_st, quantity_st)

# Strategy for K data rows (1-15 rows)
etd_rows_st = st.lists(etd_row_st, min_size=1, max_size=15)


def _create_temp_workbook(sheet_name: str = "Sheet1") -> str:
    """Create a temporary xlsx file with one named sheet, return its path."""
    fd, path = tempfile.mkstemp(suffix=".xlsx")
    os.close(fd)
    wb = Workbook()
    ws = wb.active
    ws.title = sheet_name
    wb.save(path)
    wb.close()
    return path


# --- Property 5: Excel write-then-read round trip ---
# For any list of N record tuples written to a worksheet via write_records(),
# reading back from the same cells yields the same N records with identical values.


# Feature: bluezone-macro-to-python, Property 5: Excel write-then-read round trip
@given(records=records_list_st)
@settings(max_examples=100)
def test_write_then_read_round_trip(records: list[tuple]) -> None:
    """
    **Validates: Requirements 3.2, 3.3**

    Writing N record tuples then reading back the same cells yields
    the same N records with identical values.
    """
    sheet_name = "Sheet1"
    path = _create_temp_workbook(sheet_name)

    try:
        # Write records using ExcelHandler
        handler = ExcelHandler(path)
        handler.write_records(sheet_name, records, start_row=1, start_col=1)
        handler.save()
        handler.close()

        # Read back using ExcelHandler (via openpyxl directly for verification)
        handler2 = ExcelHandler(path)
        ws = handler2.get_sheet(sheet_name)

        read_back = []
        for row_idx in range(1, len(records) + 1):
            row_values = []
            for col_idx in range(1, len(records[0]) + 1):
                row_values.append(ws.cell(row=row_idx, column=col_idx).value)
            read_back.append(tuple(row_values))

        handler2.close()

        # Assert same number of records
        assert len(read_back) == len(records), (
            f"Expected {len(records)} records, got {len(read_back)}"
        )

        # Assert each record matches
        for i, (written, read) in enumerate(zip(records, read_back)):
            for j, (w_val, r_val) in enumerate(zip(written, read)):
                if isinstance(w_val, float):
                    assert abs(w_val - r_val) < 1e-10, (
                        f"Row {i}, Col {j}: wrote {w_val}, read {r_val}"
                    )
                else:
                    assert w_val == r_val, (
                        f"Row {i}, Col {j}: wrote {w_val!r}, read {r_val!r}"
                    )
    finally:
        os.unlink(path)


# --- Property 6: ETD data reading with stop condition ---
# For any worksheet with K data rows (starting row 2) followed by a row
# with an empty part_number cell, read_etd_data() returns exactly K
# ETDRecord objects.


# Feature: bluezone-macro-to-python, Property 6: ETD data reading with stop condition
@given(rows=etd_rows_st)
@settings(max_examples=100)
def test_read_etd_data_stop_condition(rows: list[tuple]) -> None:
    """
    **Validates: Requirements 3.4, 3.5**

    For K data rows starting at row 2, followed by an empty part_number
    cell, read_etd_data() returns exactly K ETDRecord objects with correct
    values.
    """
    sheet_name = "Sheet1"
    path = _create_temp_workbook(sheet_name)

    try:
        # Set up the workbook with K data rows starting at row 2
        wb = Workbook()
        ws = wb.active
        ws.title = sheet_name

        # Optional header in row 1
        ws.cell(row=1, column=1).value = "Part Number"
        ws.cell(row=1, column=2).value = "ETD Date"
        ws.cell(row=1, column=3).value = "Quantity"

        # Write K data rows starting at row 2
        for i, (part_number, etd_date, quantity) in enumerate(rows):
            ws.cell(row=2 + i, column=1).value = part_number
            ws.cell(row=2 + i, column=2).value = etd_date
            ws.cell(row=2 + i, column=3).value = quantity

        # Row K+2 has empty part_number (stop condition)
        # openpyxl cells default to None, so just leave it empty
        ws.cell(row=2 + len(rows), column=1).value = None

        wb.save(path)
        wb.close()

        # Read using ExcelHandler
        handler = ExcelHandler(path)
        records = handler.read_etd_data(sheet_name)
        handler.close()

        # Assert exactly K records returned
        assert len(records) == len(rows), (
            f"Expected {len(rows)} records, got {len(records)}"
        )

        # Assert each record has correct values
        for i, (record, (part_number, etd_date, quantity)) in enumerate(
            zip(records, rows)
        ):
            assert isinstance(record, ETDRecord)
            assert record.row == 2 + i, (
                f"Record {i}: expected row {2 + i}, got {record.row}"
            )
            assert record.part_number == part_number, (
                f"Record {i}: expected part_number {part_number!r}, "
                f"got {record.part_number!r}"
            )
            assert record.etd_date == etd_date, (
                f"Record {i}: expected etd_date {etd_date!r}, "
                f"got {record.etd_date!r}"
            )
            assert record.quantity == quantity, (
                f"Record {i}: expected quantity {quantity!r}, "
                f"got {record.quantity!r}"
            )
    finally:
        os.unlink(path)
