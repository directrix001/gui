"""Unit tests for ExcelHandler.

Tests cover file-not-found, invalid sheet name, write_records,
clear_range, read_etd_data stop condition, value-to-string conversion,
and write_status.
"""

import os
import tempfile

import pytest
from openpyxl import Workbook

from src.excel_handler import ETDRecord, ExcelError, ExcelHandler


class TestFileNotFound:
    """Test file-not-found raises ExcelError with path."""

    def test_nonexistent_path_raises_excel_error(self):
        bad_path = os.path.join(tempfile.gettempdir(), "nonexistent_workbook.xlsx")
        with pytest.raises(ExcelError, match=bad_path.replace("\\", "\\\\")):
            ExcelHandler(bad_path)


class TestInvalidSheetName:
    """Test invalid sheet name raises ExcelError listing available sheets."""

    def test_invalid_sheet_lists_available(self, tmp_path):
        wb = Workbook()
        wb.active.title = "Data"
        wb.create_sheet("Summary")
        file_path = str(tmp_path / "test.xlsx")
        wb.save(file_path)
        wb.close()

        handler = ExcelHandler(file_path)
        with pytest.raises(ExcelError) as exc_info:
            handler.get_sheet("NonExistent")

        error_msg = str(exc_info.value)
        assert "NonExistent" in error_msg
        assert "Data" in error_msg
        assert "Summary" in error_msg
        handler.close()


class TestWriteRecords:
    """Test write_records writes data correctly."""

    def test_write_records_populates_cells(self, tmp_path):
        wb = Workbook()
        wb.active.title = "Sheet1"
        file_path = str(tmp_path / "test.xlsx")
        wb.save(file_path)
        wb.close()

        handler = ExcelHandler(file_path)
        records = [
            ("ABC123", "010124", "5"),
            ("DEF456", "150224", "10"),
        ]
        handler.write_records("Sheet1", records, start_row=1, start_col=1)
        handler.save()
        handler.close()

        # Re-open and verify
        handler2 = ExcelHandler(file_path)
        ws = handler2.get_sheet("Sheet1")
        assert ws.cell(row=1, column=1).value == "ABC123"
        assert ws.cell(row=1, column=2).value == "010124"
        assert ws.cell(row=1, column=3).value == "5"
        assert ws.cell(row=2, column=1).value == "DEF456"
        assert ws.cell(row=2, column=2).value == "150224"
        assert ws.cell(row=2, column=3).value == "10"
        handler2.close()


class TestClearRange:
    """Test clear_range clears content."""

    def test_clear_range_sets_cells_to_none(self, tmp_path):
        wb = Workbook()
        ws = wb.active
        ws.title = "Sheet1"
        # Write some data
        ws.cell(row=1, column=1).value = "A"
        ws.cell(row=1, column=2).value = "B"
        ws.cell(row=2, column=1).value = "C"
        ws.cell(row=2, column=2).value = "D"
        file_path = str(tmp_path / "test.xlsx")
        wb.save(file_path)
        wb.close()

        handler = ExcelHandler(file_path)
        handler.clear_range("Sheet1", start_row=1, start_col=1, end_row=2, end_col=2)
        handler.save()
        handler.close()

        # Re-open and verify cells are None
        handler2 = ExcelHandler(file_path)
        ws = handler2.get_sheet("Sheet1")
        assert ws.cell(row=1, column=1).value is None
        assert ws.cell(row=1, column=2).value is None
        assert ws.cell(row=2, column=1).value is None
        assert ws.cell(row=2, column=2).value is None
        handler2.close()


class TestReadEtdDataStopsAtEmptyPartNumber:
    """Test read_etd_data stops at empty part_number."""

    def test_stops_at_empty_row(self, tmp_path):
        wb = Workbook()
        ws = wb.active
        ws.title = "ETD"
        # Header row (row 1)
        ws.cell(row=1, column=1).value = "Part Number"
        ws.cell(row=1, column=2).value = "ETD Date"
        ws.cell(row=1, column=3).value = "Quantity"
        # 3 data rows
        ws.cell(row=2, column=1).value = "PART001"
        ws.cell(row=2, column=2).value = "010124"
        ws.cell(row=2, column=3).value = "5"
        ws.cell(row=3, column=1).value = "PART002"
        ws.cell(row=3, column=2).value = "020224"
        ws.cell(row=3, column=3).value = "3"
        ws.cell(row=4, column=1).value = "PART003"
        ws.cell(row=4, column=2).value = "030324"
        ws.cell(row=4, column=3).value = "7"
        # Row 5 is empty (stop condition)
        ws.cell(row=5, column=1).value = None

        file_path = str(tmp_path / "test.xlsx")
        wb.save(file_path)
        wb.close()

        handler = ExcelHandler(file_path)
        records = handler.read_etd_data("ETD")

        assert len(records) == 3
        assert all(isinstance(r, ETDRecord) for r in records)
        assert records[0].part_number == "PART001"
        assert records[1].part_number == "PART002"
        assert records[2].part_number == "PART003"
        handler.close()


class TestReadEtdDataConvertsToStrings:
    """Test read_etd_data converts values to strings."""

    def test_numeric_values_become_strings(self, tmp_path):
        wb = Workbook()
        ws = wb.active
        ws.title = "ETD"
        # Header
        ws.cell(row=1, column=1).value = "Part Number"
        # Numeric values in data row
        ws.cell(row=2, column=1).value = 12345
        ws.cell(row=2, column=2).value = 20240101
        ws.cell(row=2, column=3).value = 99
        # Empty row to stop
        ws.cell(row=3, column=1).value = None

        file_path = str(tmp_path / "test.xlsx")
        wb.save(file_path)
        wb.close()

        handler = ExcelHandler(file_path)
        records = handler.read_etd_data("ETD")

        assert len(records) == 1
        assert records[0].part_number == "12345"
        assert records[0].etd_date == "20240101"
        assert records[0].quantity == "99"
        # Verify they are actual strings
        assert isinstance(records[0].part_number, str)
        assert isinstance(records[0].etd_date, str)
        assert isinstance(records[0].quantity, str)
        handler.close()


class TestWriteStatus:
    """Test write_status writes to column 4."""

    def test_write_status_sets_column_4(self, tmp_path):
        wb = Workbook()
        ws = wb.active
        ws.title = "ETD"
        # Some existing data in row 2
        ws.cell(row=2, column=1).value = "PART001"
        ws.cell(row=2, column=2).value = "010124"
        ws.cell(row=2, column=3).value = "5"
        file_path = str(tmp_path / "test.xlsx")
        wb.save(file_path)
        wb.close()

        handler = ExcelHandler(file_path)
        handler.write_status("ETD", row=2, status="ETD Table Updated")
        handler.save()
        handler.close()

        # Re-open and verify column 4
        handler2 = ExcelHandler(file_path)
        ws = handler2.get_sheet("ETD")
        assert ws.cell(row=2, column=4).value == "ETD Table Updated"
        handler2.close()
