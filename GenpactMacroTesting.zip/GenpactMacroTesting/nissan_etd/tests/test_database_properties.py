"""Property-based tests for DatabaseClient.

Uses Hypothesis to verify universal properties of the database client
across randomly generated inputs.
"""

import re
from unittest.mock import MagicMock, patch

import pytest
from hypothesis import given, settings, strategies as st

# Strategy: generate valid column names (non-empty ASCII identifiers)
column_name_strategy = st.text(
    alphabet=st.characters(whitelist_categories=("L", "N"), whitelist_characters="_"),
    min_size=1,
    max_size=30,
).filter(lambda s: s[0].isalpha() or s[0] == "_")

# Strategy: generate cell values (strings, ints, floats, None)
cell_value_strategy = st.one_of(
    st.text(min_size=0, max_size=50),
    st.integers(min_value=-10000, max_value=10000),
    st.floats(allow_nan=False, allow_infinity=False, min_value=-1e6, max_value=1e6),
    st.none(),
)


# Feature: bluezone-macro-to-python, Property 3: Database result set mapping
# Validates: Requirements 2.2
class TestDatabaseResultSetMapping:
    """Property 3: For any query result with N rows and M columns,
    DatabaseClient.execute_query() returns a list of exactly N dicts,
    each with exactly M key-value pairs with correct column names and values.
    """

    @given(
        columns=st.lists(column_name_strategy, min_size=1, max_size=10, unique=True),
        num_rows=st.integers(min_value=0, max_value=50),
    )
    @settings(max_examples=100)
    def test_result_set_mapping_structure(self, columns, num_rows):
        """For any N rows and M columns, execute_query returns N dicts with M keys."""
        # Generate row data matching column count
        m = len(columns)
        rows = []
        for _ in range(num_rows):
            row = MagicMock()
            row_values = [f"val_{i}" for i in range(m)]
            row.__iter__ = lambda self, vals=row_values: iter(vals)
            rows.append(row)

        # Mock the cursor description to return column names
        mock_description = [(col, None, None, None, None, None, None) for col in columns]

        with patch("pyodbc.connect") as mock_connect:
            mock_conn = MagicMock()
            mock_connect.return_value = mock_conn
            mock_cursor = MagicMock()
            mock_conn.cursor.return_value = mock_cursor
            mock_cursor.description = mock_description
            mock_cursor.fetchall.return_value = rows

            from nissan_etd.src.database_client import DatabaseClient

            client = DatabaseClient.__new__(DatabaseClient)
            client._connection = mock_conn
            client._logger = MagicMock()

            results = client.execute_query("SELECT * FROM test")

        # Verify: exactly N dicts returned
        assert len(results) == num_rows

        # Verify: each dict has exactly M keys matching column names
        for result_dict in results:
            assert len(result_dict) == m
            assert set(result_dict.keys()) == set(columns)

    @given(
        columns=st.lists(column_name_strategy, min_size=1, max_size=8, unique=True),
        data=st.data(),
    )
    @settings(max_examples=100)
    def test_result_set_mapping_values(self, columns, data):
        """For any query result, values in returned dicts match cursor row values."""
        m = len(columns)
        num_rows = data.draw(st.integers(min_value=1, max_value=20))

        # Generate actual cell values for each row
        all_row_values = []
        rows = []
        for _ in range(num_rows):
            row_values = [data.draw(cell_value_strategy) for _ in range(m)]
            all_row_values.append(row_values)
            row = MagicMock()
            row.__iter__ = lambda self, vals=row_values: iter(vals)
            rows.append(row)

        mock_description = [(col, None, None, None, None, None, None) for col in columns]

        with patch("pyodbc.connect") as mock_connect:
            mock_conn = MagicMock()
            mock_connect.return_value = mock_conn
            mock_cursor = MagicMock()
            mock_conn.cursor.return_value = mock_cursor
            mock_cursor.description = mock_description
            mock_cursor.fetchall.return_value = rows

            from nissan_etd.src.database_client import DatabaseClient

            client = DatabaseClient.__new__(DatabaseClient)
            client._connection = mock_conn
            client._logger = MagicMock()

            results = client.execute_query("SELECT * FROM test")

        # Verify: each dict value matches the original row value
        for i, result_dict in enumerate(results):
            for j, col in enumerate(columns):
                assert result_dict[col] == all_row_values[i][j]


# Feature: bluezone-macro-to-python, Property 4: Parameterised query binding
# Validates: Requirements 2.3
class TestParameterisedQueryBinding:
    """Property 4: For any stored procedure with K params,
    DatabaseClient.execute_stored_proc() calls cursor.execute() with
    {CALL proc_name (?, ?, ...)} syntax and a tuple of exactly K values
    (NOT string interpolation).
    """

    @given(
        proc_name=st.text(
            alphabet=st.characters(whitelist_categories=("L", "N"), whitelist_characters="_"),
            min_size=1,
            max_size=30,
        ).filter(lambda s: s[0].isalpha() or s[0] == "_"),
        param_keys=st.lists(
            st.text(
                alphabet=st.characters(whitelist_categories=("L", "N"), whitelist_characters="_"),
                min_size=1,
                max_size=20,
            ).filter(lambda s: s[0].isalpha() or s[0] == "_"),
            min_size=1,
            max_size=10,
            unique=True,
        ),
        data=st.data(),
    )
    @settings(max_examples=100)
    def test_stored_proc_uses_parameterised_binding(self, proc_name, param_keys, data):
        """For any stored proc with K params, cursor.execute is called with
        {CALL proc_name (?, ?, ...)} and a tuple of K values."""
        # Generate param values
        param_values = {
            key: data.draw(cell_value_strategy) for key in param_keys
        }
        k = len(param_values)

        with patch("pyodbc.connect") as mock_connect:
            mock_conn = MagicMock()
            mock_connect.return_value = mock_conn
            mock_cursor = MagicMock()
            mock_conn.cursor.return_value = mock_cursor
            # Simulate no result set returned
            mock_cursor.description = None

            from nissan_etd.src.database_client import DatabaseClient

            client = DatabaseClient.__new__(DatabaseClient)
            client._connection = mock_conn
            client._logger = MagicMock()

            client.execute_stored_proc(proc_name, param_values)

        # Get the actual call arguments
        mock_cursor.execute.assert_called_once()
        call_args = mock_cursor.execute.call_args
        sql_string = call_args[0][0]
        bound_params = call_args[0][1]

        # Verify: SQL uses {CALL proc_name (?, ?, ...)} syntax
        expected_placeholders = ", ".join(["?"] * k)
        expected_sql = f"{{CALL {proc_name} ({expected_placeholders})}}"
        assert sql_string == expected_sql

        # Verify: bound params is a tuple of exactly K values
        assert isinstance(bound_params, tuple)
        assert len(bound_params) == k

        # Verify: values match (in order of dict.values())
        assert bound_params == tuple(param_values.values())

        # Verify: NO string interpolation of actual values in SQL
        for value in param_values.values():
            if isinstance(value, str) and value:
                assert value not in sql_string

    @given(
        proc_name=st.text(
            alphabet=st.characters(whitelist_categories=("L", "N"), whitelist_characters="_"),
            min_size=1,
            max_size=30,
        ).filter(lambda s: s[0].isalpha() or s[0] == "_"),
    )
    @settings(max_examples=100)
    def test_stored_proc_no_params_uses_call_syntax(self, proc_name):
        """For a stored proc with no params, cursor.execute is called with
        {CALL proc_name} syntax and no parameter tuple."""
        with patch("pyodbc.connect") as mock_connect:
            mock_conn = MagicMock()
            mock_connect.return_value = mock_conn
            mock_cursor = MagicMock()
            mock_conn.cursor.return_value = mock_cursor
            mock_cursor.description = None

            from nissan_etd.src.database_client import DatabaseClient

            client = DatabaseClient.__new__(DatabaseClient)
            client._connection = mock_conn
            client._logger = MagicMock()

            client.execute_stored_proc(proc_name, None)

        # Get the actual call arguments
        mock_cursor.execute.assert_called_once()
        call_args = mock_cursor.execute.call_args
        sql_string = call_args[0][0]

        # Verify: SQL uses {CALL proc_name} syntax (no placeholders)
        expected_sql = f"{{CALL {proc_name}}}"
        assert sql_string == expected_sql

        # Verify: no parameter tuple passed
        assert len(call_args[0]) == 1  # only the SQL string, no params

    @given(
        proc_name=st.text(
            alphabet=st.characters(whitelist_categories=("L", "N"), whitelist_characters="_"),
            min_size=1,
            max_size=30,
        ).filter(lambda s: s[0].isalpha() or s[0] == "_"),
        param_keys=st.lists(
            st.text(
                alphabet=st.characters(whitelist_categories=("L", "N"), whitelist_characters="_"),
                min_size=1,
                max_size=20,
            ).filter(lambda s: s[0].isalpha() or s[0] == "_"),
            min_size=1,
            max_size=10,
            unique=True,
        ),
    )
    @settings(max_examples=100)
    def test_placeholder_count_matches_param_count(self, proc_name, param_keys):
        """The number of ? placeholders in the SQL equals exactly K (param count)."""
        param_values = {key: f"value_{i}" for i, key in enumerate(param_keys)}
        k = len(param_values)

        with patch("pyodbc.connect") as mock_connect:
            mock_conn = MagicMock()
            mock_connect.return_value = mock_conn
            mock_cursor = MagicMock()
            mock_conn.cursor.return_value = mock_cursor
            mock_cursor.description = None

            from nissan_etd.src.database_client import DatabaseClient

            client = DatabaseClient.__new__(DatabaseClient)
            client._connection = mock_conn
            client._logger = MagicMock()

            client.execute_stored_proc(proc_name, param_values)

        call_args = mock_cursor.execute.call_args
        sql_string = call_args[0][0]

        # Count placeholders in the SQL string
        placeholder_count = sql_string.count("?")
        assert placeholder_count == k
