"""Unit tests for ConfigManager.

Requirements: 1.1, 1.2, 1.3, 1.4
"""

import os
import tempfile

import pytest
import yaml

from src.config_manager import ConfigError, ConfigManager


class TestLoadValidYAML:
    """Test loading a valid YAML configuration file."""

    def test_load_valid_yaml_and_access_values(self, tmp_path):
        """Config values are accessible via get() after loading a valid YAML file."""
        config_data = {
            "database": {"connection_string": "Driver={SQL Server};Server=localhost"},
            "etd": {"excel_path": "C:\\data\\etd.xlsx"},
            "bluezone": {"prog_id": "BZWhll.WhllObj", "timeout_ms": 5000},
            "logging": {"directory": "C:\\logs", "level": "INFO"},
        }
        config_file = tmp_path / "config.yaml"
        config_file.write_text(yaml.dump(config_data), encoding="utf-8")

        mgr = ConfigManager(str(config_file))

        assert mgr.get("database.connection_string") == "Driver={SQL Server};Server=localhost"
        assert mgr.get("etd.excel_path") == "C:\\data\\etd.xlsx"
        assert mgr.get("bluezone.prog_id") == "BZWhll.WhllObj"
        assert mgr.get("bluezone.timeout_ms") == 5000
        assert mgr.get("logging.directory") == "C:\\logs"


class TestFileNotFound:
    """Test that missing config file raises ConfigError with path info."""

    def test_nonexistent_path_raises_config_error(self):
        """ConfigError is raised with the path when the file does not exist."""
        bad_path = r"C:\nonexistent\path\missing_config.yaml"

        with pytest.raises(ConfigError) as exc_info:
            ConfigManager(bad_path)

        assert bad_path in str(exc_info.value)


class TestEnvironmentVariableOverride:
    """Test that environment variables override YAML values."""

    def test_env_var_overrides_yaml_value(self, tmp_path, monkeypatch):
        """NISSAN_ETD__SECTION__KEY env var overrides the corresponding config value."""
        config_data = {
            "database": {"connection_string": "original_value"},
            "etd": {"excel_path": "C:\\original.xlsx"},
            "bluezone": {"prog_id": "BZWhll.WhllObj", "timeout_ms": 3000},
            "logging": {"directory": "C:\\logs"},
        }
        config_file = tmp_path / "config.yaml"
        config_file.write_text(yaml.dump(config_data), encoding="utf-8")

        monkeypatch.setenv(
            "NISSAN_ETD__DATABASE__CONNECTION_STRING", "overridden_connection"
        )

        mgr = ConfigManager(str(config_file))

        assert mgr.get("database.connection_string") == "overridden_connection"

    def test_env_var_creates_new_nested_key(self, tmp_path, monkeypatch):
        """Env var creates a new key if it doesn't exist in the YAML."""
        config_data = {"database": {"connection_string": "value"}}
        config_file = tmp_path / "config.yaml"
        config_file.write_text(yaml.dump(config_data), encoding="utf-8")

        monkeypatch.setenv("NISSAN_ETD__NEWSTUFF__SECRET_KEY", "my_secret")

        mgr = ConfigManager(str(config_file))

        assert mgr.get("newstuff.secret_key") == "my_secret"


class TestValidateMissingKeys:
    """Test validate() reports all missing required keys."""

    def test_validate_lists_all_missing_keys(self, tmp_path):
        """ConfigError message contains all missing required key names."""
        # Config with only one of the required keys present
        config_data = {
            "database": {"connection_string": "some_value"},
        }
        config_file = tmp_path / "config.yaml"
        config_file.write_text(yaml.dump(config_data), encoding="utf-8")

        mgr = ConfigManager(str(config_file))

        with pytest.raises(ConfigError) as exc_info:
            mgr.validate()

        error_msg = str(exc_info.value)
        # All missing keys should be listed
        assert "etd.excel_path" in error_msg
        assert "bluezone.prog_id" in error_msg
        assert "bluezone.timeout_ms" in error_msg
        assert "logging.directory" in error_msg
        # The present key should NOT appear in the error
        assert "database.connection_string" not in error_msg

    def test_validate_passes_when_all_keys_present(self, tmp_path):
        """validate() does not raise when all required keys are present."""
        config_data = {
            "database": {"connection_string": "Driver=x"},
            "etd": {"excel_path": "C:\\etd.xlsx"},
            "bluezone": {"prog_id": "BZWhll.WhllObj", "timeout_ms": 5000},
            "logging": {"directory": "C:\\logs"},
        }
        config_file = tmp_path / "config.yaml"
        config_file.write_text(yaml.dump(config_data), encoding="utf-8")

        mgr = ConfigManager(str(config_file))

        # Should not raise
        mgr.validate()


class TestGetWithDefault:
    """Test get() returns default for non-existent keys."""

    def test_nonexistent_key_returns_default(self, tmp_path):
        """get() returns the provided default when the key does not exist."""
        config_data = {"database": {"connection_string": "value"}}
        config_file = tmp_path / "config.yaml"
        config_file.write_text(yaml.dump(config_data), encoding="utf-8")

        mgr = ConfigManager(str(config_file))

        assert mgr.get("nonexistent.key", "fallback") == "fallback"

    def test_nonexistent_key_returns_none_by_default(self, tmp_path):
        """get() returns None when no default is specified and key is missing."""
        config_data = {"database": {"connection_string": "value"}}
        config_file = tmp_path / "config.yaml"
        config_file.write_text(yaml.dump(config_data), encoding="utf-8")

        mgr = ConfigManager(str(config_file))

        assert mgr.get("nonexistent.key") is None


class TestNestedDotNotationAccess:
    """Test deeply nested key access via dot notation."""

    def test_deeply_nested_key_access(self, tmp_path):
        """get() traverses multiple levels of nesting using dot notation."""
        config_data = {
            "level1": {
                "level2": {
                    "level3": {"value": "deep_value"}
                }
            }
        }
        config_file = tmp_path / "config.yaml"
        config_file.write_text(yaml.dump(config_data), encoding="utf-8")

        mgr = ConfigManager(str(config_file))

        assert mgr.get("level1.level2.level3.value") == "deep_value"

    def test_partial_path_returns_dict(self, tmp_path):
        """get() returns the nested dict when the path stops at an intermediate level."""
        config_data = {
            "database": {
                "connection_string": "value",
                "timeout": 30,
            }
        }
        config_file = tmp_path / "config.yaml"
        config_file.write_text(yaml.dump(config_data), encoding="utf-8")

        mgr = ConfigManager(str(config_file))

        result = mgr.get("database")
        assert isinstance(result, dict)
        assert result["connection_string"] == "value"
        assert result["timeout"] == 30
