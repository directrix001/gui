"""Shared pytest fixtures for Nissan ETD test suite."""

import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest
import yaml

# Make src importable from tests
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from config_manager import ConfigManager
from excel_handler import ETDRecord


@pytest.fixture
def tmp_config_file(tmp_path):
    """Create a temporary valid YAML config file with all required keys populated.

    Returns the path to the config file.
    """
    config_data = {
        "database": {
            "connection_string": (
                "DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};"
                "DBQ=C:\\temp\\test.accdb;"
            ),
        },
        "etd": {
            "excel_path": "C:\\temp\\test_etd.xlsx",
            "sheet_name": "ETD_Data",
            "zvor_path": "C:\\temp\\test_zvor.xlsx",
        },
        "bluezone": {
            "prog_id": "BZWhll.WhllObj",
            "timeout_ms": 30000,
        },
        "logging": {
            "directory": str(tmp_path / "logs"),
            "level": "DEBUG",
        },
    }

    config_path = tmp_path / "config.yaml"
    with open(config_path, "w", encoding="utf-8") as f:
        yaml.dump(config_data, f, default_flow_style=False)

    return config_path


@pytest.fixture
def sample_etd_records():
    """Return a list of sample ETDRecord objects for testing."""
    return [
        ETDRecord(row=2, part_number="12345-AB001", etd_date="2024-03-15", quantity="10"),
        ETDRecord(row=3, part_number="67890-CD002", etd_date="2024-03-16", quantity="5"),
        ETDRecord(row=4, part_number="11111-EF003", etd_date="2024-03-17", quantity="20"),
        ETDRecord(row=5, part_number="22222-GH004", etd_date="2024-03-18", quantity="1"),
    ]


@pytest.fixture
def mock_bluezone_screen():
    """Return a MagicMock configured to simulate a BlueZone Screen COM object.

    Attributes configured: GetString, SendKeys, MoveTo, WaitForString,
    WaitHostQuiet, Row, Col.
    """
    screen = MagicMock()
    screen.GetString.return_value = "M009000G"
    screen.SendKeys.return_value = None
    screen.MoveTo.return_value = None
    screen.WaitForString.return_value = True
    screen.WaitHostQuiet.return_value = None
    screen.Row = 1
    screen.Col = 1
    return screen


@pytest.fixture
def mock_pyodbc_connection():
    """Return a MagicMock simulating a pyodbc connection.

    Methods configured: cursor(), commit(), rollback(), close().
    The cursor mock includes execute(), fetchall(), fetchone(),
    description, and rowcount attributes.
    """
    connection = MagicMock()
    cursor = MagicMock()

    # Configure cursor attributes
    cursor.execute.return_value = cursor
    cursor.fetchall.return_value = []
    cursor.fetchone.return_value = None
    cursor.description = [("col1",), ("col2",), ("col3",)]
    cursor.rowcount = 0

    connection.cursor.return_value = cursor
    connection.commit.return_value = None
    connection.rollback.return_value = None
    connection.close.return_value = None

    return connection


@pytest.fixture
def sample_config(tmp_config_file):
    """Return a ConfigManager loaded from a temporary config file."""
    return ConfigManager(config_path=str(tmp_config_file))
