# Nissan UK RDC ETD Tools — User Guide

This guide is for end users who need to run the ETD processing scripts. These Python scripts replace the old VBA/Access macros — allowing you to use **64-bit Office** while still automating BlueZone and the NPOPS mainframe.

---

## Why These Scripts Exist

The old VBA macros required 32-bit Office because they talked to 32-bit BlueZone via COM. Since the organisation is moving to **64-bit Office**, the old macros can't work anymore (64-bit Office can't call 32-bit BlueZone COM objects — bitness mismatch).

These Python scripts solve that by removing Office from the equation entirely:

- **Excel files** are read/written directly using openpyxl (no Office COM needed)
- **BlueZone** is controlled by 32-bit Python talking to the 32-bit BlueZone COM object directly
- **64-bit Office** can run alongside without any conflict — Python and Office don't interact

## What's Different From the Old Macros

| | Old (VBA/Access + 32-bit Office) | New (Python + 64-bit Office) |
|---|---|---|
| **How you run it** | Click a button in an Access form | Type a command in Command Prompt |
| **Office version** | Required 32-bit Office | Works with 64-bit Office (no conflict) |
| **BlueZone** | Same — must be open and logged in | Same — must be open and logged in |
| **Network drives** | Same — P:\, G:\ must be connected | Same — P:\, G:\ must be connected |
| **Database** | Same Access/SQL Server database | Same database, same queries |
| **Excel output** | Same workbooks, same sheets | Same workbooks, same sheets |
| **Mainframe interaction** | Same screens, same fields, same PF keys | Same screens, same fields, same PF keys |

**The only new requirement is Python 3.10 (32-bit) being installed.** This runs alongside 64-bit Office without any issues. Everything else — BlueZone, network drives, database access, mainframe credentials — is exactly the same as before.

---

## What You Need (One-Time Setup)

Your IT team or administrator needs to install these once on the Citrix machine:

1. **Python 3.10 or later (32-bit version)** — must be 32-bit to communicate with the 32-bit BlueZone COM object. This runs happily alongside 64-bit Office — no conflict.
2. **Python packages** — open a command prompt and run:
   ```
   cd C:\path\to\nissan_etd
   pip install -r requirements.txt
   ```
3. **Configuration file** — copy `config.yaml.example` to `config.yaml` and update the file paths to match your environment (your admin will know the correct paths for P: drive, G: drive, etc.)

---

## Before You Run

- Make sure **BlueZone** is open and you're logged into the mainframe session
- Make sure your **network drives** (P:\, G:\) are connected
- Make sure the **BO_UK-RDC.xlsx** file is in the expected location

---

## How to Run Each Operation

Open a **Command Prompt** (or PowerShell) and navigate to the nissan_etd folder:

```
cd C:\path\to\nissan_etd
```

Then run one of the following commands:

### Full ETD Process (replaces the main macro button)

This does everything: imports data, formats it, and submits to NPOPS via BlueZone.

```
python main.py full-etd-process
```

### Format Only (no mainframe submission)

Imports and formats the ETD data but does NOT send it to NPOPS. Useful for checking the data first.

```
python main.py format-only
```

### Export to NPOPS Only

If data is already formatted in the Excel workbook, this just submits it to the mainframe.

```
python main.py export-npops-only
```

### ZVOR Export

Exports ZVOR ETD parts data from the database to the ZVOR Excel workbook.

```
python main.py zvor-export
```

### Run a Database Query

Run any of the named queries (same ones the old macros used):

```
python main.py run-query "find etd information"
python main.py run-query "ICS Requests to Ams"
python main.py run-query "Outstanding ETD Requests"
python main.py run-query "archive solved requests"
python main.py run-query "delete solved requests"
```

### Generate a Picker Claim Report

**Summary report:**
```
python main.py report --type summary --start-date 2026-01-01 --end-date 2026-07-17
```

**Detailed report:**
```
python main.py report --type detailed --start-date 2026-01-01 --end-date 2026-07-17
```

**With filters:**
```
python main.py report --type summary --start-date 2026-01-01 --end-date 2026-07-17 --stock-type VOR --zones A,B,C --cost-centres 10,11,21
```

Filter options:
- `--stock-type` — Stock, VOR, or All (default: All)
- `--dealer` — dealer account number
- `--part-number` — part number to filter on
- `--picker` — picker's full name
- `--team` — team ID
- `--zones` — comma-separated zone letters to include (e.g., A,B,C)
- `--cost-centres` — comma-separated cost centre codes to include (e.g., 10,11,21)

---

## What Happens During the ETD Process

1. The script queries the database for backorder data
2. Writes it to the ETD Excel workbook (Dropoff sheet)
3. Calculates new ETD dates (+7 days) and formats them
4. Sorts and removes duplicates
5. Connects to BlueZone and navigates to the NPOPS ETD screen (NPS025P1)
6. For each part: enters the part number, date, and quantity, then submits
7. Records whether each submission succeeded or failed
8. Saves the results back to the Excel workbook (column D shows status)

---

## Understanding the Output

After running `full-etd-process` or `export-npops-only`:

- **Exit code 0** = everything worked
- **Exit code 2** = some rows had errors (check the Excel file, column D shows what went wrong)
- **Exit code 1** = something went seriously wrong (check the log file)

The log file is in the `logs/` folder — it records every step with timestamps.

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| "Configuration file not found" | Make sure `config.yaml` exists in the nissan_etd folder |
| "Could not create BlueZone COM object" | Make sure BlueZone is running and you have an active session |
| "No active BlueZone session" | Open BlueZone and log into the mainframe first |
| "Navigation failed: expected NPS025P1" | You might not be on the right mainframe screen — navigate manually to the main menu and try again |
| "Failed to connect to database" | Check the database path in config.yaml and make sure the Access file is accessible |
| "Workbook not found" | Check the file paths in config.yaml — the Excel files need to be where the config says they are |

---

## Config File Quick Reference

The `config.yaml` file controls all paths and settings. Key values to check:

```yaml
database:
  connection_string: "DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=P:\\UKRDC\\database.accdb"

etd:
  excel_path: "P:\\UKRDC\\ETD\\Assign New ETD.xls"
  backorder_path: "P:\\UKRDC\\BO_UK-RDC.xlsx"
  zvor_path: "G:\\xxNPO\\VOR files\\ZVOR_Search.xlsm"

bluezone:
  prog_id: "BZWhll.WhllObj"
  timeout_ms: 30000
```

If any paths change, just update this file — no code changes needed.

---

## Getting Help

- Check the `logs/nissan_etd.log` file for detailed error information
- The log shows every step the script took and where it failed
- If BlueZone submissions are failing, the status column in the Excel file shows the exact mainframe error message for each row
