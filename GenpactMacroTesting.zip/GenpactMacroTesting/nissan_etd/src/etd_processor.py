"""ETD Processor - Main orchestration module for the ETD pipeline.

Coordinates the full ETD processing workflow: database query → Excel import →
data formatting → BlueZone mainframe submission → status recording.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from src.bluezone_client import BlueZoneClient, BlueZoneError
from src.config_manager import ConfigManager
from src.database_client import DatabaseClient, DatabaseError
from src.etd_formatter import ETDFormatter
from src.excel_handler import ExcelHandler, ExcelError
from src.npops_navigator import NPOPSNavigator, NavigationError


class ETDProcessError(Exception):
    """General pipeline error raised during ETD processing."""


@dataclass
class RowResult:
    """Result of processing a single ETD row on the mainframe."""

    row_number: int
    part_number: str
    status: str
    is_success: bool


@dataclass
class ProcessResult:
    """Aggregate result of an ETD processing run."""

    total_rows: int
    success_count: int
    error_count: int
    row_results: list[RowResult] = field(default_factory=list)


class ETDProcessor:
    """Orchestrates the ETD processing pipeline.

    Coordinates data import from database, Excel workbook staging,
    ETD date formatting, and NPOPS mainframe submission.
    """

    def __init__(self, config: ConfigManager):
        """Initialise the processor with configuration.

        Args:
            config: A validated ConfigManager instance providing all
                required paths, connection strings, and settings.
        """
        self._config = config
        self._logger = logging.getLogger(__name__)

    # Column name mapping: Access DB column names -> internal field names
    # The database returns columns like "PART NUMBER", "ETD reply", "bo-qty"
    # but the formatter expects "part_number", "etd_date", "quantity", "priority"
    COLUMN_MAP = {
        "PART NUMBER": "part_number",
        "PART_NO": "part_number",
        "part_number": "part_number",
        "ETD reply": "etd_date",
        "MinOfETD reply": "etd_date",
        "etd_date": "etd_date",
        "bo-qty": "quantity",
        "SumOfbo-qty": "quantity",
        "quantity": "quantity",
        "ALLOC_PRIORITY": "priority",
        "priority": "priority",
    }

    def _map_etd_columns(self, records: list[dict]) -> list[dict]:
        """Map database column names to internal field names for the formatter.

        Handles the mismatch between Access database column names
        (e.g., 'PART NUMBER', 'ETD reply', 'bo-qty') and the internal
        field names expected by ETDFormatter ('part_number', 'etd_date', 'quantity').

        Args:
            records: List of dicts with database column names as keys.

        Returns:
            List of dicts with standardised internal field names.
        """
        mapped = []
        for record in records:
            new_record = {}
            for db_col, value in record.items():
                internal_name = self.COLUMN_MAP.get(db_col)
                if internal_name:
                    new_record[internal_name] = value
            # Ensure required fields exist with defaults
            new_record.setdefault("part_number", "")
            new_record.setdefault("etd_date", "")
            new_record.setdefault("quantity", "0")
            new_record.setdefault("priority", 0)
            # Only include records with a valid part number
            if new_record["part_number"]:
                mapped.append(new_record)
        return mapped

    def run_full_process(self) -> ProcessResult:
        """Execute the full ETD pipeline: import → format → submit to NPOPS.

        Steps:
        1. Open database and execute the ETD COUNT DATE query.
        2. Open the ETD Excel workbook.
        3. Clear the Dropoff sheet range (A7:Z10000).
        4. Write query results to the Dropoff sheet.
        5. Run the format pipeline (ETDFormatter.process_pipeline).
        6. Connect to BlueZone and navigate to NPS025P1.
        7. For each formatted row: submit part_no, date, qty via PF8.
        8. Parse response and record status.
        9. Write status to Excel column 4.
        10. Return ProcessResult summary.

        Returns:
            ProcessResult with counts and per-row status details.

        Raises:
            ETDProcessError: If a fatal error occurs during processing.
        """
        self._logger.info("Starting full ETD process")

        # Step 1: Open database and execute ETD COUNT DATE query
        connection_string = self._config.get("database.connection_string")
        try:
            db = DatabaseClient(connection_string)
        except DatabaseError as exc:
            raise ETDProcessError(f"Database connection failed: {exc}") from exc

        try:
            query_name = self._config.get("queries.etd_count_date", "ETD COUNT DATE QRY")
            self._logger.info("Executing query: %s", query_name)
            raw_records = db.execute_query(query_name)
            self._logger.info("Query returned %d rows", len(raw_records))
        except DatabaseError as exc:
            db.close()
            raise ETDProcessError(f"ETD query failed: {exc}") from exc
        finally:
            db.close()

        # Step 2: Open ETD Excel workbook
        excel_path = self._config.get("etd.excel_path")
        try:
            workbook = ExcelHandler(excel_path)
        except ExcelError as exc:
            raise ETDProcessError(f"Failed to open ETD workbook: {exc}") from exc

        # Step 3: Clear Dropoff sheet range A7:Z10000
        dropoff_sheet = self._config.get("etd.dropoff_sheet", "Dropoff")
        self._logger.info("Clearing Dropoff sheet range A7:Z10000")
        workbook.clear_range(dropoff_sheet, start_row=7, start_col=1, end_row=10000, end_col=26)

        # Step 4: Write query results to Dropoff sheet
        if raw_records:
            records_as_tuples = [tuple(record.values()) for record in raw_records]
            workbook.write_records(dropoff_sheet, records_as_tuples, start_row=7, start_col=1)
            self._logger.info("Wrote %d records to Dropoff sheet", len(records_as_tuples))

        # Step 5: Run format pipeline
        # Map database column names to internal field names expected by ETDFormatter
        self._logger.info("Running ETD format pipeline")
        mapped_records = self._map_etd_columns(raw_records)
        formatted_data = ETDFormatter.process_pipeline(mapped_records)
        self._logger.info("Format pipeline produced %d records", len(formatted_data))

        # Step 6: Connect BlueZone and navigate to NPS025P1
        prog_id = self._config.get("bluezone.prog_id", "BZWhll.WhllObj")
        timeout_ms = self._config.get("bluezone.timeout_ms", 30000)

        try:
            bz_client = BlueZoneClient(prog_id=prog_id, timeout_ms=timeout_ms)
        except BlueZoneError as exc:
            workbook.save()
            workbook.close()
            raise ETDProcessError(f"BlueZone connection failed: {exc}") from exc

        navigator = NPOPSNavigator(bz_client)

        try:
            navigator.navigate_to_etd_entry()
        except NavigationError as exc:
            bz_client.disconnect()
            workbook.save()
            workbook.close()
            raise ETDProcessError(f"NPOPS navigation failed: {exc}") from exc

        # Step 7-9: Submit each formatted row
        row_results: list[RowResult] = []
        success_count = 0
        error_count = 0

        for idx, record in enumerate(formatted_data, start=1):
            part_no = record["part_number"]
            etd_date = record["etd_date"]
            quantity = record["quantity"]

            self._logger.info(
                "Submitting row %d: part=%s, date=%s, qty=%s",
                idx, part_no, etd_date, quantity,
            )

            try:
                # Navigate to entry screen before each row (matches VBA behaviour
                # which checks/navigates at the start of every loop iteration)
                navigator.navigate_to_etd_entry()

                # Enter part number at row 5, col 24
                bz_client.move_to(5, 24)
                bz_client.send_keys(part_no)

                # Enter ETD date at row 13, col 29
                bz_client.move_to(13, 29)
                bz_client.send_keys(etd_date)

                # Enter quantity at row 13, col 45
                bz_client.move_to(13, 45)
                bz_client.send_keys(quantity)

                # Submit with PF8
                bz_client.send_keys("<PF8>")
                bz_client.wait_host_quiet()

                # Parse response — matches VBA logic exactly:
                # 1. Check row 1, col 2 for "Part: {part_no} - ETD Table Updated"
                # 2. If not, check row 1, col 1 for error message text
                # 3. If that's empty too, report "Problem - screen: {screen_id}"
                success_text = f"Part: {part_no} - ETD Table Updated"
                response_line = bz_client.get_string(1, 2, 80)

                if response_line == success_text:
                    status = "ETD Table Updated"
                    is_success = True
                    success_count += 1
                    self._logger.info("Row %d: SUCCESS - %s", idx, status)
                else:
                    # Check row 1, col 1 for error message
                    error_line = bz_client.get_string(1, 1, 80)
                    if error_line:
                        status = error_line
                    else:
                        # Fallback: report the current screen identifier
                        screen_text = bz_client.get_string(3, 3, 10)
                        status = f"Problem - screen: {screen_text}"
                    is_success = False
                    error_count += 1
                    self._logger.warning("Row %d: ERROR - %s", idx, status)

            except (BlueZoneError, Exception) as exc:
                status = str(exc)
                is_success = False
                error_count += 1
                self._logger.error("Row %d: EXCEPTION - %s", idx, exc)

            # Record result
            row_result = RowResult(
                row_number=idx,
                part_number=part_no,
                status=status,
                is_success=is_success,
            )
            row_results.append(row_result)

            # Write status to Excel column 4
            workbook.write_status(dropoff_sheet, idx + 1, status)

            # Check if still on NPS025P1, if not send PF11 to recover
            current_screen = bz_client.get_current_screen_id()
            if current_screen != NPOPSNavigator.TARGET_SCREEN:
                self._logger.warning(
                    "Not on NPS025P1 after submission (on %s), sending PF11 to recover",
                    current_screen,
                )
                bz_client.send_keys("<PF11>")
                bz_client.wait_host_quiet()

        # Cleanup
        bz_client.disconnect()
        workbook.save()
        workbook.close()

        result = ProcessResult(
            total_rows=len(formatted_data),
            success_count=success_count,
            error_count=error_count,
            row_results=row_results,
        )

        self._logger.info(
            "Full ETD process complete: %d total, %d success, %d errors",
            result.total_rows, result.success_count, result.error_count,
        )

        return result

    def format_only(self) -> list[dict]:
        """Import data from the BO file, format it, and return without NPOPS submission.

        Returns:
            List of formatted record dicts with keys: part_number, etd_date, quantity.

        Raises:
            ETDProcessError: If import or formatting fails.
        """
        self._logger.info("Starting format-only operation")

        # Execute the ETD COUNT DATE query to get raw data
        connection_string = self._config.get("database.connection_string")
        try:
            db = DatabaseClient(connection_string)
        except DatabaseError as exc:
            raise ETDProcessError(f"Database connection failed: {exc}") from exc

        try:
            query_name = self._config.get("queries.etd_count_date", "ETD COUNT DATE QRY")
            raw_records = db.execute_query(query_name)
            self._logger.info("Query returned %d rows", len(raw_records))
        except DatabaseError as exc:
            raise ETDProcessError(f"ETD query failed: {exc}") from exc
        finally:
            db.close()

        # Run format pipeline (map column names first)
        mapped_records = self._map_etd_columns(raw_records)
        formatted_data = ETDFormatter.process_pipeline(mapped_records)
        self._logger.info(
            "Format-only complete: %d records formatted", len(formatted_data)
        )

        return formatted_data

    def export_npops_only(
        self, formatted_data: list[dict] | None = None
    ) -> ProcessResult:
        """Submit pre-formatted data to NPOPS (skips import/format).

        If no data is provided, reads formatted data from the ETD workbook.

        Args:
            formatted_data: Optional list of formatted record dicts. If None,
                reads from the ETD workbook Dropoff sheet.

        Returns:
            ProcessResult with submission counts and per-row details.

        Raises:
            ETDProcessError: If connection or submission fails fatally.
        """
        self._logger.info("Starting export-to-NPOPS-only operation")

        # If no data provided, read from ETD workbook
        if formatted_data is None:
            excel_path = self._config.get("etd.excel_path")
            try:
                workbook = ExcelHandler(excel_path)
            except ExcelError as exc:
                raise ETDProcessError(
                    f"Failed to open ETD workbook: {exc}"
                ) from exc

            dropoff_sheet = self._config.get("etd.dropoff_sheet", "Dropoff")
            etd_records = workbook.read_etd_data(dropoff_sheet)

            formatted_data = [
                {
                    "part_number": rec.part_number,
                    "etd_date": rec.etd_date,
                    "quantity": rec.quantity,
                }
                for rec in etd_records
            ]
            self._logger.info("Read %d records from workbook", len(formatted_data))
        else:
            workbook = None

        # Connect BlueZone and navigate
        prog_id = self._config.get("bluezone.prog_id", "BZWhll.WhllObj")
        timeout_ms = self._config.get("bluezone.timeout_ms", 30000)

        try:
            bz_client = BlueZoneClient(prog_id=prog_id, timeout_ms=timeout_ms)
        except BlueZoneError as exc:
            if workbook:
                workbook.close()
            raise ETDProcessError(f"BlueZone connection failed: {exc}") from exc

        navigator = NPOPSNavigator(bz_client)

        try:
            navigator.navigate_to_etd_entry()
        except NavigationError as exc:
            bz_client.disconnect()
            if workbook:
                workbook.close()
            raise ETDProcessError(f"NPOPS navigation failed: {exc}") from exc

        # Submit each row
        row_results: list[RowResult] = []
        success_count = 0
        error_count = 0

        for idx, record in enumerate(formatted_data, start=1):
            part_no = record["part_number"]
            etd_date = record["etd_date"]
            quantity = record["quantity"]

            self._logger.info(
                "Submitting row %d: part=%s, date=%s, qty=%s",
                idx, part_no, etd_date, quantity,
            )

            try:
                # Navigate to entry screen before each row (matches VBA behaviour)
                navigator.navigate_to_etd_entry()

                # Enter fields
                bz_client.move_to(5, 24)
                bz_client.send_keys(part_no)

                bz_client.move_to(13, 29)
                bz_client.send_keys(etd_date)

                bz_client.move_to(13, 45)
                bz_client.send_keys(quantity)

                # Submit with PF8
                bz_client.send_keys("<PF8>")
                bz_client.wait_host_quiet()

                # Parse response — matches VBA logic exactly:
                # 1. Check row 1, col 2 for "Part: {part_no} - ETD Table Updated"
                # 2. If not, check row 1, col 1 for error message text
                # 3. If that's empty too, report "Problem - screen: {screen_id}"
                success_text = f"Part: {part_no} - ETD Table Updated"
                response_line = bz_client.get_string(1, 2, 80)

                if response_line == success_text:
                    status = "ETD Table Updated"
                    is_success = True
                    success_count += 1
                    self._logger.info("Row %d: SUCCESS - %s", idx, status)
                else:
                    # Check row 1, col 1 for error message
                    error_line = bz_client.get_string(1, 1, 80)
                    if error_line:
                        status = error_line
                    else:
                        # Fallback: report the current screen identifier
                        screen_text = bz_client.get_string(3, 3, 10)
                        status = f"Problem - screen: {screen_text}"
                    is_success = False
                    error_count += 1
                    self._logger.warning("Row %d: ERROR - %s", idx, status)

            except (BlueZoneError, Exception) as exc:
                status = str(exc)
                is_success = False
                error_count += 1
                self._logger.error("Row %d: EXCEPTION - %s", idx, exc)

            # Record result
            row_result = RowResult(
                row_number=idx,
                part_number=part_no,
                status=status,
                is_success=is_success,
            )
            row_results.append(row_result)

            # Write status to Excel if workbook is open
            if workbook:
                dropoff_sheet = self._config.get("etd.dropoff_sheet", "Dropoff")
                workbook.write_status(dropoff_sheet, idx + 1, status)

            # Recovery if not on NPS025P1
            current_screen = bz_client.get_current_screen_id()
            if current_screen != NPOPSNavigator.TARGET_SCREEN:
                self._logger.warning(
                    "Not on NPS025P1 after submission (on %s), sending PF11 to recover",
                    current_screen,
                )
                bz_client.send_keys("<PF11>")
                bz_client.wait_host_quiet()

        # Cleanup
        bz_client.disconnect()
        if workbook:
            workbook.save()
            workbook.close()

        result = ProcessResult(
            total_rows=len(formatted_data),
            success_count=success_count,
            error_count=error_count,
            row_results=row_results,
        )

        self._logger.info(
            "NPOPS export complete: %d total, %d success, %d errors",
            result.total_rows, result.success_count, result.error_count,
        )

        return result

    def zvor_export(self) -> None:
        """Export ZVOR ETD parts data to Excel workbook.

        Opens the ZVOR workbook, clears the Dropoff sheet, executes the
        ZVOR_ETD_PARTs query, and writes results to the sheet.

        Raises:
            ETDProcessError: If the ZVOR path is not configured, or if
                the workbook or query operation fails.
        """
        self._logger.info("Starting ZVOR export operation")

        # Get ZVOR workbook path
        zvor_path = self._config.get("etd.zvor_path")
        if not zvor_path:
            raise ETDProcessError(
                "ZVOR workbook path not configured (etd.zvor_path)"
            )

        # Open ZVOR workbook
        try:
            workbook = ExcelHandler(zvor_path)
        except ExcelError as exc:
            raise ETDProcessError(
                f"Failed to open ZVOR workbook: {exc}"
            ) from exc

        # Clear Dropoff sheet
        dropoff_sheet = self._config.get("etd.dropoff_sheet", "Dropoff")
        self._logger.info("Clearing ZVOR Dropoff sheet")
        workbook.clear_range(dropoff_sheet, start_row=2, start_col=1, end_row=10000, end_col=26)

        # Execute ZVOR_ETD_PARTs query
        connection_string = self._config.get("database.connection_string")
        try:
            db = DatabaseClient(connection_string)
        except DatabaseError as exc:
            workbook.close()
            raise ETDProcessError(f"Database connection failed: {exc}") from exc

        try:
            query_name = self._config.get("queries.zvor_etd_parts", "ZVOR_ETD_PARTs")
            self._logger.info("Executing ZVOR query: %s", query_name)
            results = db.execute_query(query_name)
            self._logger.info("ZVOR query returned %d rows", len(results))
        except DatabaseError as exc:
            workbook.close()
            raise ETDProcessError(f"ZVOR query failed: {exc}") from exc
        finally:
            db.close()

        # Write results to Dropoff sheet
        if results:
            records_as_tuples = [tuple(record.values()) for record in results]
            workbook.write_records(dropoff_sheet, records_as_tuples, start_row=2, start_col=1)
            self._logger.info("Wrote %d ZVOR records to Dropoff sheet", len(records_as_tuples))

        workbook.save()
        workbook.close()
        self._logger.info("ZVOR export complete")

    def run_query(self, query_name: str) -> list[dict]:
        """Execute a named database query and return results.

        Args:
            query_name: The name of the query to execute (as defined in
                the database or configuration).

        Returns:
            List of dictionaries representing the query result rows.

        Raises:
            ETDProcessError: If the database connection or query fails.
        """
        self._logger.info("Executing named query: %s", query_name)

        connection_string = self._config.get("database.connection_string")
        try:
            db = DatabaseClient(connection_string)
        except DatabaseError as exc:
            raise ETDProcessError(f"Database connection failed: {exc}") from exc

        try:
            results = db.execute_query(query_name)
            self._logger.info(
                "Query '%s' returned %d rows", query_name, len(results)
            )
            return results
        except DatabaseError as exc:
            raise ETDProcessError(
                f"Query '{query_name}' failed: {exc}"
            ) from exc
        finally:
            db.close()
