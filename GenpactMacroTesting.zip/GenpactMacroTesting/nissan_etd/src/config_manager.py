"""Configuration manager for Nissan ETD processing.

Loads configuration from a YAML file with support for environment variable
overrides and dot-notation key access.
"""

import os
from pathlib import Path
from typing import Any

import yaml


class ConfigError(Exception):
    """Raised when configuration is invalid or missing."""


class ConfigManager:
    """Loads config from YAML with environment variable overrides."""

    REQUIRED_KEYS = [
        "database.connection_string",
        "etd.excel_path",
        "bluezone.prog_id",
        "bluezone.timeout_ms",
        "logging.directory",
    ]

    def __init__(self, config_path: str | None = None):
        """Load config from path. Defaults to config.yaml in script directory.

        Args:
            config_path: Path to the YAML configuration file. If None,
                looks for config.yaml in the same directory as this script.

        Raises:
            ConfigError: If the configuration file is not found.
        """
        if config_path is None:
            script_dir = Path(__file__).resolve().parent.parent
            config_path = str(script_dir / "config.yaml")

        path = Path(config_path)
        if not path.exists():
            raise ConfigError(f"Configuration file not found: {config_path}")

        with open(path, "r", encoding="utf-8") as f:
            self._data: dict = yaml.safe_load(f) or {}

        self._apply_env_overrides()

    def get(self, dotted_key: str, default: Any = None) -> Any:
        """Retrieve a config value using dot notation.

        Args:
            dotted_key: Key in dot notation (e.g., 'database.connection_string').
            default: Value to return if the key is not found.

        Returns:
            The config value or default if not found.
        """
        keys = dotted_key.split(".")
        current = self._data

        for key in keys:
            if not isinstance(current, dict) or key not in current:
                return default
            current = current[key]

        return current

    def validate(self) -> None:
        """Check all required keys exist in the configuration.

        Raises:
            ConfigError: If any required keys are missing, with a message
                listing all missing key names.
        """
        missing = [key for key in self.REQUIRED_KEYS if self.get(key) is None]

        if missing:
            missing_list = ", ".join(missing)
            raise ConfigError(
                f"Missing required configuration keys: {missing_list}"
            )

    def _apply_env_overrides(self) -> None:
        """Apply environment variable overrides to the configuration.

        Looks for environment variables with the prefix NISSAN_ETD__.
        Double underscores (__) separate nested levels.

        Example:
            NISSAN_ETD__DATABASE__CONNECTION_STRING overrides
            database.connection_string
        """
        prefix = "NISSAN_ETD__"

        for env_key, env_value in os.environ.items():
            if not env_key.startswith(prefix):
                continue

            # Strip prefix and split on double underscore
            raw_key = env_key[len(prefix):]
            parts = raw_key.split("__")

            # Convert to lowercase for config keys
            parts = [part.lower() for part in parts]

            # Navigate/create nested dict structure and set value
            current = self._data
            for part in parts[:-1]:
                if part not in current or not isinstance(current[part], dict):
                    current[part] = {}
                current = current[part]

            current[parts[-1]] = env_value
