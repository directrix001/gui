"""NPOPS screen navigation state machine.

Navigates through NPOPS mainframe screens using a defined transition table
to reach the ETD data entry screen (NPS025P1). Uses the BlueZone COM client
for screen identification and command sending.
"""

from __future__ import annotations

import logging

from src.bluezone_client import BlueZoneClient, BlueZoneError


class NavigationError(Exception):
    """Raised when screen navigation fails.

    Stores the expected and actual screen identifiers for diagnostics.
    """

    def __init__(self, expected_screen: str, actual_screen: str):
        self.expected_screen = expected_screen
        self.actual_screen = actual_screen
        super().__init__(
            f"Navigation failed: expected screen '{expected_screen}', "
            f"got '{actual_screen}'"
        )


class NPOPSNavigator:
    """State machine for NPOPS screen navigation.

    Traverses a defined transition table to navigate from the current
    mainframe screen to the ETD data entry screen (NPS025P1).
    """

    # Screen transition table: {current_screen: (command, target_screen, target_row, target_col)}
    TRANSITIONS: dict[str, tuple[str, str, int, int]] = {
        "M009000G": ("13<Enter>", "M009001G", 6, 71),
        "M009001G": ("11<Enter>", "NPS025M0", 3, 3),
        "NPS025M0": ("1<Enter>", "NPS025P1", 3, 3),
    }

    TARGET_SCREEN = "NPS025P1"

    def __init__(self, bluezone_client: BlueZoneClient):
        """Initialise the navigator with a BlueZone client.

        Args:
            bluezone_client: An active BlueZoneClient instance for
                terminal interaction.
        """
        self._client = bluezone_client
        self._logger = logging.getLogger(__name__)

    def identify_current_screen(self) -> str:
        """Identify which NPOPS screen is currently displayed.

        Delegates to the BlueZone client's screen identification method.

        Returns:
            The identified screen ID string, or "UNKNOWN" if no known
            screen is detected.
        """
        return self._client.get_current_screen_id()

    def navigate_to_etd_entry(self) -> None:
        """Navigate from the current screen to the ETD entry screen (NPS025P1).

        Follows the TRANSITIONS table step by step until NPS025P1 is reached.
        At each step, sends the defined command and waits for the target screen
        to appear at the expected position.

        Raises:
            NavigationError: If the current screen is UNKNOWN, not in the
                transitions table, or if a transition fails (target screen
                not reached).
        """
        current_screen = self.identify_current_screen()
        self._logger.info("Starting navigation from screen: %s", current_screen)

        # Already at target
        if current_screen == self.TARGET_SCREEN:
            self._logger.info("Already at target screen %s", self.TARGET_SCREEN)
            return

        # Unknown or unmapped screen
        if current_screen == "UNKNOWN" or current_screen not in self.TRANSITIONS:
            raise NavigationError(self.TARGET_SCREEN, current_screen)

        while current_screen != self.TARGET_SCREEN:
            command, target_screen, target_row, target_col = self.TRANSITIONS[current_screen]

            self._logger.debug(
                "Transitioning: %s -> %s (command='%s', wait at (%d, %d))",
                current_screen,
                target_screen,
                command,
                target_row,
                target_col,
            )

            # Send the navigation command
            self._client.send_keys(command)

            # Wait for the target screen identifier to appear
            arrived = self._client.wait_for_string(
                target_screen, target_row, target_col
            )

            if not arrived:
                actual = self.identify_current_screen()
                self._logger.error(
                    "Navigation failed: expected '%s' at (%d, %d), got '%s'",
                    target_screen,
                    target_row,
                    target_col,
                    actual,
                )
                raise NavigationError(target_screen, actual)

            self._logger.debug("Arrived at screen: %s", target_screen)
            current_screen = target_screen

        self._logger.info("Navigation complete — at target screen %s", self.TARGET_SCREEN)

    def return_to_entry_screen(self) -> None:
        """Return to the ETD entry screen (NPS025P1) by sending PF11.

        Used after a submission error to recover back to the entry screen.
        If already on NPS025P1, does nothing.

        Raises:
            NavigationError: If the screen is not NPS025P1 after sending PF11.
        """
        current_screen = self.identify_current_screen()

        if current_screen == self.TARGET_SCREEN:
            self._logger.debug("Already on entry screen %s", self.TARGET_SCREEN)
            return

        self._logger.info("Returning to entry screen via PF11 from '%s'", current_screen)
        self._client.send_keys("<PF11>")
        self._client.wait_host_quiet()

        # Verify we arrived
        actual_screen = self.identify_current_screen()
        if actual_screen != self.TARGET_SCREEN:
            self._logger.error(
                "PF11 recovery failed: expected '%s', got '%s'",
                self.TARGET_SCREEN,
                actual_screen,
            )
            raise NavigationError(self.TARGET_SCREEN, actual_screen)

        self._logger.info("Successfully returned to entry screen %s", self.TARGET_SCREEN)
