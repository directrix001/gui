"""ETD Formatter - Pure data transformation functions for ETD processing.

Handles date calculation, formatting, sorting, deduplication, and the
full processing pipeline for ETD records.
"""

from datetime import date, timedelta


class ETDFormatter:
    """Pure data transformation functions for ETD processing."""

    @staticmethod
    def calculate_etd_date(original_date: date) -> date:
        """Add 7 days to the original date.

        Args:
            original_date: The base date to calculate from.

        Returns:
            A new date 7 days after the original.
        """
        return original_date + timedelta(days=7)

    @staticmethod
    def format_date_ddmmyy(d: date) -> str:
        """Format date as 6-character zero-padded ddmmyy string.

        Args:
            d: The date to format.

        Returns:
            A 6-character string in ddmmyy format, e.g. date(2024, 7, 3) -> "030724".
        """
        day = f"{d.day:02d}"
        month = f"{d.month:02d}"
        year = f"{d.year % 100:02d}"
        return f"{day}{month}{year}"

    @staticmethod
    def sort_etd_data(records: list[dict]) -> list[dict]:
        """Sort ETD records by priority DESC, part_number ASC (numeric), date ASC.

        Sorting rules:
        - Priority: descending (higher priority first). None treated as 0.
        - Part number: ascending, treated as numeric (int conversion) where possible,
          otherwise sorted alphabetically.
        - ETD date: ascending.

        Args:
            records: List of dicts with keys: part_number, etd_date, quantity, priority.

        Returns:
            A new sorted list of records.
        """
        def sort_key(record):
            # Priority descending: negate for descending sort. None treated as 0.
            priority = record.get("priority") or 0
            priority_key = -priority

            # Part number ascending: try numeric sort, fallback to string
            part_number = record.get("part_number", "")
            try:
                part_number_key = (0, int(part_number), part_number)
            except (ValueError, TypeError):
                part_number_key = (1, 0, str(part_number))

            # ETD date ascending
            etd_date = record.get("etd_date", "")

            return (priority_key, part_number_key, etd_date)

        return sorted(records, key=sort_key)

    @staticmethod
    def deduplicate(records: list[dict], key: str = "part_number") -> list[dict]:
        """Remove duplicate records by key, keeping first occurrence.

        Args:
            records: List of dicts to deduplicate.
            key: The dict key to use for identifying duplicates.

        Returns:
            A new list with duplicates removed, preserving order.
        """
        seen = set()
        result = []
        for record in records:
            value = record.get(key)
            if value not in seen:
                seen.add(value)
                result.append(record)
        return result

    @staticmethod
    def _parse_date(value) -> date:
        """Parse a date value into a date object.

        Handles:
        - date objects (returned as-is)
        - Strings in dd.mm.yy format (e.g., "05.06.26")
        - Strings in other common formats as fallback

        Args:
            value: A date object or string to parse.

        Returns:
            A date object.

        Raises:
            ValueError: If the value cannot be parsed as a date.
        """
        if isinstance(value, date):
            return value

        if isinstance(value, str):
            value = value.strip()

            # Try dd.mm.yy format first (BO data format)
            if "." in value:
                parts = value.split(".")
                if len(parts) == 3:
                    day = int(parts[0])
                    month = int(parts[1])
                    year = int(parts[2])
                    # Handle 2-digit year
                    if year < 100:
                        year += 2000
                    return date(year, month, day)

            # Try dd/mm/yy or dd/mm/yyyy
            if "/" in value:
                parts = value.split("/")
                if len(parts) == 3:
                    day = int(parts[0])
                    month = int(parts[1])
                    year = int(parts[2])
                    if year < 100:
                        year += 2000
                    return date(year, month, day)

            # Try yyyy-mm-dd (ISO format)
            if "-" in value:
                parts = value.split("-")
                if len(parts) == 3:
                    year = int(parts[0])
                    month = int(parts[1])
                    day = int(parts[2])
                    return date(year, month, day)

        raise ValueError(f"Cannot parse date value: {value!r}")

    @staticmethod
    def process_pipeline(raw_records: list[dict]) -> list[dict]:
        """Run the full ETD formatting pipeline.

        Pipeline steps:
        1. Parse and calculate ETD dates (+7 days)
        2. Format dates as ddmmyy strings
        3. Sort by priority DESC, part_number ASC, date ASC
        4. Deduplicate by part_number (keep first occurrence)

        Input records have: part_number (str), etd_date (date or str), quantity (str),
                           priority (int or None)
        Output records have: part_number (str), etd_date (str in ddmmyy format),
                            quantity (str)

        Args:
            raw_records: List of dicts with raw ETD data.

        Returns:
            List of processed dicts with formatted dates, sorted and deduplicated.
        """
        # Step 1 & 2: Calculate new dates and format them
        processed = []
        for record in raw_records:
            original_date = ETDFormatter._parse_date(record["etd_date"])
            new_date = ETDFormatter.calculate_etd_date(original_date)
            formatted_date = ETDFormatter.format_date_ddmmyy(new_date)

            processed.append({
                "part_number": record["part_number"],
                "etd_date": formatted_date,
                "quantity": record["quantity"],
                "priority": record.get("priority") or 0,
            })

        # Step 3: Sort
        sorted_records = ETDFormatter.sort_etd_data(processed)

        # Step 4: Deduplicate
        deduplicated = ETDFormatter.deduplicate(sorted_records, key="part_number")

        # Remove priority from output (intermediate working column)
        result = []
        for record in deduplicated:
            result.append({
                "part_number": record["part_number"],
                "etd_date": record["etd_date"],
                "quantity": record["quantity"],
            })

        return result
