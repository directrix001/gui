"""Excel workbook handler for Nissan ETD processing.

Manages Excel workbook operations using openpyxl — no COM dependency
for spreadsheet I/O.
"""

from dataclasses import dataclass
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.worksheet.worksheet import Worksheet


class ExcelError(Exception):
    """Raised on workbook operation failure."""


@dataclass
class ETDRecord:
    """Represents a single ETD data row from the Excel workbook."""

    row: int
    part_number: str
    etd_date: str
    quantity: str


class ExcelHandler:
    """Read/write Excel workbooks using openpyxl."""

    def __init__(self, workbook_path: str):
        """Open workbook at path.

        Args:
            workbook_path: Path to the Excel workbook file.

        Raises:
            ExcelError: If the workbook file is not found.
        """
        path = Path(workbook_path)
        if not path.exists():
            raise ExcelError(f"Workbook not found: {workbook_path}")

        self._workbook_path = workbook_path
        self._wb = load_workbook(workbook_path)

    def get_sheet(self, sheet_name: str) -> Worksheet:
        """Get a worksheet by name.

        Args:
            sheet_name: Name of the worksheet to retrieve.

        Returns:
            The requested Worksheet object.

        Raises:
            ExcelError: If the sheet name is not found, listing available sheets.
        """
        if sheet_name not in self._wb.sheetnames:
            available = ", ".join(self._wb.sheetnames)
            raise ExcelError(
                f"Sheet '{sheet_name}' not found. "
                f"Available sheets: {available}"
            )
        return self._wb[sheet_name]

    def clear_range(
        self,
        sheet_name: str,
        start_row: int,
        start_col: int,
        end_row: int,
        end_col: int,
    ) -> None:
        """Clear all cell values in the specified range.

        Args:
            sheet_name: Name of the worksheet.
            start_row: First row of the range (1-indexed).
            start_col: First column of the range (1-indexed).
            end_row: Last row of the range (1-indexed).
            end_col: Last column of the range (1-indexed).
        """
        ws = self.get_sheet(sheet_name)
        for row in range(start_row, end_row + 1):
            for col in range(start_col, end_col + 1):
                ws.cell(row=row, column=col).value = None

    def write_records(
        self,
        sheet_name: str,
        records: list[tuple],
        start_row: int = 1,
        start_col: int = 1,
    ) -> None:
        """Write a list of record tuples to a worksheet, one tuple per row.

        Args:
            sheet_name: Name of the worksheet.
            records: List of tuples, each tuple is one row of data.
            start_row: Row to start writing at (1-indexed).
            start_col: Column to start writing at (1-indexed).
        """
        ws = self.get_sheet(sheet_name)
        for row_offset, record in enumerate(records):
            for col_offset, value in enumerate(record):
                ws.cell(
                    row=start_row + row_offset,
                    column=start_col + col_offset,
                ).value = value

    def read_etd_data(self, sheet_name: str) -> list[ETDRecord]:
        """Read ETD data from row 2 until an empty part_number cell.

        Reads part_number (col 1), etd_date (col 2), quantity (col 3)
        starting from row 2. Stops when column 1 is empty/None.
        All values are converted to strings.

        Args:
            sheet_name: Name of the worksheet containing ETD data.

        Returns:
            List of ETDRecord objects with row number and string values.
        """
        ws = self.get_sheet(sheet_name)
        records: list[ETDRecord] = []
        row = 2

        while True:
            part_number = ws.cell(row=row, column=1).value
            if part_number is None or str(part_number).strip() == "":
                break

            etd_date = ws.cell(row=row, column=2).value
            quantity = ws.cell(row=row, column=3).value

            records.append(
                ETDRecord(
                    row=row,
                    part_number=str(part_number),
                    etd_date=str(etd_date) if etd_date is not None else "",
                    quantity=str(quantity) if quantity is not None else "",
                )
            )
            row += 1

        return records

    def write_status(self, sheet_name: str, row: int, status: str) -> None:
        """Write processing status to column 4 of the given row.

        Args:
            sheet_name: Name of the worksheet.
            row: Row number to write the status to (1-indexed).
            status: Status text to write.
        """
        ws = self.get_sheet(sheet_name)
        ws.cell(row=row, column=4).value = status

    def save(self) -> None:
        """Save the workbook to disk."""
        self._wb.save(self._workbook_path)

    def close(self) -> None:
        """Close the workbook."""
        self._wb.close()
