"""BlueZone COM automation client for terminal emulator interaction.

Wraps the BlueZone 32-bit COM object (BZWhll.WhllObj) using win32com.client
to provide screen reading, keystroke sending, cursor positioning, and
host wait operations for NPOPS mainframe interaction.
"""

from __future__ import annotations

import logging
import time

import win32com.client


class BlueZoneError(Exception):
    """Raised on COM connection or interaction failure."""

    pass


class BlueZoneClient:
    """COM automation client for BlueZone terminal emulator.

    Creates a connection to the BlueZone WhllObj COM object and provides
    methods for reading screen text, sending keystrokes, positioning the
    cursor, and waiting for host responses.
    """

    # Known NPOPS screen identifiers and their reading positions
    SCREEN_POSITIONS: list[tuple[str, int, int]] = [
        ("M009000G", 3, 14),
        ("M009001G", 3, 13),
        ("NPS025M0", 3, 13),
        ("NPS025P1", 3, 3),
    ]

    def __init__(self, prog_id: str = "BZWhll.WhllObj", timeout_ms: int = 30000):
        """Create COM connection to BlueZone terminal emulator.

        Args:
            prog_id: The ProgID for the BlueZone COM object.
            timeout_ms: Timeout value in milliseconds for host operations.

        Raises:
            BlueZoneError: If the COM object, sessions, session, or screen
                cannot be obtained.
        """
        self._logger = logging.getLogger(__name__)
        self._logger.debug("Creating BlueZone COM object with ProgID: %s", prog_id)

        # Create the system COM object
        try:
            self._system = win32com.client.Dispatch(prog_id)
        except Exception as exc:
            raise BlueZoneError(
                f"Could not create BlueZone COM object '{prog_id}': {exc}"
            ) from exc

        if self._system is None:
            raise BlueZoneError("Could not create system object")

        # Get Sessions collection
        self._sessions = self._system.Sessions
        if self._sessions is None:
            raise BlueZoneError("Could not create sessions object")

        # Get active Session
        self._session = self._system.ActiveSession
        if self._session is None:
            raise BlueZoneError("Could not create session object — no active BlueZone session exists")

        # Get Screen from active session
        self._screen = self._session.Screen
        if self._screen is None:
            raise BlueZoneError("Could not create screen object")

        # Configure timeout and visibility
        self._system.TimeoutValue = timeout_ms
        self._session.Visible = True

        self._logger.info(
            "BlueZone COM connection established (ProgID=%s, timeout=%dms)",
            prog_id,
            timeout_ms,
        )

    def get_string(self, row: int, col: int, length: int) -> str:
        """Read text from the terminal screen at the given position.

        Args:
            row: Screen row (1-based).
            col: Screen column (1-based).
            length: Number of characters to read.

        Returns:
            The stripped text read from the screen.
        """
        result = self._screen.GetString(row, col, length)
        return result.strip() if result else ""

    def send_keys(self, keys: str) -> None:
        """Send keystrokes to the terminal.

        Supports BlueZone key notation such as <Enter>, <PF8>, <PF11>, etc.

        Args:
            keys: The keystroke string to send.
        """
        self._screen.SendKeys(keys)
        self._logger.debug("Sent keys: %s", keys)

    def move_to(self, row: int, col: int, max_retries: int = 10) -> None:
        """Move cursor to the specified row and column.

        Retries the move operation in a loop until the cursor is confirmed
        at the target position, matching the original VBA pattern:
            Do Until ExtraScreen.Row = row And ExtraScreen.Col = col
                ExtraScreen.MoveTo row, col, Null
            Loop

        Args:
            row: Target row (1-based).
            col: Target column (1-based).
            max_retries: Maximum number of attempts before raising an error.

        Raises:
            BlueZoneError: If the cursor cannot be positioned after max_retries.
        """
        for attempt in range(max_retries):
            if self._screen.Row == row and self._screen.Col == col:
                self._logger.debug("Cursor at position (%d, %d)", row, col)
                return
            self._screen.MoveTo(row, col, None)
            time.sleep(0.05)  # Brief pause between retries

        # Final check after all retries
        if self._screen.Row == row and self._screen.Col == col:
            self._logger.debug("Cursor at position (%d, %d)", row, col)
            return

        raise BlueZoneError(
            f"Failed to move cursor to ({row}, {col}) after {max_retries} retries. "
            f"Current position: ({self._screen.Row}, {self._screen.Col})"
        )

    def wait_for_string(
        self, text: str, row: int, col: int, timeout_ms: int | None = None
    ) -> bool:
        """Wait for specific text to appear at a screen position.

        Args:
            text: The text string to wait for.
            row: The row where the text is expected.
            col: The column where the text is expected.
            timeout_ms: Optional override for the default timeout (not used
                directly by BlueZone WaitForString, but reserved for future use).

        Returns:
            True if the text appeared, False if the wait timed out.
        """
        result = self._screen.WaitForString(text, row, col)
        self._logger.debug(
            "WaitForString('%s', %d, %d) -> %s", text, row, col, result
        )
        return bool(result)

    def wait_host_quiet(self, duration_ms: int = 500) -> None:
        """Wait for the host to become quiet (stop transmitting).

        Args:
            duration_ms: The quiet duration in milliseconds to wait for.
        """
        self._screen.WaitHostQuiet(duration_ms)
        self._logger.debug("WaitHostQuiet(%d) completed", duration_ms)

    def get_current_screen_id(self) -> str:
        """Identify which NPOPS screen is currently displayed.

        Reads text at known screen identifier positions and checks for
        recognized screen IDs. Tries positions in order:
            (3, 14) - M009000G
            (3, 13) - M009001G, NPS025M0
            (3, 3)  - NPS025P1

        Returns:
            The identified screen ID string, or "UNKNOWN" if no known
            screen is detected.
        """
        # Check position (3, 14) for M009000G
        text = self.get_string(3, 14, 8)
        if text == "M009000G":
            self._logger.debug("Current screen identified: M009000G")
            return "M009000G"

        # Check position (3, 13) for M009001G or NPS025M0
        text = self.get_string(3, 13, 8)
        if text == "M009001G":
            self._logger.debug("Current screen identified: M009001G")
            return "M009001G"
        if text == "NPS025M0":
            self._logger.debug("Current screen identified: NPS025M0")
            return "NPS025M0"

        # Check position (3, 3) for NPS025P1
        text = self.get_string(3, 3, 8)
        if text == "NPS025P1":
            self._logger.debug("Current screen identified: NPS025P1")
            return "NPS025P1"

        self._logger.warning(
            "Could not identify current screen. Text at (3,14)='%s', (3,13)='%s', (3,3)='%s'",
            self.get_string(3, 14, 8),
            self.get_string(3, 13, 8),
            self.get_string(3, 3, 8),
        )
        return "UNKNOWN"

    def disconnect(self) -> None:
        """Release all COM references.

        Sets internal COM object references to None to allow proper
        COM cleanup and garbage collection.
        """
        self._screen = None
        self._session = None
        self._sessions = None
        self._system = None
        self._logger.info("BlueZone COM connection disconnected")
