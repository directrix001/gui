"""Shared utilities for Nissan ETD processing."""

import getpass
import logging
import os
from logging.handlers import RotatingFileHandler
from pathlib import Path


def get_windows_username() -> str:
    """Get the current Windows login username.

    Uses os.getlogin() as the primary method, falling back to
    getpass.getuser() if os.getlogin() is unavailable (e.g., in
    non-interactive or service contexts).
    """
    try:
        return os.getlogin()
    except OSError:
        return getpass.getuser()


def configure_logging(config: dict) -> logging.Logger:
    """Configure application logging from a config dictionary.

    Reads logging settings from the config dict and sets up a rotating
    file handler and a console handler on the root logger.

    Args:
        config: Configuration dictionary with a "logging" key containing:
            - directory: Path to the log output directory (created if needed)
            - level: Logging level string (e.g., "INFO", "DEBUG")
            - format: Log message format string

    Returns:
        The configured root logger instance.
    """
    log_config = config.get("logging", {})
    log_directory = log_config.get("directory", "./logs")
    log_level = log_config.get("level", "INFO")
    log_format = log_config.get("format", "%(asctime)s [%(levelname)s] %(name)s: %(message)s")

    # Create log directory if it doesn't exist
    log_path = Path(log_directory)
    log_path.mkdir(parents=True, exist_ok=True)

    # Resolve numeric log level
    numeric_level = getattr(logging, log_level.upper(), logging.INFO)

    # Set up the root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(numeric_level)

    # Remove any existing handlers to avoid duplicate output on reconfiguration
    root_logger.handlers.clear()

    # Create formatter
    formatter = logging.Formatter(log_format)

    # File handler - rotating, 5MB max, keep 5 backups
    log_file = log_path / "nissan_etd.log"
    file_handler = RotatingFileHandler(
        log_file,
        maxBytes=5 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setLevel(numeric_level)
    file_handler.setFormatter(formatter)
    root_logger.addHandler(file_handler)

    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(numeric_level)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)

    return root_logger
