"""Database client for Nissan ETD processing.

Wraps pyodbc for ODBC connectivity with parameterised queries,
transaction management, and comprehensive logging.
"""

import logging
import time

import pyodbc


class DatabaseError(Exception):
    """Raised on connection or query failure."""


class DatabaseClient:
    """ODBC database client with parameterised query support."""

    def __init__(self, connection_string: str):
        """Establish a pyodbc connection.

        Args:
            connection_string: ODBC connection string for the target database.

        Raises:
            DatabaseError: If the connection cannot be established.
        """
        self._connection_string = connection_string
        self._logger = logging.getLogger(__name__)

        try:
            self._connection = pyodbc.connect(connection_string)
            self._logger.info("Database connection established.")
        except pyodbc.Error as exc:
            self._logger.error(
                "Failed to connect to database: %s", exc
            )
            raise DatabaseError(
                f"Failed to connect to database: {exc}"
            ) from exc

    def execute_query(self, query_name: str) -> list[dict]:
        """Execute a named query and return results as a list of dicts.

        Args:
            query_name: The SQL text or Access query name to execute.

        Returns:
            A list of dictionaries with column names as keys.

        Raises:
            DatabaseError: If the query execution fails.
        """
        self._logger.info("Executing query: %s", query_name)
        start = time.time()

        try:
            cursor = self._connection.cursor()
            cursor.execute(query_name)
            columns = [desc[0] for desc in cursor.description]
            rows = cursor.fetchall()
            results = [dict(zip(columns, row)) for row in rows]

            duration = time.time() - start
            self._logger.info(
                "Query '%s' completed in %.3fs, returned %d rows.",
                query_name, duration, len(results),
            )
            return results

        except pyodbc.Error as exc:
            duration = time.time() - start
            self._logger.error(
                "Query '%s' failed after %.3fs: %s",
                query_name, duration, exc,
            )
            self._connection.rollback()
            raise DatabaseError(
                f"Query '{query_name}' failed: {exc}"
            ) from exc

    def execute_stored_proc(
        self, proc_name: str, params: dict | None = None
    ) -> list[dict] | None:
        """Execute a stored procedure with parameterised binding.

        Uses the ODBC {CALL proc_name (?, ?, ...)} syntax with parameter
        values bound via the driver (NOT string interpolation).

        Args:
            proc_name: Name of the stored procedure.
            params: Dictionary of parameter names to values, or None.

        Returns:
            A list of dicts if the procedure returns a result set, else None.

        Raises:
            DatabaseError: If the procedure execution fails.
        """
        self._logger.info("Executing stored procedure: %s", proc_name)
        start = time.time()

        try:
            cursor = self._connection.cursor()

            if params:
                placeholders = ", ".join(["?"] * len(params))
                call_sql = f"{{CALL {proc_name} ({placeholders})}}"
                cursor.execute(call_sql, tuple(params.values()))
            else:
                call_sql = f"{{CALL {proc_name}}}"
                cursor.execute(call_sql)

            # Check if there are results to fetch
            if cursor.description:
                columns = [desc[0] for desc in cursor.description]
                rows = cursor.fetchall()
                results = [dict(zip(columns, row)) for row in rows]
            else:
                results = None

            duration = time.time() - start
            row_count = len(results) if results else 0
            self._logger.info(
                "Stored procedure '%s' completed in %.3fs, returned %d rows.",
                proc_name, duration, row_count,
            )
            return results

        except pyodbc.Error as exc:
            duration = time.time() - start
            self._logger.error(
                "Stored procedure '%s' failed after %.3fs: %s",
                proc_name, duration, exc,
            )
            self._connection.rollback()
            raise DatabaseError(
                f"Stored procedure '{proc_name}' failed: {exc}"
            ) from exc

    def execute_action(self, sql: str, params: tuple = ()) -> int:
        """Execute an INSERT, UPDATE, or DELETE statement.

        Commits on success, rolls back on failure.

        Args:
            sql: The SQL statement to execute.
            params: Tuple of parameters for parameterised binding.

        Returns:
            The number of affected rows.

        Raises:
            DatabaseError: If the execution fails.
        """
        self._logger.info("Executing action: %s", sql[:80])
        start = time.time()

        try:
            cursor = self._connection.cursor()
            cursor.execute(sql, params)
            affected = cursor.rowcount
            self._connection.commit()

            duration = time.time() - start
            self._logger.info(
                "Action completed in %.3fs, %d rows affected.",
                duration, affected,
            )
            return affected

        except pyodbc.Error as exc:
            duration = time.time() - start
            self._logger.error(
                "Action failed after %.3fs: %s", duration, exc
            )
            self._connection.rollback()
            raise DatabaseError(
                f"Action failed: {exc}"
            ) from exc

    def close(self) -> None:
        """Close the pyodbc connection."""
        self._connection.close()
        self._logger.info("Database connection closed.")

    def __enter__(self):
        """Enter context manager."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit context manager — close connection on exit."""
        self.close()
        return False
