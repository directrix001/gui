"""Picker claim report generator for Nissan ETD processing.

Generates summary and detailed picker claim reports by applying filters
via stored procedures and writing results to Excel workbooks.
"""

import logging
import os
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path

from openpyxl import Workbook

from src.config_manager import ConfigManager
from src.database_client import DatabaseClient


logger = logging.getLogger(__name__)

# Valid cost centre codes used in picker claim filtering.
COST_CENTRE_CODES = [
    "10", "11", "12", "21", "22", "30", "40", "41",
    "45", "46", "50", "55", "60", "61", "62", "65", "70",
]


@dataclass
class ReportFilters:
    """Filter parameters for picker claim reports."""

    start_date: date
    end_date: date
    stock_urgent_type: str  # "Stock", "VOR", or "All"
    dealer_account: str | None = None
    part_number: str | None = None
    picker_name: str | None = None
    team_id: str | None = None
    zones: dict[str, bool] = field(
        default_factory=lambda: {chr(i): True for i in range(65, 91)}
    )
    cost_centres: dict[str, bool] = field(
        default_factory=lambda: {code: True for code in COST_CENTRE_CODES}
    )


class ReportGenerator:
    """Generates picker claim reports (summary and detailed).

    Translates user filter selections into stored procedure parameters
    matching the original VBA qryNisC_PickerClaimFiltersSet interface.
    """

    STOCK_TYPE_MAP = {"Stock": "S%", "VOR": "V%", "All": "%"}

    def __init__(self, config: ConfigManager, db_client: DatabaseClient):
        """Initialise the report generator.

        Args:
            config: Configuration manager instance.
            db_client: Database client for executing stored procedures/queries.
        """
        self._config = config
        self._db = db_client
        self._logger = logging.getLogger(__name__)

    def generate_summary(self, filters: ReportFilters) -> str:
        """Generate a summary picker claim report.

        Applies filters via stored procedures, executes the summary query,
        and writes results to an Excel workbook.

        Args:
            filters: Report filter parameters.

        Returns:
            Path to the generated Excel report file.
        """
        self._logger.info("Generating summary report.")
        self._apply_filters(filters)

        # Determine which report query to run based on filters
        if filters.picker_name is None and filters.team_id is None:
            query_name = "rptNisC_PickerClaimReport_Sum"
        else:
            query_name = "rptNisC_PickerClaimReport_Sum_ByPicker"

        results = self._db.execute_query(query_name)
        output_path = self._write_report_to_excel(results, "Summary")

        self._logger.info("Summary report written to: %s", output_path)
        return output_path

    def generate_detailed(self, filters: ReportFilters) -> str:
        """Generate a detailed picker claim report.

        Applies filters via stored procedures, executes the detailed query,
        and writes results to an Excel workbook.

        Args:
            filters: Report filter parameters.

        Returns:
            Path to the generated Excel report file.
        """
        self._logger.info("Generating detailed report.")
        self._apply_filters(filters)

        # Determine which report query to run based on filters
        if filters.picker_name is None and filters.team_id is None:
            query_name = "rptNisC_PickerClaimReport_Detailed"
        else:
            query_name = "rptNisC_PickerClaimReport_Detailed_ByPicker"

        results = self._db.execute_query(query_name)
        output_path = self._write_report_to_excel(results, "Detailed")

        self._logger.info("Detailed report written to: %s", output_path)
        return output_path

    def _apply_filters(self, filters: ReportFilters) -> None:
        """Reset existing filters then set new filter values via stored procedures.

        Mirrors the VBA Set_Filters subroutine: calls qryNisC_PickerClaimFiltersReset
        to clear old filters, then calls qryNisC_PickerClaimFiltersSet with all
        filter parameters in the exact order expected by the stored procedure.

        Args:
            filters: Report filter parameters to apply.
        """
        username = self._get_windows_username()
        self._logger.info("Applying filters for user: %s", username)

        # Reset existing filters for this user
        self._db.execute_stored_proc(
            "qryNisC_PickerClaimFiltersReset",
            {"txtUserName": username},
        )

        # Map stock/urgent type to SQL LIKE pattern
        stock_type = self.STOCK_TYPE_MAP.get(filters.stock_urgent_type, "%")

        # Build SU variant parameters matching the VBA txtSU_01..04 pattern
        # These represent the suffixed variants used by the stored procedure
        su_variants = self._build_su_variants(filters.stock_urgent_type)

        # Translate zone and cost centre filters
        zone_params = self._translate_zone_filter(filters.zones)
        cc_params = self._translate_cost_centre_filter(filters.cost_centres)

        # Build the full parameter dictionary in the order expected by
        # qryNisC_PickerClaimFiltersSet (matches VBA parameter order exactly)
        params: dict[str, object] = {
            "txtUserName": username,
            "txtDate_Start": filters.start_date,
            "txtDate_End": filters.end_date,
            "txtSU": stock_type,
            "txtSU_01": su_variants["01"],
            "txtSU_02": su_variants["02"],
            "txtSU_03": su_variants["03"],
            "txtSU_04": su_variants["04"],
            "txtDealerNo": (filters.dealer_account or "") + "%",
            "txtPartNo": (filters.part_number or "") + "%",
            "txtPickerName": filters.picker_name or "",
        }

        # Add zone parameters (A-Z)
        for letter in (chr(i) for i in range(65, 91)):
            params[f"txtZone{letter}"] = zone_params[letter]

        # Add cost centre parameters
        for code in COST_CENTRE_CODES:
            params[f"txtCC{code}"] = cc_params[code]

        # Add team ID as the final parameter
        params["txtTeam_ID"] = filters.team_id or ""

        self._db.execute_stored_proc("qryNisC_PickerClaimFiltersSet", params)
        self._logger.info("Filters applied successfully.")

    def _build_su_variants(self, stock_urgent_type: str) -> dict[str, str]:
        """Build the SU variant parameters (txtSU_01 through txtSU_04).

        The VBA form has txtClaim_SU_01..04 fields which provide additional
        stock/urgent type pattern variants to the stored procedure.

        Args:
            stock_urgent_type: One of "Stock", "VOR", or "All".

        Returns:
            Dictionary with keys "01", "02", "03", "04" and their pattern values.
        """
        if stock_urgent_type == "Stock":
            return {"01": "S%", "02": "S%", "03": "S%", "04": "S%"}
        elif stock_urgent_type == "VOR":
            return {"01": "V%", "02": "V%", "03": "V%", "04": "V%"}
        else:
            # "All" — pass wildcard for all variants
            return {"01": "%", "02": "%", "03": "%", "04": "%"}

    def _translate_zone_filter(self, zones: dict[str, bool]) -> dict[str, str]:
        """Convert zone boolean selections to stored procedure parameter values.

        Each zone letter is either included (passes the letter itself) or
        excluded (passes "-" to filter it out).

        Args:
            zones: Dictionary mapping zone letters (A-Z) to True/False.

        Returns:
            Dictionary mapping zone letters to their parameter value
            (the letter if included, "-" if excluded).
        """
        result: dict[str, str] = {}
        for letter in (chr(i) for i in range(65, 91)):
            included = zones.get(letter, True)
            result[letter] = letter if included else "-"
        return result

    def _translate_cost_centre_filter(
        self, centres: dict[str, bool]
    ) -> dict[str, str]:
        """Convert cost centre boolean selections to stored procedure parameter values.

        Each cost centre code is either included (passes the code as a string)
        or excluded (passes "0").

        Args:
            centres: Dictionary mapping cost centre codes to True/False.

        Returns:
            Dictionary mapping cost centre codes to their parameter value
            (the code string if included, "0" if excluded).
        """
        result: dict[str, str] = {}
        for code in COST_CENTRE_CODES:
            included = centres.get(code, True)
            result[code] = code if included else "0"
        return result

    def _get_windows_username(self) -> str:
        """Get the current Windows login username.

        Uses os.getlogin() with a fallback to the USERNAME environment
        variable if os.getlogin() is unavailable.

        Returns:
            The current Windows username.
        """
        try:
            return os.getlogin()
        except OSError:
            self._logger.warning(
                "os.getlogin() unavailable, falling back to USERNAME env var."
            )
            return os.environ.get("USERNAME", "unknown")

    def _write_report_to_excel(
        self, results: list[dict], report_type: str
    ) -> str:
        """Write query results to a new Excel workbook.

        Args:
            results: List of row dictionaries from the database query.
            report_type: Label for the report (e.g., "Summary", "Detailed").

        Returns:
            Absolute path to the saved Excel file.
        """
        output_dir = self._config.get("logging.directory", "./logs")
        Path(output_dir).mkdir(parents=True, exist_ok=True)

        timestamp = date.today().strftime("%Y%m%d")
        filename = f"PickerClaimReport_{report_type}_{timestamp}.xlsx"
        output_path = str(Path(output_dir) / filename)

        wb = Workbook()
        ws = wb.active
        ws.title = report_type

        if results:
            # Write header row from dictionary keys
            headers = list(results[0].keys())
            for col_idx, header in enumerate(headers, start=1):
                ws.cell(row=1, column=col_idx, value=header)

            # Write data rows
            for row_idx, record in enumerate(results, start=2):
                for col_idx, header in enumerate(headers, start=1):
                    ws.cell(row=row_idx, column=col_idx, value=record[header])

        wb.save(output_path)
        wb.close()

        return output_path
