"""CLI entry point for Nissan UK RDC ETD Processing and Reporting Tools.

Provides subcommands for ETD processing, NPOPS export, ZVOR export,
database queries, and picker claim report generation.
"""

import argparse
import logging
import sys
import traceback
from datetime import date, datetime

from src.config_manager import ConfigManager, ConfigError
from src.etd_processor import ETDProcessor, ProcessResult
from src.report_generator import ReportGenerator, ReportFilters
from src.utils import configure_logging


logger = logging.getLogger(__name__)


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """Build and parse CLI arguments.

    Args:
        argv: Optional argument list (defaults to sys.argv[1:]).

    Returns:
        Parsed namespace with all CLI arguments.
    """
    parser = argparse.ArgumentParser(
        prog="nissan_etd",
        description="Nissan UK RDC ETD Processing and Reporting Tools",
    )
    parser.add_argument(
        "--config",
        help="Path to config.yaml (defaults to config.yaml in project root)",
        default=None,
    )

    subparsers = parser.add_subparsers(dest="operation", required=True)

    # ETD operations
    subparsers.add_parser(
        "full-etd-process", help="Run full ETD pipeline (import, format, submit)"
    )
    subparsers.add_parser(
        "format-only", help="Import and format data without NPOPS submission"
    )
    subparsers.add_parser(
        "export-npops-only", help="Submit pre-formatted data to NPOPS"
    )
    subparsers.add_parser(
        "zvor-export", help="Export ZVOR ETD parts data to Excel"
    )

    # Query operations
    sub_query = subparsers.add_parser(
        "run-query", help="Execute a named database query"
    )
    sub_query.add_argument("query_name", help="Name of the query to execute")

    # Report operations
    sub_report = subparsers.add_parser(
        "report", help="Generate picker claim report"
    )
    sub_report.add_argument(
        "--type",
        choices=["summary", "detailed"],
        required=True,
        dest="report_type",
        help="Type of report to generate",
    )
    sub_report.add_argument(
        "--start-date",
        required=True,
        help="Report start date (YYYY-MM-DD)",
    )
    sub_report.add_argument(
        "--end-date",
        required=True,
        help="Report end date (YYYY-MM-DD)",
    )
    sub_report.add_argument(
        "--stock-type",
        choices=["Stock", "VOR", "All"],
        default="All",
        help="Stock/urgent type filter (default: All)",
    )
    sub_report.add_argument(
        "--dealer",
        default=None,
        help="Dealer account filter",
    )
    sub_report.add_argument(
        "--part-number",
        default=None,
        help="Part number filter",
    )
    sub_report.add_argument(
        "--picker",
        default=None,
        help="Picker name filter",
    )
    sub_report.add_argument(
        "--team",
        default=None,
        help="Team ID filter",
    )
    sub_report.add_argument(
        "--zones",
        default=None,
        help="Comma-separated list of included zones (e.g., 'A,B,C,D')",
    )
    sub_report.add_argument(
        "--cost-centres",
        default=None,
        help="Comma-separated list of included cost centres (e.g., '10,11,21')",
    )

    return parser.parse_args(argv)


def _parse_date(date_string: str) -> date:
    """Parse a YYYY-MM-DD date string.

    Args:
        date_string: Date in YYYY-MM-DD format.

    Returns:
        A date object.

    Raises:
        SystemExit: If the date string is not valid.
    """
    try:
        return datetime.strptime(date_string, "%Y-%m-%d").date()
    except ValueError:
        print(f"Error: Invalid date format '{date_string}'. Expected YYYY-MM-DD.", file=sys.stderr)
        sys.exit(1)


def _build_zone_dict(zones_arg: str | None) -> dict[str, bool]:
    """Convert a comma-separated zones string to a zone filter dict.

    If zones_arg is None, all zones are included (default).

    Args:
        zones_arg: Comma-separated zone letters (e.g., "A,B,C") or None.

    Returns:
        Dictionary mapping each letter A-Z to True/False.
    """
    # Default: all zones included
    zone_dict = {chr(i): True for i in range(65, 91)}

    if zones_arg is not None:
        # Only the specified zones are included
        included = {z.strip().upper() for z in zones_arg.split(",")}
        zone_dict = {chr(i): (chr(i) in included) for i in range(65, 91)}

    return zone_dict


def _build_cost_centre_dict(cc_arg: str | None) -> dict[str, bool]:
    """Convert a comma-separated cost-centres string to a filter dict.

    If cc_arg is None, all cost centres are included (default).

    Args:
        cc_arg: Comma-separated cost centre codes (e.g., "10,11,21") or None.

    Returns:
        Dictionary mapping each valid cost centre code to True/False.
    """
    from src.report_generator import COST_CENTRE_CODES

    # Default: all cost centres included
    cc_dict = {code: True for code in COST_CENTRE_CODES}

    if cc_arg is not None:
        included = {c.strip() for c in cc_arg.split(",")}
        cc_dict = {code: (code in included) for code in COST_CENTRE_CODES}

    return cc_dict


def _handle_report(args: argparse.Namespace, config: ConfigManager) -> int:
    """Handle the 'report' subcommand.

    Args:
        args: Parsed CLI arguments.
        config: Validated configuration manager.

    Returns:
        Exit code (0 success, 1 error).
    """
    from src.database_client import DatabaseClient

    start_date = _parse_date(args.start_date)
    end_date = _parse_date(args.end_date)

    filters = ReportFilters(
        start_date=start_date,
        end_date=end_date,
        stock_urgent_type=args.stock_type,
        dealer_account=args.dealer,
        part_number=args.part_number,
        picker_name=args.picker,
        team_id=args.team,
        zones=_build_zone_dict(args.zones),
        cost_centres=_build_cost_centre_dict(args.cost_centres),
    )

    connection_string = config.get("database.connection_string")
    db_client = DatabaseClient(connection_string)

    try:
        generator = ReportGenerator(config, db_client)

        if args.report_type == "summary":
            output_path = generator.generate_summary(filters)
        else:
            output_path = generator.generate_detailed(filters)

        logger.info("Report generated: %s", output_path)
        print(f"Report generated: {output_path}")
        return 0
    finally:
        db_client.close()


def _handle_process_result(result: ProcessResult) -> int:
    """Determine exit code from a ProcessResult.

    Args:
        result: The process result to evaluate.

    Returns:
        0 if all rows succeeded, 2 if there were partial errors.
    """
    if result.error_count > 0:
        logger.warning(
            "Partial success: %d/%d rows had errors",
            result.error_count,
            result.total_rows,
        )
        return 2
    return 0


def main(argv: list[str] | None = None) -> int:
    """Main entry point for the Nissan ETD CLI.

    Args:
        argv: Optional argument list for testing (defaults to sys.argv[1:]).

    Returns:
        Exit code: 0 = success, 1 = fatal error, 2 = partial success.
    """
    args = parse_args(argv)

    # Load configuration
    try:
        config = ConfigManager(args.config)
    except ConfigError as exc:
        print(f"Configuration error: {exc}", file=sys.stderr)
        return 1

    # Validate configuration
    try:
        config.validate()
    except ConfigError as exc:
        print(f"Configuration validation failed: {exc}", file=sys.stderr)
        return 1

    # Configure logging from config
    log_config = {
        "logging": {
            "directory": config.get("logging.directory", "./logs"),
            "level": config.get("logging.level", "INFO"),
            "format": config.get(
                "logging.format",
                "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            ),
        }
    }
    configure_logging(log_config)

    logger.info("Starting operation: %s", args.operation)

    try:
        # Dispatch to appropriate handler
        if args.operation == "report":
            return _handle_report(args, config)

        # All other operations use ETDProcessor
        processor = ETDProcessor(config)

        if args.operation == "full-etd-process":
            result = processor.run_full_process()
            return _handle_process_result(result)

        elif args.operation == "format-only":
            formatted = processor.format_only()
            logger.info("Formatted %d records", len(formatted))
            print(f"Formatted {len(formatted)} records successfully.")
            return 0

        elif args.operation == "export-npops-only":
            result = processor.export_npops_only()
            return _handle_process_result(result)

        elif args.operation == "zvor-export":
            processor.zvor_export()
            logger.info("ZVOR export complete")
            print("ZVOR export completed successfully.")
            return 0

        elif args.operation == "run-query":
            results = processor.run_query(args.query_name)
            logger.info("Query returned %d rows", len(results))
            print(f"Query '{args.query_name}' returned {len(results)} rows.")
            return 0

    except Exception:
        logger.critical("Unhandled exception:\n%s", traceback.format_exc())
        print("A fatal error occurred. Check the log for details.", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
