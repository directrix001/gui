# Nissan UK RDC ETD Processing Tools

Python-based replacement for the Nissan UK RDC VBA/Access macro suite. This project automates ETD (Estimated Time of Delivery) processing, mainframe interaction via NPOPS through the BlueZone terminal emulator, ETD request management, and picker claim reporting.

## Requirements

- Python 3.10+ (32-bit) for BlueZone COM compatibility
- Windows environment with BlueZone terminal emulator installed
- ODBC driver for Microsoft Access / SQL Server
- Network access to shared drives (P:\, G:\)

## Setup

1. Copy `config.yaml.example` to `config.yaml` and update paths/credentials for your environment.
2. Install dependencies:

```bash
pip install -r requirements.txt
```

## Usage

All operations are invoked via the CLI entry point:

```bash
# Run the full ETD pipeline (import, format, submit to NPOPS)
python main.py full-etd-process

# Import and format data without mainframe submission
python main.py format-only

# Submit pre-formatted data to NPOPS
python main.py export-npops-only

# Export ZVOR ETD parts to Excel
python main.py zvor-export

# Execute a named database query
python main.py run-query <query_name>

# Generate a picker claim report
python main.py report --type summary --start-date 2024-01-01 --end-date 2024-01-31
```

Use `--config <path>` to specify an alternate configuration file.

## Project Structure

```
nissan_etd/
├── main.py                  # CLI entry point
├── config.yaml              # Local configuration (not committed)
├── config.yaml.example      # Configuration template
├── requirements.txt         # Python dependencies
├── src/                     # Source modules
│   ├── config_manager.py    # YAML config loading and validation
│   ├── database_client.py   # ODBC database access
│   ├── excel_handler.py     # Excel read/write via openpyxl
│   ├── bluezone_client.py   # BlueZone COM automation
│   ├── npops_navigator.py   # NPOPS screen navigation
│   ├── etd_processor.py     # ETD pipeline orchestration
│   ├── etd_formatter.py     # Date calculation, sorting, deduplication
│   ├── report_generator.py  # Picker claim reports
│   └── utils.py             # Shared utilities
├── tests/                   # Test suite
└── logs/                    # Log output directory
```

## Testing

```bash
pytest tests/
```

## Exit Codes

- `0` — Success
- `1` — Fatal error
- `2` — Partial success (some rows failed during ETD submission)
