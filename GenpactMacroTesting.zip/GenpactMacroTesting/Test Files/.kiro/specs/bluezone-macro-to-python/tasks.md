# Implementation Plan: BlueZone Macro to Python

## Overview

Convert the Nissan UK RDC VBA/Access macro suite into a modular Python package (`nissan_rdc`). Implementation follows the design's package structure, building incrementally from project scaffold and configuration through core infrastructure, BlueZone automation, ETD pipeline, reports, CLI integration, and tests.

## Tasks

- [ ] 1. Set up project structure and configuration
  - [ ] 1.1 Create package directory structure and `__init__.py` files
    - Create `nissan_rdc/` package with `__init__.py`, `__main__.py`
    - Create subpackages: `bluezone/`, `etd/`, `reports/` each with `__init__.py`
    - Create `tests/unit/`, `tests/property/`, `tests/integration/` directories
    - Add `requirements.txt` with: openpyxl, pyodbc, pywin32, PyYAML, pytest, hypothesis
    - _Requirements: 1.1, 1.5_

  - [ ] 1.2 Implement `config.py` — ConfigManager class
    - Implement `__init__` to load YAML config relative to script directory
    - Implement `get(key, default)` supporting dotted keys (e.g., `database.connection_string`)
    - Implement `require(*keys)` that raises `ConfigError` listing all missing keys
    - Implement `_apply_env_overrides()` using `NISSAN_RDC_` prefix and `__` nesting convention
    - Raise `ConfigError` with expected path when config file not found
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5_

  - [ ] 1.3 Create `config.yaml` default configuration template
    - Include all sections: database, excel, bluezone, npops, queries, picker_claims, logging
    - Use placeholder values matching the design schema
    - _Requirements: 1.5_

  - [ ] 1.4 Implement `logging_config.py` — logging setup
    - Configure logging from config values (directory, level, format, rotation)
    - Support max file size and backup count from config
    - Expose a `setup_logging(config)` function called at startup
    - _Requirements: 12.1, 12.5_

  - [ ] 1.5 Define error hierarchy in `nissan_rdc/__init__.py`
    - Implement `NissanRDCError`, `ConfigError`, `DatabaseError`, `ExcelError`
    - Implement `BlueZoneConnectionError`, `NavigationError`, `SubmissionError`
    - `NavigationError` stores expected_screen and actual_screen attributes
    - _Requirements: 1.4, 2.4, 2.5, 3.7, 5.5, 5.6, 6.5_

- [ ] 2. Implement core infrastructure — Database and Excel
  - [ ] 2.1 Implement `database.py` — DatabaseClient class
    - Implement `__init__` accepting connection string from config
    - Implement `execute_query(query_name, params)` returning `list[dict]`
    - Implement `execute_procedure(proc_name, params)` with parameterised binding
    - Implement context manager (`__enter__`/`__exit__`) for connection lifecycle
    - Log each query/procedure execution with operation name and duration
    - On connection failure: log error, raise `DatabaseError`
    - On query failure: log SQL error, rollback transaction, raise `DatabaseError`
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 12.3_

  - [ ] 2.2 Implement `excel_handler.py` — ExcelHandler class
    - Implement `__init__` to open workbook with openpyxl; raise `ExcelError` if not found
    - Implement `read_rows(sheet_name, start_row, columns, stop_on_empty_col)` — stop on empty cell
    - Implement `write_records(sheet_name, records, start_cell)` — write tuples to rows
    - Implement `clear_range(sheet_name, range_str)` — clear content before writing
    - Implement `write_cell(sheet_name, row, col, value, bold, font_color)` — single cell with formatting
    - Implement `save()` and `close()` methods
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7_

  - [ ]* 2.3 Write property tests for ConfigManager
    - **Property 1: Environment variable override** — verify env var takes precedence over YAML value
    - **Property 2: Missing key validation** — verify `ConfigError` lists all missing keys
    - **Validates: Requirements 1.2, 1.3**

  - [ ]* 2.4 Write property tests for ExcelHandler
    - **Property 3: Excel write/read round-trip** — write records then read back yields equivalent data
    - **Property 4: Excel read stop condition** — reading stops at first empty cell in stop column
    - **Validates: Requirements 3.2, 3.5**

  - [ ]* 2.5 Write unit tests for ConfigManager and DatabaseClient
    - Test loading valid YAML, missing file error, missing key validation
    - Mock pyodbc — verify parameterised binding, rollback on error, connection string usage
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 2.1, 2.2, 2.3, 2.4, 2.5_

  - [ ]* 2.6 Write unit tests for ExcelHandler
    - Test open, read columns, write records, clear range, file-not-found error using temp workbooks
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7_

- [ ] 3. Checkpoint — Core infrastructure
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 4. Implement BlueZone automation layer
  - [ ] 4.1 Implement `bluezone/client.py` — BlueZoneClient class
    - Implement `connect()` — create COM object via `win32com.client.Dispatch`, get Sessions/Session/Screen
    - Implement `get_string(row, col, length)` — read from screen
    - Implement `send_keys(keys)` — send keystrokes, supporting `<Enter>`, `<PF8>`, `<PF11>` tokens
    - Implement `move_to(row, col)` — move cursor with retry confirmation
    - Implement `wait_for_string(text, row, col, timeout_ms)` — poll for expected text
    - Implement `wait_host_quiet(ms)` — wait for host idle
    - Implement `disconnect()` — release COM references
    - Implement `current_screen_id` property — read screen ID from standard position
    - Raise `BlueZoneConnectionError` when COM unavailable or no session
    - Log each navigation step with result
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 12.2_

  - [ ] 4.2 Implement `bluezone/navigator.py` — NPOPSNavigator class
    - Define `SCREEN_CHAIN` from config (M009000G → M009001G → NPS025M0 → NPS025P1)
    - Implement `navigate_to_entry_screen()` — traverse chain from current screen
    - Implement `return_to_entry_screen()` — send PF11, wait for host quiet
    - Log expected vs actual screen on timeout; raise `NavigationError`
    - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.5, 6.6_

  - [ ]* 4.3 Write unit tests for BlueZoneClient and NPOPSNavigator
    - Mock COM objects — verify connect sequence, send_keys formatting, timeout handling
    - Mock BlueZoneClient — verify correct navigation sequences, timeout handling
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 6.1, 6.2, 6.3, 6.4, 6.5, 6.6_

- [ ] 5. Implement ETD processing pipeline
  - [ ] 5.1 Implement `etd/formatter.py` — ETDFormatter class
    - Implement `format_records(raw_rows)` — add 7 days, format ddmmyy, sort, deduplicate
    - Implement `add_days_and_format(date_val, days=7)` — date arithmetic + formatting
    - Sort: priority DESC, part_no ASC (numeric text), date ASC
    - Deduplicate on part number (keep first occurrence after sort)
    - Return list of `(part_number, formatted_date, quantity)` tuples
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6_

  - [ ] 5.2 Implement `etd/submitter.py` — ETDSubmitter class
    - Define `SubmissionResult` dataclass (row, part_number, status, success)
    - Implement `submit_row(part_no, etd_date, quantity)` — cursor moves, PF8 submit, read response
    - Implement `submit_batch(rows)` — iterate rows, navigate between submissions, handle errors
    - On success: status = "ETD Table Updated", success = True
    - On error: status = actual mainframe message, success = False
    - On navigation issue after submit: PF11 recovery, continue
    - On complete COM failure: save progress, raise error
    - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5, 7.6, 7.7_

  - [ ] 5.3 Implement `etd/processor.py` — ETDProcessor orchestration
    - Implement `run_full_pipeline(config)` — query DB, write to Excel, format, submit to NPOPS, write statuses
    - Implement `run_format_only(config)` — read BO file, format ETD data, write back to Excel
    - Implement `run_export_npops_only(config)` — read formatted data from Excel, submit to NPOPS
    - Implement `run_zvor_export(config)` — open ZVOR workbook, clear, query ZVOR_ETD_PARTs, write results
    - Log all significant operations (start, import, format, submit, completion) with timestamps
    - Log each row submission result (part number, status) for reconciliation
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 7.5, 7.6, 11.1, 11.2, 11.3, 12.1, 12.6, 13.1, 13.2, 13.3, 13.4_

  - [ ]* 5.4 Write property tests for ETDFormatter
    - **Property 5: Date formatting round-trip** — `add_days_and_format(date, 7)` produces valid ddmmyy, parseable back to date+7
    - **Property 6: Formatter output structure** — output is 3-tuples: non-empty part_no, 6-digit date, non-empty qty
    - **Property 7: Sort ordering invariant** — output maintains priority DESC, part_no ASC, date ASC
    - **Property 8: Deduplication uniqueness** — no duplicate part numbers in output
    - **Validates: Requirements 4.1, 4.2, 4.3, 4.4, 4.5, 4.6**

  - [ ]* 5.5 Write property test for ETDSubmitter response interpretation
    - **Property 9: Submission response interpretation** — success/failure maps correctly from response string
    - **Validates: Requirements 7.5, 7.6**

  - [ ]* 5.6 Write unit tests for ETDFormatter and ETDSubmitter
    - Test specific formatting examples, edge cases (year boundaries, leap years, empty input)
    - Mock BlueZoneClient — verify cursor positions, key sequences, response parsing
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 7.1, 7.2, 7.3, 7.4, 7.5, 7.6_

- [ ] 6. Checkpoint — ETD pipeline
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 7. Implement reports
  - [ ] 7.1 Implement `reports/picker_claims.py` — ReportGenerator class
    - Define `ClaimFilters` dataclass with all filter fields
    - Implement `apply_filters(filters)` — call reset proc then set proc with mapped parameters
    - Implement `generate_summary(filters, output_path)` — query data, write Excel report
    - Implement `generate_detailed(filters, output_path)` — query data, write Excel report
    - Map stock type: "Stock" → "S%", "VOR" → "V%", "All" → "%"
    - Auto-detect Windows username for audit via `os.getlogin()`
    - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5, 9.6, 9.7, 9.8, 10.1, 10.2, 10.3, 10.4, 10.5_

  - [ ]* 7.2 Write property test for stock type filter mapping
    - **Property 10: Stock type filter mapping** — "Stock" → "S%", "VOR" → "V%", "All" → "%"
    - **Validates: Requirements 9.4, 9.5, 9.6**

  - [ ]* 7.3 Write unit tests for ReportGenerator
    - Mock DatabaseClient — verify stored procedure call order, filter parameter mapping
    - Test zone/cost centre inclusion/exclusion logic
    - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5, 9.6, 9.7, 9.8, 10.1, 10.2, 10.3, 10.4, 10.5_

- [ ] 8. Implement CLI and ETD request management
  - [ ] 8.1 Implement `cli.py` — argparse CLI definition
    - Define subcommands: `full-etd-process`, `format-only`, `export-npops-only`, `zvor-export`, `run-query`, `report`
    - `run-query` accepts `--query-name` argument
    - `report` accepts `--type` (summary/detailed) and all filter arguments
    - Accept optional `--config` for alternative config file path
    - Reject invalid operation names with non-zero exit and valid operation list
    - _Requirements: 14.1, 14.2, 14.3, 14.4, 14.5_

  - [ ] 8.2 Implement `__main__.py` — entry point wiring
    - Parse CLI args, load config, setup logging
    - Dispatch to appropriate processor/report method based on operation
    - Implement ETD request management queries (find ETD info, ICS requests, outstanding ETD, archive, delete, part search)
    - Handle unhandled exceptions: log stack trace, exit code 1
    - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5, 8.6, 8.7, 8.8, 12.4, 14.1_

  - [ ]* 8.3 Write property test for CLI invalid operation rejection
    - **Property 11: Invalid operation rejection** — invalid operation names produce non-zero exit with valid ops list
    - **Validates: Requirements 14.4**

  - [ ]* 8.4 Write unit tests for CLI argument parsing
    - Test all subcommands parse correctly, invalid operation handling, --config flag
    - _Requirements: 14.1, 14.2, 14.3, 14.4, 14.5_

- [ ] 9. Final checkpoint
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties from the design document (Hypothesis library)
- Unit tests validate specific examples and edge cases (pytest)
- Integration tests (BlueZone COM, NPOPS navigation, database queries) are not included as automated tasks — they require live mainframe/BlueZone access and should be run manually on target machines
- All COM automation (pywin32) tasks require Windows with BlueZone installed

## Task Dependency Graph

```json
{
  "waves": [
    { "id": 0, "tasks": ["1.1", "1.5"] },
    { "id": 1, "tasks": ["1.2", "1.3", "1.4"] },
    { "id": 2, "tasks": ["2.1", "2.2"] },
    { "id": 3, "tasks": ["2.3", "2.4", "2.5", "2.6"] },
    { "id": 4, "tasks": ["4.1"] },
    { "id": 5, "tasks": ["4.2", "4.3"] },
    { "id": 6, "tasks": ["5.1", "5.2"] },
    { "id": 7, "tasks": ["5.3", "5.4", "5.5", "5.6"] },
    { "id": 8, "tasks": ["7.1"] },
    { "id": 9, "tasks": ["7.2", "7.3"] },
    { "id": 10, "tasks": ["8.1"] },
    { "id": 11, "tasks": ["8.2", "8.3", "8.4"] }
  ]
}
```
