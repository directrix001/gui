# Design Document: BlueZone Macro to Python

## Overview

This design converts the Nissan UK RDC VBA/Access macro suite into a modular Python package. The existing system uses 32-bit Microsoft Office COM automation with BlueZone terminal emulator to manage ETD data processing, NPOPS mainframe interaction, ETD request management, and picker claim reporting. The Python replacement removes the 32-bit Office dependency while maintaining all business functionality and output formats.

### Design Goals

- **File-location agnostic**: All paths loaded from YAML configuration
- **Lightweight on Citrix**: Only standard-library + 4 pure/simple packages (openpyxl, pyodbc, pywin32, PyYAML)
- **Same output**: End users see identical results (Excel files, mainframe updates, reports)
- **Observable**: Full logging of every operation for support diagnosis
- **Composable**: Each pipeline stage runnable independently via CLI

### Technology Stack

| Concern | Library | Rationale |
|---------|---------|-----------|
| Excel I/O | openpyxl | Pure Python, no Office install needed |
| Database | pyodbc | Standard ODBC driver for Access and SQL Server |
| BlueZone COM | win32com.client (pywin32) | Only way to automate 32-bit BlueZone |
| Configuration | PyYAML + os.environ | Human-readable config with env override |
| CLI | argparse (stdlib) | Zero extra dependency |
| Logging | logging (stdlib) | Built-in, configurable |
| Reports | openpyxl (Excel output) | Matches existing spreadsheet workflow |

## Architecture

### High-Level Architecture

```mermaid
graph TD
    CLI[CLI Entry Point<br/>main.py] --> CFG[Config Manager]
    CLI --> ETD[ETD Processor]
    CLI --> RPT[Report Generator]
    
    ETD --> XL[Excel Handler]
    ETD --> DB[Database Client]
    ETD --> BZ[BlueZone Client]
    
    RPT --> DB
    RPT --> XL
    
    BZ --> NAV[NPOPS Navigator]
    
    CFG -.->|provides config to| ETD
    CFG -.->|provides config to| RPT
    CFG -.->|provides config to| DB
    CFG -.->|provides config to| BZ
    CFG -.->|provides config to| XL
```

### Package Structure

```
nissan_rdc/
├── __init__.py
├── __main__.py              # python -m nissan_rdc entry point
├── cli.py                   # argparse CLI definition
├── config.py                # Config_Manager
├── database.py              # Database_Client
├── excel_handler.py         # Excel_Handler
├── bluezone/
│   ├── __init__.py
│   ├── client.py            # BlueZone_Client (COM connection)
│   └── navigator.py         # NPOPS_Navigator (screen navigation)
├── etd/
│   ├── __init__.py
│   ├── processor.py         # ETD_Processor orchestration
│   ├── formatter.py         # ETD data formatting logic
│   └── submitter.py         # NPOPS submission loop
├── reports/
│   ├── __init__.py
│   └── picker_claims.py     # Report_Generator
└── logging_config.py        # Logging setup
config.yaml                  # Default configuration file (alongside package)
```

### Data Flow: Full ETD Pipeline

```mermaid
sequenceDiagram
    participant User as CLI User
    participant CLI as cli.py
    participant CFG as Config Manager
    participant ETD as ETD Processor
    participant XL as Excel Handler
    participant DB as Database Client
    participant FMT as Formatter
    participant BZ as BlueZone Client
    participant MF as NPOPS Mainframe

    User->>CLI: python -m nissan_rdc full-etd-process
    CLI->>CFG: load config
    CFG-->>CLI: config dict
    CLI->>ETD: run_full_pipeline(config)
    
    ETD->>DB: execute("ETD COUNT DATE QRY")
    DB-->>ETD: raw records
    
    ETD->>XL: open_workbook(etd_file_path)
    ETD->>XL: clear_range("Dropoff", "A7:Z10000")
    ETD->>XL: write_records(records, "Dropoff", "ABZ")
    
    ETD->>FMT: format_etd_data(worksheet_data)
    FMT-->>ETD: formatted rows [(part_no, etd_date, qty), ...]
    
    ETD->>BZ: connect()
    BZ-->>ETD: session ready
    
    loop For each ETD row
        ETD->>BZ: navigate_to_nps025p1()
        BZ->>MF: screen navigation
        MF-->>BZ: NPS025P1 ready
        ETD->>BZ: submit_etd(part_no, date, qty)
        BZ->>MF: enter data + PF8
        MF-->>BZ: response message
        BZ-->>ETD: status (success/error message)
        ETD->>XL: write_status(row, status)
    end
    
    ETD->>XL: save_workbook()
    ETD-->>CLI: pipeline complete
```

## Components and Interfaces

### Config Manager (`config.py`)

```python
class ConfigManager:
    """Loads and validates YAML configuration with environment variable overrides."""
    
    def __init__(self, config_path: str | None = None):
        """Load config from file. If None, looks relative to script directory."""
        ...
    
    def get(self, key: str, default=None) -> Any:
        """Get a config value. Supports dotted keys (e.g., 'database.connection_string')."""
        ...
    
    def require(self, *keys: str) -> None:
        """Validate that all required keys exist. Raises ConfigError listing missing keys."""
        ...
    
    @staticmethod
    def _apply_env_overrides(config: dict) -> dict:
        """Override config values with NISSAN_RDC_* environment variables."""
        ...
```

**Environment variable convention**: `NISSAN_RDC_DATABASE__CONNECTION_STRING` overrides `database.connection_string` (double underscore = nested key separator).

### Database Client (`database.py`)

```python
class DatabaseClient:
    """ODBC database connection manager with parameterised query execution."""
    
    def __init__(self, connection_string: str):
        ...
    
    def execute_query(self, query_name: str, params: dict | None = None) -> list[dict]:
        """Execute a named query, return results as list of dicts."""
        ...
    
    def execute_procedure(self, proc_name: str, params: dict | None = None) -> list[dict] | None:
        """Execute a stored procedure with named parameters."""
        ...
    
    def close(self) -> None:
        ...
    
    def __enter__(self): ...
    def __exit__(self, *args): ...
```

### Excel Handler (`excel_handler.py`)

```python
class ExcelHandler:
    """Reads and writes Excel workbooks using openpyxl."""
    
    def __init__(self, file_path: str):
        """Open workbook at path. Raises FileNotFoundError if missing."""
        ...
    
    def read_rows(self, sheet_name: str, start_row: int = 2, 
                  columns: list[int] | None = None, 
                  stop_on_empty_col: int = 1) -> list[tuple]:
        """Read rows until stop column is empty."""
        ...
    
    def write_records(self, sheet_name: str, records: list[tuple], 
                      start_cell: str = "A7") -> None:
        """Write records to sheet starting at cell."""
        ...
    
    def clear_range(self, sheet_name: str, range_str: str) -> None:
        """Clear content in range."""
        ...
    
    def write_cell(self, sheet_name: str, row: int, col: int, value, 
                   bold: bool = False, font_color: str | None = None) -> None:
        """Write a single cell with optional formatting."""
        ...
    
    def save(self) -> None: ...
    def close(self) -> None: ...
```

### BlueZone Client (`bluezone/client.py`)

```python
class BlueZoneClient:
    """Manages COM connection to BlueZone terminal emulator."""
    
    def __init__(self, prog_id: str = "BZWhll.WhllObj", timeout_ms: int = 30000):
        ...
    
    def connect(self) -> None:
        """Establish COM connection to BlueZone. Raises BlueZoneConnectionError on failure."""
        ...
    
    def get_string(self, row: int, col: int, length: int) -> str:
        """Read string from screen at position."""
        ...
    
    def send_keys(self, keys: str) -> None:
        """Send keystrokes to terminal. Supports <Enter>, <PF8>, <PF11>, etc."""
        ...
    
    def move_to(self, row: int, col: int) -> None:
        """Move cursor to position, retrying until confirmed."""
        ...
    
    def wait_for_string(self, text: str, row: int, col: int, timeout_ms: int | None = None) -> bool:
        """Wait for text to appear at position. Returns True if found before timeout."""
        ...
    
    def wait_host_quiet(self, ms: int = 500) -> None:
        """Wait for host to become idle."""
        ...
    
    def disconnect(self) -> None: ...
    
    @property
    def current_screen_id(self) -> str:
        """Read screen identifier from standard position."""
        ...
```

### NPOPS Navigator (`bluezone/navigator.py`)

```python
class NPOPSNavigator:
    """Handles navigation through NPOPS mainframe screen hierarchy."""
    
    SCREEN_CHAIN = [
        ScreenStep(id="M009000G", read_pos=(3, 14), send="13", 
                   wait_id="M009001G", wait_pos=(6, 71)),
        ScreenStep(id="M009001G", read_pos=(3, 13), send="11", 
                   wait_id="NPS025M0", wait_pos=(3, 3)),
        ScreenStep(id="NPS025M0", read_pos=(3, 13), send="1", 
                   wait_id="NPS025P1", wait_pos=(3, 3)),
    ]
    
    def __init__(self, client: BlueZoneClient):
        ...
    
    def navigate_to_entry_screen(self) -> None:
        """Navigate from any known screen to NPS025P1. Raises NavigationError on failure."""
        ...
    
    def return_to_entry_screen(self) -> None:
        """Send PF11 to return to NPS025P1 after a submission."""
        ...
```

### ETD Formatter (`etd/formatter.py`)

```python
class ETDFormatter:
    """Pure data transformation: format, sort, and deduplicate ETD records."""
    
    @staticmethod
    def format_records(raw_rows: list[tuple]) -> list[tuple[str, str, str]]:
        """
        Transform raw ETD data:
        1. Add 7 days to date column
        2. Format as ddmmyy string
        3. Sort by priority DESC, part_no ASC (numeric text), date ASC
        4. Deduplicate on part number (keep first)
        5. Return (part_number, formatted_date, quantity) tuples
        """
        ...
    
    @staticmethod
    def add_days_and_format(date_val, days: int = 7) -> str:
        """Add days to a date and return ddmmyy string."""
        ...
```

### ETD Submitter (`etd/submitter.py`)

```python
@dataclass
class SubmissionResult:
    row: int
    part_number: str
    status: str        # "ETD Table Updated" or error message
    success: bool

class ETDSubmitter:
    """Submits formatted ETD rows to NPOPS via BlueZone."""
    
    def __init__(self, client: BlueZoneClient, navigator: NPOPSNavigator):
        ...
    
    def submit_row(self, part_no: str, etd_date: str, quantity: str) -> SubmissionResult:
        """Submit a single ETD record. Returns result with status."""
        ...
    
    def submit_batch(self, rows: list[tuple[str, str, str]]) -> list[SubmissionResult]:
        """Submit all rows, navigating as needed between submissions."""
        ...
```

### Report Generator (`reports/picker_claims.py`)

```python
@dataclass
class ClaimFilters:
    start_date: date
    end_date: date
    stock_type: str         # "Stock", "VOR", or "All" -> mapped to "S%", "V%", "%"
    dealer_account: str | None
    part_number: str | None
    picker_name: str | None
    team_id: str | None
    zones: dict[str, bool]        # {"A": True, "B": False, ...}
    cost_centres: dict[str, bool] # {"10": True, "11": False, ...}

class ReportGenerator:
    """Generates picker claim reports via stored procedures."""
    
    def __init__(self, db_client: DatabaseClient, excel_handler_factory):
        ...
    
    def apply_filters(self, filters: ClaimFilters) -> None:
        """Reset filters then set new ones via stored procedures."""
        ...
    
    def generate_summary(self, filters: ClaimFilters, output_path: str) -> None:
        """Generate summary report to Excel file."""
        ...
    
    def generate_detailed(self, filters: ClaimFilters, output_path: str) -> None:
        """Generate detailed report to Excel file."""
        ...
```

### Component Relationship Diagram

```mermaid
classDiagram
    class ConfigManager {
        +get(key) Any
        +require(*keys) None
    }
    
    class DatabaseClient {
        +execute_query(name, params) list
        +execute_procedure(name, params) list
        +close()
    }
    
    class ExcelHandler {
        +read_rows(sheet, start_row, columns) list
        +write_records(sheet, records, start_cell)
        +clear_range(sheet, range_str)
        +write_cell(sheet, row, col, value)
        +save()
    }
    
    class BlueZoneClient {
        +connect()
        +get_string(row, col, length) str
        +send_keys(keys)
        +move_to(row, col)
        +wait_for_string(text, row, col) bool
        +wait_host_quiet(ms)
    }
    
    class NPOPSNavigator {
        +navigate_to_entry_screen()
        +return_to_entry_screen()
    }
    
    class ETDFormatter {
        +format_records(raw_rows) list
        +add_days_and_format(date, days) str
    }
    
    class ETDSubmitter {
        +submit_row(part_no, date, qty) SubmissionResult
        +submit_batch(rows) list
    }
    
    class ETDProcessor {
        +run_full_pipeline()
        +run_format_only()
        +run_export_npops_only()
        +run_zvor_export()
    }
    
    class ReportGenerator {
        +apply_filters(filters)
        +generate_summary(filters, output_path)
        +generate_detailed(filters, output_path)
    }
    
    ETDProcessor --> ExcelHandler
    ETDProcessor --> DatabaseClient
    ETDProcessor --> ETDFormatter
    ETDProcessor --> ETDSubmitter
    ETDSubmitter --> BlueZoneClient
    ETDSubmitter --> NPOPSNavigator
    NPOPSNavigator --> BlueZoneClient
    ReportGenerator --> DatabaseClient
    ReportGenerator --> ExcelHandler
```

## Data Models

### Configuration Schema (`config.yaml`)

```yaml
# Database settings
database:
  connection_string: "DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=path\\to\\db.accdb"
  query_timeout: 60

# Excel file paths
excel:
  etd_file: "P:\\UKRDC\\ETD\\Assign New ETD.xls"
  zvor_file: "G:\\xxNPO\\VOR files\\ZVOR_Search.xlsm"
  backorder_file: "path\\to\\BO_UK-RDC.xlsx"
  report_output_dir: "path\\to\\reports"

# BlueZone terminal settings
bluezone:
  prog_id: "BZWhll.WhllObj"
  timeout_ms: 30000
  host_quiet_ms: 500

# NPOPS screen positions (row, col)
npops:
  screens:
    M009000G: {read_row: 3, read_col: 14, send: "13", wait_id: "M009001G", wait_row: 6, wait_col: 71}
    M009001G: {read_row: 3, read_col: 13, send: "11", wait_id: "NPS025M0", wait_row: 3, wait_col: 3}
    NPS025M0: {read_row: 3, read_col: 13, send: "1",  wait_id: "NPS025P1", wait_row: 3, wait_col: 3}
  entry_screen:
    id: "NPS025P1"
    part_no_pos: {row: 5, col: 24}
    etd_date_pos: {row: 13, col: 29}
    quantity_pos: {row: 13, col: 45}
    success_row: 1
    success_col: 2
    success_length: 80

# Named queries (map operation name -> SQL or stored proc name)
queries:
  etd_count_date: "ETD COUNT DATE QRY"
  zvor_etd_parts: "ZVOR_ETD_PARTs"
  find_etd_info: "find etd information"
  ics_requests_all: "ICS Requets all Info"
  ics_requests_ams: "ICS Requests to Ams"
  ics_requests_no_response: "ICS Requests No Response"
  outstanding_etd: "Outstanding ETD Requests"
  archive_solved: "archive solved requests"
  delete_solved: "delete solved requests"
  part_search: "MCR_Part number search"

# Picker claims stored procedures
picker_claims:
  filter_check_proc: "qryNisC_PickerClaimFilters"
  filter_reset_proc: "qryNisC_PickerClaimFiltersReset"
  filter_set_proc: "qryNisC_PickerClaimFiltersSet"
  cost_centres: [10, 11, 12, 21, 22, 30, 40, 41, 45, 46, 50, 55, 60, 61, 62, 65, 70]
  zones: "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

# Logging
logging:
  directory: "logs"
  level: "INFO"         # DEBUG, INFO, WARNING, ERROR
  format: "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
  max_file_size_mb: 10
  backup_count: 5
```

### ETD Record (Internal)

```python
@dataclass
class ETDRecord:
    part_number: str       # e.g., "12345A"
    etd_date: str          # formatted ddmmyy e.g., "150724"
    quantity: str          # e.g., "5"
    priority: int | None   # sort priority from raw data
    
@dataclass
class SubmissionResult:
    row_index: int
    part_number: str
    status: str            # "ETD Table Updated" or mainframe error text
    success: bool
```

### Backorder Import Columns

| Index | Column Name | Type | Description |
|-------|-------------|------|-------------|
| 0 | buyer | str | Buyer code |
| 1 | sales_part_no | str | Sales part number |
| 2 | sl_part_no | str | SL part number |
| 3 | description | str | Part description |
| 4 | dealer_code | str | Dealer code |
| 5 | order_number | str | Order reference |
| 6 | reference_number | str | Reference number |
| 7 | item_number | str | Item number |
| 8 | backorder_date | date | Date of backorder |
| 9 | backorder_qty | int | Backorder quantity |
| 10 | etd_reply | str | ETD reply value |
| 11 | reply_deadline | date | Reply deadline |
| 12 | comment | str | Comment field |
| 13 | auto_etd | str | Auto-ETD flag |
| 14 | rolos_code | str | ROLOS code |
| 15 | controller_comment | str | Controller comment |

### Picker Claim Filter Parameters

```python
@dataclass
class ClaimFilters:
    username: str                    # Windows login (auto-detected)
    start_date: date                 # Report start date
    end_date: date                   # Report end date
    stock_type: Literal["Stock", "VOR", "All"]  # Maps to "S%", "V%", "%"
    dealer_account: str | None       # Partial match with trailing %
    part_number: str | None          # Partial match with trailing %
    picker_name: str | None          # Full name filter
    team_id: str | None              # Team ID filter
    zones: dict[str, bool]           # A-Z, True = included
    cost_centres: dict[int, bool]    # 10-70, True = included
```



## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Environment variable override

*For any* configuration key present in the YAML file, if a corresponding environment variable (using the `NISSAN_RDC_` prefix and double-underscore nesting convention) is set, then `ConfigManager.get()` shall return the environment variable value rather than the file value.

**Validates: Requirements 1.2**

### Property 2: Missing key validation

*For any* non-empty set of required configuration keys and any configuration dictionary missing at least one of those keys, calling `ConfigManager.require()` shall raise a `ConfigError` whose message contains the name of every missing key.

**Validates: Requirements 1.3**

### Property 3: Excel write/read round-trip

*For any* list of record tuples written to a worksheet via `ExcelHandler.write_records()`, reading back the same range via `ExcelHandler.read_rows()` shall produce a list equivalent to the original records (preserving order and values).

**Validates: Requirements 3.2**

### Property 4: Excel read stop condition

*For any* worksheet where row N (starting from row 2) has an empty value in the stop column (column 1), `ExcelHandler.read_rows()` shall return exactly N−2 rows and shall not include any row at or beyond the first empty cell.

**Validates: Requirements 3.5**

### Property 5: Date formatting round-trip

*For any* valid date value, `ETDFormatter.add_days_and_format(date, 7)` shall produce a 6-character string in ddmmyy format, and parsing that string back to a date shall yield a date exactly 7 days after the input.

**Validates: Requirements 4.1, 4.2**

### Property 6: Formatter output structure

*For any* list of raw ETD input rows, the output of `ETDFormatter.format_records()` shall consist exclusively of 3-element tuples where element 0 is a non-empty string (part number), element 1 is a 6-character string matching the pattern `\d{6}` (ddmmyy date), and element 2 is a non-empty string (quantity).

**Validates: Requirements 4.5, 4.6**

### Property 7: Sort ordering invariant

*For any* list of ETD records with varying priorities, part numbers, and dates, the output of `ETDFormatter.format_records()` shall be sorted such that for any adjacent pair (a, b), either a.priority > b.priority, or (a.priority == b.priority and int(a.part_no) <= int(b.part_no)), or (a.priority == b.priority and a.part_no == b.part_no and a.date <= b.date).

**Validates: Requirements 4.3**

### Property 8: Deduplication uniqueness

*For any* list of ETD records (including records with duplicate part numbers), the output of `ETDFormatter.format_records()` shall contain no duplicate part numbers — every part number in the output list is unique.

**Validates: Requirements 4.4**

### Property 9: Submission response interpretation

*For any* part number string and any screen response string, if the response equals `"Part: {part_no} - ETD Table Updated"` then `SubmissionResult.success` shall be `True` and `status` shall be `"ETD Table Updated"`; otherwise `success` shall be `False` and `status` shall equal the actual response text (or a descriptive fallback if empty).

**Validates: Requirements 7.5, 7.6**

### Property 10: Stock type filter mapping

*For any* valid stock type input value from the set `{"Stock", "VOR", "All"}`, the filter mapping function shall produce exactly `"S%"`, `"V%"`, or `"%"` respectively, with no other output possible for these inputs.

**Validates: Requirements 9.4, 9.5, 9.6**

### Property 11: Invalid operation rejection

*For any* string that is not in the set of valid operation names (`full-etd-process`, `format-only`, `export-npops-only`, `zvor-export`, `run-query`, `report`), the CLI parser shall reject it with a non-zero exit code and display the list of valid operations.

**Validates: Requirements 14.4**

## Error Handling

### Strategy: Fail-Fast with Descriptive Context

The system follows a fail-fast philosophy. When an error makes further processing unreliable, execution halts immediately with enough context to diagnose the issue remotely.

### Error Hierarchy

```python
class NissanRDCError(Exception):
    """Base exception for all application errors."""
    pass

class ConfigError(NissanRDCError):
    """Configuration loading or validation failure."""
    pass

class DatabaseError(NissanRDCError):
    """Database connection or query execution failure."""
    pass

class ExcelError(NissanRDCError):
    """Excel file open, read, or write failure."""
    pass

class BlueZoneConnectionError(NissanRDCError):
    """COM connection to BlueZone failed."""
    pass

class NavigationError(NissanRDCError):
    """NPOPS screen navigation timeout or unexpected screen."""
    def __init__(self, expected_screen: str, actual_screen: str):
        super().__init__(f"Expected screen '{expected_screen}', got '{actual_screen}'")
        self.expected_screen = expected_screen
        self.actual_screen = actual_screen

class SubmissionError(NissanRDCError):
    """ETD row submission failed in a non-recoverable way."""
    pass
```

### Error Handling Patterns

| Scenario | Action |
|----------|--------|
| Config file missing | Raise `ConfigError` with expected path |
| Required config key missing | Raise `ConfigError` listing all missing keys |
| DB connection fails | Log error, raise `DatabaseError` |
| DB query fails | Log SQL error, rollback transaction, raise `DatabaseError` |
| Excel file missing | Raise `ExcelError` with attempted path |
| BlueZone COM unavailable | Raise `BlueZoneConnectionError` |
| No active BlueZone session | Raise `BlueZoneConnectionError` |
| Screen navigation timeout | Log expected vs actual, raise `NavigationError` |
| ETD submission returns error | Log and record status — continue to next row |
| Unhandled exception | Log full stack trace, exit with code 1 |

### Recovery Behaviour During Batch Submission

The ETD submission loop does NOT halt on individual row failures. Each row is processed independently:
- Success → write "ETD Table Updated" to status column (green)
- Mainframe error message → write that message to status column (red)
- Navigation issue after submit → send PF11 to recover, continue next row
- Complete COM failure → halt the batch, save progress, raise error

This matches the existing VBA behaviour where the macro continues processing remaining rows after an individual row error.

### Logging Integration

All exceptions are logged at `ERROR` level with:
- Timestamp
- Module and function name
- Full exception message
- Stack trace (for unhandled exceptions)
- Context data (file paths, screen IDs, part numbers) where applicable

## Testing Strategy

### Unit Tests (pytest)

Unit tests cover specific examples, edge cases, and component interactions with mocks:

- **ConfigManager**: Load valid YAML, missing file error, missing key validation
- **DatabaseClient**: Mock pyodbc — verify parameterised binding, rollback on error, connection string usage
- **ExcelHandler**: Temp workbook files — open, read columns, write records, clear range, file-not-found error
- **ETDFormatter**: Specific formatting examples, edge cases (year boundaries, leap years, empty input)
- **NPOPSNavigator**: Mock BlueZoneClient — verify correct navigation sequences, timeout handling
- **ETDSubmitter**: Mock BlueZoneClient — verify cursor positions, key sequences, response parsing
- **ReportGenerator**: Mock DatabaseClient — verify stored procedure call order, filter parameter mapping
- **CLI**: Argument parsing for all operations, invalid operation handling

### Property-Based Tests (Hypothesis)

Property-based tests validate universal correctness properties across generated inputs. Each property test runs a minimum of 100 iterations.

**Library**: [Hypothesis](https://hypothesis.readthedocs.io/) (Python's standard PBT library)

**Configuration**: Each test uses `@settings(max_examples=100)` minimum.

**Tag format**: Each test is annotated with a comment:
```python
# Feature: bluezone-macro-to-python, Property N: <property text>
```

Properties to implement:
1. Environment variable override (ConfigManager)
2. Missing key validation (ConfigManager)
3. Excel write/read round-trip (ExcelHandler)
4. Excel read stop condition (ExcelHandler)
5. Date formatting round-trip (ETDFormatter)
6. Formatter output structure (ETDFormatter)
7. Sort ordering invariant (ETDFormatter)
8. Deduplication uniqueness (ETDFormatter)
9. Submission response interpretation (ETDSubmitter)
10. Stock type filter mapping (ReportGenerator)
11. Invalid operation rejection (CLI)

### Integration Tests

Integration tests verify end-to-end behaviour with real external systems (run on machines with BlueZone and database access):

- **BlueZone COM connection**: Verify connect/disconnect cycle
- **NPOPS full navigation**: Navigate M009000G → NPS025P1
- **Database query execution**: Run a known query, verify results
- **Full ETD pipeline**: Small batch of test parts through the complete pipeline

### Test Structure

```
tests/
├── unit/
│   ├── test_config.py
│   ├── test_database.py
│   ├── test_excel_handler.py
│   ├── test_etd_formatter.py
│   ├── test_navigator.py
│   ├── test_submitter.py
│   ├── test_reports.py
│   └── test_cli.py
├── property/
│   ├── test_config_properties.py
│   ├── test_excel_properties.py
│   ├── test_formatter_properties.py
│   ├── test_submitter_properties.py
│   ├── test_reports_properties.py
│   └── test_cli_properties.py
└── integration/
    ├── test_bluezone_connection.py
    ├── test_npops_navigation.py
    ├── test_database_queries.py
    └── test_full_pipeline.py
```
