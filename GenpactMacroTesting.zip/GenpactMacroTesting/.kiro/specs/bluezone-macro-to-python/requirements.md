# Requirements Document

## Introduction

This document defines the requirements for converting the Nissan UK RDC (Regional Distribution Centre) VBA/Access macro suite to Python scripts. The existing system relies on 32-bit Microsoft Office and BlueZone terminal emulator COM automation to manage ETD (Estimated Time of Delivery) data processing, mainframe interaction via the NPOPS system, ETD request management, and picker claim reporting. The organisation is migrating to 64-bit Office, which cannot call 32-bit BlueZone COM objects directly. The Python conversion bridges this gap — 32-bit Python communicates with 32-bit BlueZone while coexisting with 64-bit Office, and uses openpyxl for Excel file I/O without any Office COM dependency.

## Glossary

- **ETD_Processor**: The Python module responsible for orchestrating the ETD data pipeline (import, format, export to mainframe)
- **BlueZone_Client**: The Python module that manages COM automation of the BlueZone terminal emulator for mainframe screen interaction
- **NPOPS_Navigator**: The component within BlueZone_Client that handles navigation through NPOPS mainframe screens (M009000G → M009001G → NPS025M0 → NPS025P1)
- **Excel_Handler**: The Python module responsible for reading, writing, and formatting Excel workbook data using openpyxl
- **Database_Client**: The Python module responsible for ODBC connectivity to Access/SQL Server databases and execution of queries and stored procedures
- **Report_Generator**: The Python module responsible for producing picker claim reports (summary and detailed views)
- **Config_Manager**: The Python module responsible for loading configuration from external files or environment variables to achieve file-location-agnostic operation
- **ETD**: Estimated Time of Delivery — the date a backordered part is expected to arrive
- **NPOPS**: Nissan Parts Ordering and Processing System — the mainframe system accessed via BlueZone
- **Backorder**: A parts order that cannot be fulfilled from current stock and awaits future delivery
- **PF_Key**: Program Function key used to send commands to the mainframe (e.g., PF8 = submit, PF11 = back)
- **Dropoff_Sheet**: The Excel worksheet named "Dropoff" where ETD data is staged for processing
- **Picker_Claim**: A claim record generated when a warehouse picker reports a discrepancy
- **Cost_Centre**: A numeric code (10–70) representing a warehouse operational area
- **Zone**: A single letter (A–Z) representing a warehouse storage zone

## Requirements

### Requirement 1: Configuration Management

**User Story:** As a system administrator, I want all file paths, database connections, and environment-specific settings stored in external configuration, so that the scripts can run on any machine without code changes.

#### Acceptance Criteria

1. THE Config_Manager SHALL load configuration values from a YAML or INI configuration file located relative to the script directory
2. THE Config_Manager SHALL support overriding any configuration value via environment variables
3. THE Config_Manager SHALL validate that all required configuration keys are present at startup and report missing keys with descriptive error messages
4. WHEN a configuration file is not found at the expected path, THE Config_Manager SHALL raise a descriptive error indicating the expected file location
5. THE Config_Manager SHALL store the following configurable values: database connection string, ETD Excel file path, BlueZone COM object identifier, NPOPS screen timeout duration, and log file directory

### Requirement 2: Database Connectivity

**User Story:** As a data analyst, I want the Python scripts to connect to the existing Access/SQL Server databases and execute queries and stored procedures, so that all data operations continue to function after migration.

#### Acceptance Criteria

1. THE Database_Client SHALL connect to the database using an ODBC connection string defined in configuration
2. WHEN a named query is executed, THE Database_Client SHALL return the result set as a list of records
3. WHEN a stored procedure is executed with parameters, THE Database_Client SHALL pass all parameters using parameterised binding
4. IF a database connection fails, THEN THE Database_Client SHALL log the error details and raise a descriptive exception
5. IF a query execution fails, THEN THE Database_Client SHALL log the SQL error, roll back any open transaction, and raise a descriptive exception
6. THE Database_Client SHALL support executing the stored procedures: qryNisC_PickerClaimFilters, qryNisC_PickerClaimFiltersReset, and qryNisC_PickerClaimFiltersSet

### Requirement 3: Excel Data Import and Export

**User Story:** As an ETD coordinator, I want the Python scripts to read from and write to Excel workbooks, so that I can continue using spreadsheets as the data interchange format.

#### Acceptance Criteria

1. THE Excel_Handler SHALL open an Excel workbook at the path specified in configuration and access a named worksheet
2. WHEN exporting database records, THE Excel_Handler SHALL write all records from a query result set into the specified worksheet starting at a defined named range
3. THE Excel_Handler SHALL clear existing content in the target range before writing new data
4. WHEN reading ETD data for mainframe export, THE Excel_Handler SHALL read part number from column 1, ETD date from column 2, and quantity from column 3, starting from row 2
5. THE Excel_Handler SHALL continue reading rows until an empty part number cell is encountered
6. WHEN a row is processed by the mainframe, THE Excel_Handler SHALL write the processing status to column 4 of that row
7. IF the specified workbook file does not exist, THEN THE Excel_Handler SHALL raise a descriptive error with the attempted file path

### Requirement 4: ETD Data Formatting

**User Story:** As an ETD coordinator, I want the imported backorder data to be automatically formatted with calculated ETD dates, sorted, and deduplicated, so that only valid unique records are submitted to the mainframe.

#### Acceptance Criteria

1. WHEN raw data is imported, THE ETD_Processor SHALL calculate a new ETD date by adding 7 days to the original date in column B
2. THE ETD_Processor SHALL format the calculated ETD date as a six-character string in ddmmyy format
3. THE ETD_Processor SHALL sort the data by priority column descending, then by part number ascending (treating values as numeric text), then by date ascending
4. THE ETD_Processor SHALL remove duplicate rows based on part number (column A), keeping the first occurrence after sorting
5. THE ETD_Processor SHALL replace the original date column with the formatted ddmmyy date values
6. THE ETD_Processor SHALL remove any intermediate working columns after formatting is complete

### Requirement 5: BlueZone COM Connection

**User Story:** As a system operator, I want the Python scripts to establish a COM connection to the BlueZone terminal emulator, so that automated mainframe interaction can proceed.

#### Acceptance Criteria

1. THE BlueZone_Client SHALL create a COM connection to the BlueZone WhllObj using the ProgID defined in configuration
2. WHEN the COM connection is established, THE BlueZone_Client SHALL obtain references to the Sessions collection and the active Session object
3. THE BlueZone_Client SHALL obtain a reference to the Screen object from the active session
4. THE BlueZone_Client SHALL set the timeout value to the duration specified in configuration
5. IF the BlueZone COM object cannot be created, THEN THE BlueZone_Client SHALL raise a descriptive error indicating BlueZone is not available
6. IF the active session cannot be obtained, THEN THE BlueZone_Client SHALL raise a descriptive error indicating no active BlueZone session exists

### Requirement 6: NPOPS Screen Navigation

**User Story:** As an ETD coordinator, I want the scripts to automatically navigate through the NPOPS mainframe screens to reach the ETD update screen, so that ETD data can be submitted without manual terminal operation.

#### Acceptance Criteria

1. WHEN the current screen is M009000G, THE NPOPS_Navigator SHALL send "13" followed by Enter and wait for screen M009001G to appear at row 6, column 71
2. WHEN the current screen is M009001G, THE NPOPS_Navigator SHALL send "11" followed by Enter and wait for screen NPS025M0 to appear at row 3, column 3
3. WHEN the current screen is NPS025M0, THE NPOPS_Navigator SHALL send "1" followed by Enter and wait for screen NPS025P1 to appear at row 3, column 3
4. THE NPOPS_Navigator SHALL identify the current screen by reading text at defined row and column positions using GetString
5. IF an expected screen does not appear within the configured timeout, THEN THE NPOPS_Navigator SHALL log the error with the expected and actual screen identifiers and raise a navigation error
6. WHEN navigation back to NPS025P1 is required after a submission, THE NPOPS_Navigator SHALL send PF11 and wait for the host to become quiet

### Requirement 7: NPOPS ETD Data Submission

**User Story:** As an ETD coordinator, I want each ETD record (part number, date, quantity) to be submitted to the NPOPS mainframe automatically, so that the ETD table is updated without manual data entry.

#### Acceptance Criteria

1. WHEN on screen NPS025P1, THE BlueZone_Client SHALL move the cursor to row 5, column 24 and send the part number
2. WHEN the part number is entered, THE BlueZone_Client SHALL move the cursor to row 13, column 29 and send the ETD date
3. WHEN the ETD date is entered, THE BlueZone_Client SHALL move the cursor to row 13, column 45 and send the quantity
4. WHEN all fields are entered, THE BlueZone_Client SHALL send PF8 to submit the record and wait for the host to become quiet
5. WHEN the submission response contains "ETD Table Updated" for the current part number, THE ETD_Processor SHALL record a success status for that row
6. WHEN the submission response does not contain the expected success message, THE ETD_Processor SHALL record the actual mainframe message text as the error status for that row
7. IF the screen identifier after submission is not NPS025P1, THEN THE BlueZone_Client SHALL send PF11 to return to the data entry screen before processing the next row

### Requirement 8: ETD Request Management Operations

**User Story:** As an ETD administrator, I want to run data management operations (find ETD info, view ICS requests, archive solved requests, delete solved requests, search part numbers), so that the ETD request queue stays current.

#### Acceptance Criteria

1. WHEN the "find ETD information" operation is invoked, THE Database_Client SHALL execute the corresponding named query and return results
2. WHEN the "ICS Requests all Info" operation is invoked, THE Database_Client SHALL execute the corresponding named query and return results
3. WHEN the "ICS Requests to Ams" operation is invoked, THE Database_Client SHALL execute the corresponding named query and return results
4. WHEN the "ICS Requests No Response" operation is invoked, THE Database_Client SHALL execute the corresponding named query and return results
5. WHEN the "Outstanding ETD Requests" operation is invoked, THE Database_Client SHALL execute the corresponding named query and return results
6. WHEN the "archive solved requests" operation is invoked, THE Database_Client SHALL execute the archive query to move solved records to the solved table
7. WHEN the "delete solved requests" operation is invoked, THE Database_Client SHALL execute the delete query to remove solved records from the active table
8. WHEN the "Part number search" operation is invoked, THE Database_Client SHALL accept a part number parameter and return matching records

### Requirement 9: Picker Claim Report Filtering

**User Story:** As a warehouse supervisor, I want to filter picker claim data by date range, stock/VOR type, zones, cost centres, dealer number, part number, picker name, and team, so that I can generate targeted reports.

#### Acceptance Criteria

1. THE Report_Generator SHALL accept filter parameters: start date, end date, stock/urgent type, dealer account number, part number, picker full name, and team ID
2. THE Report_Generator SHALL accept zone filter selections for zones A through Z, where each zone is either included or excluded
3. THE Report_Generator SHALL accept cost centre filter selections for cost centres 10, 11, 12, 21, 22, 30, 40, 41, 45, 46, 50, 55, 60, 61, 62, 65, and 70
4. WHEN the stock/urgent type filter is "Stock", THE Report_Generator SHALL pass "S%" as the filter value
5. WHEN the stock/urgent type filter is "VOR", THE Report_Generator SHALL pass "V%" as the filter value
6. WHEN the stock/urgent type filter is "All", THE Report_Generator SHALL pass "%" as the filter value
7. THE Report_Generator SHALL obtain the current Windows username and pass it to the stored procedures for audit purposes
8. WHEN filters are applied, THE Report_Generator SHALL first call qryNisC_PickerClaimFiltersReset to clear existing filters, then call qryNisC_PickerClaimFiltersSet with all filter parameters

### Requirement 10: Picker Claim Report Generation

**User Story:** As a warehouse supervisor, I want to generate summary and detailed picker claim reports, so that I can review warehouse picking accuracy.

#### Acceptance Criteria

1. WHEN a summary report is requested without a picker name or team filter, THE Report_Generator SHALL produce a summary report for all pickers
2. WHEN a summary report is requested with a picker name or team filter, THE Report_Generator SHALL produce a summary report filtered to the specified picker or team
3. WHEN a detailed report is requested without a picker name or team filter, THE Report_Generator SHALL produce a detailed report for all pickers
4. WHEN a detailed report is requested with a picker name or team filter, THE Report_Generator SHALL produce a detailed report filtered to the specified picker or team
5. THE Report_Generator SHALL output reports in a portable format (PDF or Excel) rather than requiring Microsoft Access

### Requirement 11: Backorder Data Import

**User Story:** As an ETD coordinator, I want to import the latest backorder data from the BO_UK-RDC spreadsheet, so that the ETD process works with current data.

#### Acceptance Criteria

1. WHEN the ETD process is initiated, THE ETD_Processor SHALL import backorder data from the BO_UK-RDC Excel file at the path specified in configuration
2. THE ETD_Processor SHALL read the following columns from the backorder file: buyer, sales part number, SL part number, description, dealer code, order number, reference number, item number, backorder date, backorder quantity, ETD reply, reply deadline, comment, auto-ETD, ROLOS code, and controller comment
3. IF the backorder file does not exist at the configured path, THEN THE ETD_Processor SHALL raise a descriptive error with the attempted file path

### Requirement 12: Logging and Error Handling

**User Story:** As a support engineer, I want all script operations logged with timestamps and error details, so that issues can be diagnosed without reproducing them.

#### Acceptance Criteria

1. THE ETD_Processor SHALL log all significant operations (start, data import, formatting, mainframe submission, completion) with timestamps to a log file
2. THE BlueZone_Client SHALL log each screen navigation step and the result (success or failure) with timestamps
3. THE Database_Client SHALL log each query or stored procedure execution with the operation name and execution duration
4. IF an unhandled exception occurs, THEN THE ETD_Processor SHALL log the full stack trace and exit with a non-zero return code
5. THE Config_Manager SHALL configure the log file location and log level (DEBUG, INFO, WARNING, ERROR) from the configuration file
6. THE ETD_Processor SHALL log each row submission result (part number, status) to enable reconciliation

### Requirement 13: ZVOR Export Operation

**User Story:** As a VOR coordinator, I want to export ZVOR ETD parts data from the database to an Excel workbook, so that I can review VOR search results in spreadsheet format.

#### Acceptance Criteria

1. WHEN the ZVOR export operation is invoked, THE ETD_Processor SHALL open the ZVOR Excel workbook at the path specified in configuration
2. THE ETD_Processor SHALL clear existing content in the Dropoff sheet before writing new data
3. THE ETD_Processor SHALL execute the "ZVOR_ETD_PARTs" query and write the results to the Dropoff sheet
4. IF the ZVOR workbook path is not configured, THEN THE ETD_Processor SHALL raise a descriptive error indicating the missing configuration

### Requirement 14: Command-Line Interface

**User Story:** As a system operator, I want to invoke each script operation from the command line with named arguments, so that the scripts can be scheduled, automated, or run individually.

#### Acceptance Criteria

1. THE ETD_Processor SHALL accept a command-line argument specifying the operation to perform: full-etd-process, format-only, export-npops-only, zvor-export, or run-query
2. WHEN the "run-query" operation is specified, THE ETD_Processor SHALL accept an additional argument for the query name
3. WHEN the "report" operation is specified, THE Report_Generator SHALL accept arguments for report type (summary or detailed) and all filter parameters
4. IF an invalid operation name is provided, THEN THE ETD_Processor SHALL display the list of valid operations and exit with a non-zero return code
5. THE ETD_Processor SHALL accept an optional argument to specify an alternative configuration file path
