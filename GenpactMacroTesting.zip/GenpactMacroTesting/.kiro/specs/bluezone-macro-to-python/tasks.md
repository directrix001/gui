# Implementation Plan: BlueZone Macro to Python Migration

## Overview

Convert the Nissan UK RDC VBA/Access macro suite into standalone Python scripts. Implementation proceeds bottom-up: shared utilities and configuration first, then data layer modules (database, Excel), then BlueZone COM automation, then orchestration and reporting, and finally the CLI entry point that wires everything together.

## Tasks

- [x] 1. Set up project structure, dependencies, and core utilities
  - [x] 1.1 Create project skeleton and install dependencies
    - Create `nissan_etd/` directory structure: `src/`, `tests/`, `logs/`
    - Create `src/__init__.py`, `tests/__init__.py`
    - Create `requirements.txt` with: pywin32==306, openpyxl==3.1.2, pyodbc==5.1.0, PyYAML==6.0.1, hypothesis==6.100.0, pytest==8.1.1, reportlab==4.1.0
    - Create `config.yaml.example` with the full configuration schema from the design document
    - _Requirements: 1.1, 1.5_

  - [x] 1.2 Implement `src/utils.py` shared utilities
    - Implement `get_windows_username()` using `os.getlogin()` or `getpass.getuser()`
    - Implement logging setup helper `configure_logging(config)` that reads log directory and level from config and creates file + console handlers
    - _Requirements: 12.5_

- [x] 2. Implement Configuration Manager
  - [x] 2.1 Implement `src/config_manager.py`
    - Create `ConfigError` exception class
    - Create `ConfigManager` class with `__init__(config_path)` that loads YAML file (defaults to `config.yaml` in script directory)
    - Implement `get(dotted_key, default)` method for dot-notation access (e.g., `database.connection_string`)
    - Implement environment variable override: `NISSAN_ETD__{SECTION}__{KEY}` pattern
    - Implement `validate()` method that checks all `REQUIRED_KEYS` and raises `ConfigError` with list of missing keys
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5_

  - [x]* 2.2 Write property tests for ConfigManager
    - **Property 1: Configuration loading with environment override**
    - **Property 2: Configuration validation rejects incomplete configs**
    - **Validates: Requirements 1.1, 1.2, 1.3**

  - [x]* 2.3 Write unit tests for ConfigManager (`tests/test_config_manager.py`)
    - Test loading a valid YAML file
    - Test file-not-found raises ConfigError with path
    - Test environment variable override format
    - Test validate() with missing keys lists all missing key names
    - _Requirements: 1.1, 1.2, 1.3, 1.4_

- [x] 3. Implement Database Client
  - [x] 3.1 Implement `src/database_client.py`
    - Create `DatabaseError` exception class
    - Create `DatabaseClient` class with `__init__(connection_string)` that establishes pyodbc connection
    - Implement `execute_query(query_name)` returning list of dicts (column names as keys)
    - Implement `execute_stored_proc(proc_name, params)` with parameterised binding
    - Implement `execute_action(sql, params)` for INSERT/UPDATE/DELETE returning affected row count
    - Implement `close()` method to release connection
    - Add logging for each query execution with operation name and duration
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 12.3_

  - [x]* 3.2 Write property tests for DatabaseClient
    - **Property 3: Database result set mapping**
    - **Property 4: Parameterised query binding**
    - **Validates: Requirements 2.2, 2.3**

  - [x]* 3.3 Write unit tests for DatabaseClient (`tests/test_database_client.py`)
    - Test connection failure raises DatabaseError with details
    - Test query failure triggers rollback and raises DatabaseError
    - Test execute_query returns correct list-of-dicts structure
    - Test stored procedure parameter passing (mocked pyodbc)
    - _Requirements: 2.4, 2.5, 2.6_

- [x] 4. Implement Excel Handler
  - [x] 4.1 Implement `src/excel_handler.py`
    - Create `ExcelError` exception class and `ETDRecord` dataclass
    - Create `ExcelHandler` class with `__init__(workbook_path)` that opens workbook via openpyxl (raises ExcelError if not found)
    - Implement `get_sheet(sheet_name)` with error for invalid sheet names listing available sheets
    - Implement `clear_range(sheet_name, start_row, start_col, end_row, end_col)`
    - Implement `write_records(sheet_name, records, start_row, start_col)` for writing tuples
    - Implement `read_etd_data(sheet_name)` reading from row 2 until empty part_number cell, returning list of `ETDRecord`
    - Implement `write_status(sheet_name, row, status)` writing to column 4
    - Implement `save()` method
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7_

  - [x]* 4.2 Write property tests for ExcelHandler
    - **Property 5: Excel write-then-read round trip**
    - **Property 6: ETD data reading with stop condition**
    - **Validates: Requirements 3.2, 3.3, 3.4, 3.5**

  - [x]* 4.3 Write unit tests for ExcelHandler (`tests/test_excel_handler.py`)
    - Test file-not-found raises ExcelError with path
    - Test invalid sheet name raises ExcelError listing available sheets
    - Test write_records clears range then writes data
    - Test read_etd_data stops at empty part_number
    - _Requirements: 3.1, 3.7_

- [x] 5. Checkpoint - Core data layer verification
  - Ensure all tests pass, ask the user if questions arise.

- [x] 6. Implement ETD Formatter (pure logic)
  - [x] 6.1 Implement `src/etd_formatter.py`
    - Create `ETDFormatter` class with all static methods
    - Implement `calculate_etd_date(original_date)` adding 7 days
    - Implement `format_date_ddmmyy(d)` producing zero-padded 6-char string
    - Implement `sort_etd_data(records)` sorting by priority DESC, part_number ASC, date ASC
    - Implement `deduplicate(records, key)` keeping first occurrence
    - Implement `process_pipeline(raw_records)` combining all transformations
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6_

  - [x]* 6.2 Write property tests for ETDFormatter
    - **Property 7: ETD date calculation and formatting**
    - **Property 8: ETD sort ordering invariant**
    - **Property 9: Deduplication preserves first occurrence and ensures uniqueness**
    - **Validates: Requirements 4.1, 4.2, 4.3, 4.4, 4.5**

  - [x]* 6.3 Write unit tests for ETDFormatter (`tests/test_etd_formatter.py`)
    - Test date calculation across month/year boundaries and leap years
    - Test ddmmyy format zero-padding (e.g., day 1 → "01", month 3 → "03")
    - Test sort with equal priorities, ties in part_number
    - Test deduplication with no duplicates, all duplicates, mixed
    - _Requirements: 4.1, 4.2, 4.3, 4.4_

- [x] 7. Implement BlueZone Client (COM automation)
  - [x] 7.1 Implement `src/bluezone_client.py`
    - Create `BlueZoneError` exception class
    - Create `BlueZoneClient` class with `__init__(prog_id, timeout_ms)` that creates COM object via `win32com.client.Dispatch`
    - Obtain Sessions collection, active Session, and Screen objects
    - Implement `get_string(row, col, length)` reading from screen
    - Implement `send_keys(keys)` sending keystrokes (supporting `<Enter>`, `<PFn>` notation)
    - Implement `move_to(row, col)` with retry until cursor positioned
    - Implement `wait_for_string(text, row, col, timeout_ms)` returning bool
    - Implement `wait_host_quiet(duration_ms)`
    - Implement `get_current_screen_id()` reading screen ID from standard position
    - Implement `disconnect()` to release COM references
    - Add logging for each screen interaction step
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 12.2_

  - [x]* 7.2 Write unit tests for BlueZoneClient (mocked COM)
    - Test COM creation failure raises BlueZoneError
    - Test no active session raises BlueZoneError
    - Test get_string, send_keys, move_to with mocked Screen object
    - Test wait_for_string timeout returns False
    - _Requirements: 5.5, 5.6_

- [x] 8. Implement NPOPS Navigator (screen state machine)
  - [x] 8.1 Implement `src/npops_navigator.py`
    - Create `NavigationError` exception class with expected/actual screen fields
    - Create `NPOPSNavigator` class with `__init__(bluezone_client)`
    - Define `TRANSITIONS` dict and `SCREEN_POSITIONS` dict from design
    - Implement `identify_current_screen()` reading text at defined positions
    - Implement `navigate_to_etd_entry()` traversing transitions from current screen to NPS025P1
    - Implement `return_to_entry_screen()` sending PF11 and waiting for host quiet
    - Raise `NavigationError` if expected screen not reached within timeout
    - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.5, 6.6_

  - [x]* 8.2 Write property tests for NPOPSNavigator
    - **Property 10: NPOPS navigation state machine correctness**
    - **Property 11: ETD field entry positioning**
    - **Validates: Requirements 6.1, 6.2, 6.3, 6.4, 7.1, 7.2, 7.3**

  - [x]* 8.3 Write unit tests for NPOPSNavigator (`tests/test_npops_navigator.py`)
    - Test navigation from each known screen to NPS025P1 (mocked BlueZoneClient)
    - Test timeout on unexpected screen raises NavigationError
    - Test PF11 recovery path
    - _Requirements: 6.5, 6.6_

- [x] 9. Checkpoint - COM and navigation layer verification
  - Ensure all tests pass, ask the user if questions arise.

- [x] 10. Implement ETD Processor (pipeline orchestration)
  - [x] 10.1 Implement `src/etd_processor.py`
    - Create `ETDProcessError` exception, `ProcessResult` and `RowResult` dataclasses
    - Create `ETDProcessor` class with `__init__(config)` instantiating ConfigManager, DatabaseClient, ExcelHandler
    - Implement `run_full_process()`: import BO data → format → submit to NPOPS → record statuses → return ProcessResult
    - Implement `format_only()`: import and format without mainframe submission
    - Implement `export_npops_only(formatted_data)`: submit pre-formatted data to NPOPS
    - Implement `zvor_export()`: open ZVOR workbook, clear Dropoff sheet, execute ZVOR_ETD_PARTs query, write results
    - Implement `run_query(query_name)`: execute named query via DatabaseClient
    - Implement row-level submission loop: enter part_number at (5,24), etd_date at (13,29), quantity at (13,45), send PF8, parse response
    - Implement response parsing: check for "ETD Table Updated" → success, else record error message
    - Handle row-level failures (log and continue) vs navigation failures (halt)
    - Log all significant operations with timestamps
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 7.1, 7.2, 7.3, 7.4, 7.5, 7.6, 7.7, 8.1–8.8, 11.1, 11.2, 11.3, 12.1, 12.4, 12.6, 13.1, 13.2, 13.3, 13.4_

  - [x]* 10.2 Write property tests for ETD submission response parsing
    - **Property 12: Submission response status parsing**
    - **Property 15: Backorder column import completeness**
    - **Validates: Requirements 7.5, 7.6, 11.2**

  - [x]* 10.3 Write unit tests for ETDProcessor (mocked dependencies)
    - Test full pipeline with mocked DB, Excel, and BlueZone
    - Test row-level error continues processing
    - Test navigation failure halts processing
    - Test ZVOR export flow
    - _Requirements: 7.5, 7.6, 7.7, 13.1, 13.2, 13.3_

- [x] 11. Implement Report Generator
  - [x] 11.1 Implement `src/report_generator.py`
    - Create `ReportFilters` dataclass with all filter fields (start_date, end_date, stock_urgent_type, dealer_account, part_number, picker_name, team_id, zones dict, cost_centres dict)
    - Create `ReportGenerator` class with `__init__(config, db_client)`
    - Define `STOCK_TYPE_MAP`: {"Stock": "S%", "VOR": "V%", "All": "%"}
    - Implement `_translate_zone_filter(zones)`: included zone → letter, excluded → "-"
    - Implement `_translate_cost_centre_filter(centres)`: included → code string, excluded → "0"
    - Implement `_apply_filters(filters)`: call qryNisC_PickerClaimFiltersReset then qryNisC_PickerClaimFiltersSet
    - Implement `_get_windows_username()` for audit parameter
    - Implement `generate_summary(filters)`: apply filters → execute summary query → write to Excel/PDF → return path
    - Implement `generate_detailed(filters)`: apply filters → execute detailed query → write to Excel/PDF → return path
    - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5, 9.6, 9.7, 9.8, 10.1, 10.2, 10.3, 10.4, 10.5_

  - [x]* 11.2 Write property tests for ReportGenerator filter translation
    - **Property 13: Zone and cost centre filter translation**
    - **Validates: Requirements 9.2, 9.3**

  - [x]* 11.3 Write unit tests for ReportGenerator (`tests/test_report_generator.py`)
    - Test stock type mapping (Stock→S%, VOR→V%, All→%)
    - Test zone filter translation with mixed included/excluded
    - Test cost centre filter translation
    - Test filter application order (reset then set)
    - Test summary vs detailed routing
    - _Requirements: 9.4, 9.5, 9.6, 9.7, 9.8, 10.1, 10.2, 10.3, 10.4_

- [x] 12. Implement CLI Entry Point and wire everything together
  - [x] 12.1 Implement `main.py` CLI entry point
    - Create argparse parser with `--config` optional argument
    - Create subparsers for: full-etd-process, format-only, export-npops-only, zvor-export, run-query, report
    - Add `query_name` positional argument to run-query subparser
    - Add report arguments: --type (summary/detailed), --start-date, --end-date, --stock-type, --dealer, --part-number, --picker, --team, --zones, --cost-centres
    - Wire each subcommand to corresponding ETDProcessor or ReportGenerator method
    - Implement proper exit codes: 0=success, 1=fatal error, 2=partial success
    - Wrap execution in try/except with full stack trace logging on unhandled exceptions
    - _Requirements: 14.1, 14.2, 14.3, 14.4, 14.5, 12.4_

  - [x]* 12.2 Write property tests for CLI validation
    - **Property 14: CLI operation validation**
    - **Validates: Requirements 14.1, 14.4**

  - [x]* 12.3 Write unit tests for CLI argument parsing
    - Test each valid subcommand is accepted
    - Test invalid subcommand shows help and exits non-zero
    - Test --config argument is passed to ConfigManager
    - Test report arguments are correctly parsed into ReportFilters
    - _Requirements: 14.1, 14.2, 14.3, 14.4, 14.5_

- [x] 13. Create test fixtures and conftest
  - [x] 13.1 Implement `tests/conftest.py` with shared fixtures
    - Create fixture for temporary config YAML file
    - Create fixture for in-memory openpyxl workbook with sample ETD data
    - Create fixture for mocked pyodbc connection and cursor
    - Create fixture for mocked BlueZone COM objects (Session, Screen)
    - Create fixture for sample ETDRecord lists
    - _Requirements: All (testing infrastructure)_

- [x] 14. Final checkpoint - Full integration verification
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties from the design document
- Unit tests validate specific examples and edge cases
- All BlueZone COM interactions are mocked in automated tests — live testing requires manual execution on a BlueZone-equipped machine
- Python 3.10+ (32-bit) is required for the target Citrix environment
- Database integration tests require a real Access/SQL Server connection and should be run manually

## Task Dependency Graph

```json
{
  "waves": [
    { "id": 0, "tasks": ["1.1", "1.2"] },
    { "id": 1, "tasks": ["2.1"] },
    { "id": 2, "tasks": ["2.2", "2.3", "3.1"] },
    { "id": 3, "tasks": ["3.2", "3.3", "4.1"] },
    { "id": 4, "tasks": ["4.2", "4.3", "6.1"] },
    { "id": 5, "tasks": ["6.2", "6.3", "7.1"] },
    { "id": 6, "tasks": ["7.2", "8.1"] },
    { "id": 7, "tasks": ["8.2", "8.3"] },
    { "id": 8, "tasks": ["10.1", "11.1"] },
    { "id": 9, "tasks": ["10.2", "10.3", "11.2", "11.3"] },
    { "id": 10, "tasks": ["12.1", "13.1"] },
    { "id": 11, "tasks": ["12.2", "12.3"] }
  ]
}
```
