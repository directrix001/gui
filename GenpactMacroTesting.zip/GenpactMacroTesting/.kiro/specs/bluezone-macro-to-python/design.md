A Design Document: BlueZone Macro to Python Migration

## Overview

This design describes the architecture for converting the Nissan UK RDC VBA/Access macro suite into standalone Python scripts. The system automates ETD (Estimated Time of Delivery) processing, mainframe interaction via NPOPS through the BlueZone terminal emulator, ETD request management, and picker claim reporting.

The Python implementation targets a Windows Citrix environment using 32-bit Python to interface with the 32-bit BlueZone COM objects. This allows the organisation to migrate to 64-bit Office — Python handles BlueZone automation independently and uses openpyxl for Excel file I/O (no Office COM dependency). The design prioritises:

- **File-location agnosticism** via YAML-based configuration
- **Standalone operation** — no web server or framework dependencies
- **CLI-first interface** — all operations invokable from command line
- **Same outputs** as the original VBA macros
- **Robust error handling** with comprehensive logging

### Key Technology Decisions

| Concern | Choice | Rationale |
|---------|--------|-----------|
| Excel I/O | openpyxl | Pure Python, no COM dependency for Excel files |
| Database | pyodbc | Standard ODBC driver for Access/SQL Server |
| BlueZone COM | win32com.client (pywin32) | Required for 32-bit COM automation |
| Configuration | PyYAML | Human-readable, supports nested structures |
| CLI | argparse | stdlib, no extra dependencies |
| Logging | logging (stdlib) | Configurable, supports file + console output |
| Reports | openpyxl / reportlab | Excel or PDF output without Access |


## Architecture

### High-Level Architecture

```mermaid
graph TD
    CLI[CLI Entry Point<br>main.py] --> CFG[Config Manager]
    CLI --> ETD[ETD Processor]
    CLI --> RPT[Report Generator]
    
    ETD --> DB[Database Client]
    ETD --> XL[Excel Handler]
    ETD --> BZ[BlueZone Client]
    
    RPT --> DB
    RPT --> XL
    
    BZ --> NAV[NPOPS Navigator]
    
    CFG --> |config.yaml| ALL[All Modules]
    
    subgraph "External Systems"
        ACC[(Access/SQL Server DB)]
        TERM[BlueZone Terminal<br>32-bit COM]
        FILES[Excel Workbooks]
    end
    
    DB --> ACC
    BZ --> TERM
    XL --> FILES
```

### Project Structure

```
nissan_etd/
├── main.py                  # CLI entry point (argparse)
├── config.yaml              # Default configuration file
├── config.yaml.example      # Template with documentation
├── requirements.txt         # Python dependencies
├── README.md
├── src/
│   ├── __init__.py
│   ├── config_manager.py    # YAML loading, env var override, validation
│   ├── database_client.py   # pyodbc connection, query execution, stored procs
│   ├── excel_handler.py     # openpyxl read/write operations
│   ├── bluezone_client.py   # COM automation wrapper
│   ├── npops_navigator.py   # Screen navigation state machine
│   ├── etd_processor.py     # ETD pipeline orchestration
│   ├── etd_formatter.py     # Date calculation, sorting, deduplication
│   ├── report_generator.py  # Picker claim report generation
│   └── utils.py             # Shared utilities (Windows username, etc.)
├── tests/
│   ├── __init__.py
│   ├── test_config_manager.py
│   ├── test_database_client.py
│   ├── test_excel_handler.py
│   ├── test_etd_formatter.py
│   ├── test_npops_navigator.py
│   ├── test_report_generator.py
│   └── conftest.py          # Shared fixtures
└── logs/                    # Default log output directory
```


## Components and Interfaces

### 1. Config Manager (`src/config_manager.py`)

Responsible for loading, merging, and validating configuration from YAML files and environment variables.

```python
class ConfigManager:
    """Loads config from YAML with environment variable overrides."""
    
    REQUIRED_KEYS = [
        "database.connection_string",
        "etd.excel_path",
        "bluezone.prog_id",
        "bluezone.timeout_ms",
        "logging.directory",
    ]
    
    def __init__(self, config_path: str | None = None):
        """Load config from path. Defaults to config.yaml in script dir."""
        ...
    
    def get(self, dotted_key: str, default=None) -> Any:
        """Retrieve a config value using dot notation (e.g., 'database.connection_string')."""
        ...
    
    def validate(self) -> None:
        """Raise ConfigError if any required keys are missing."""
        ...

class ConfigError(Exception):
    """Raised when configuration is invalid or missing."""
    ...
```

**Environment variable override convention**: `NISSAN_ETD__{SECTION}__{KEY}` (double underscore as separator). For example, `NISSAN_ETD__DATABASE__CONNECTION_STRING` overrides `database.connection_string`.

### 2. Database Client (`src/database_client.py`)

Wraps pyodbc for ODBC connectivity with parameterised queries and transaction management.

```python
class DatabaseClient:
    """ODBC database client with parameterised query support."""
    
    def __init__(self, connection_string: str):
        ...
    
    def execute_query(self, query_name: str) -> list[dict]:
        """Execute a named query, return results as list of dicts."""
        ...
    
    def execute_stored_proc(self, proc_name: str, params: dict) -> list[dict] | None:
        """Execute a stored procedure with named parameters."""
        ...
    
    def execute_action(self, sql: str, params: tuple = ()) -> int:
        """Execute an INSERT/UPDATE/DELETE, return affected row count."""
        ...
    
    def close(self) -> None:
        """Close the connection."""
        ...

class DatabaseError(Exception):
    """Raised on connection or query failure."""
    ...
```


### 3. Excel Handler (`src/excel_handler.py`)

Manages Excel workbook operations using openpyxl — no COM dependency for spreadsheet I/O.

```python
class ExcelHandler:
    """Read/write Excel workbooks using openpyxl."""
    
    def __init__(self, workbook_path: str):
        """Open workbook at path. Raises ExcelError if not found."""
        ...
    
    def get_sheet(self, sheet_name: str) -> Worksheet:
        """Get a worksheet by name."""
        ...
    
    def clear_range(self, sheet_name: str, start_row: int, start_col: int, 
                    end_row: int, end_col: int) -> None:
        """Clear content in the specified range."""
        ...
    
    def write_records(self, sheet_name: str, records: list[tuple], 
                      start_row: int = 1, start_col: int = 1) -> None:
        """Write a list of record tuples to a worksheet."""
        ...
    
    def read_etd_data(self, sheet_name: str) -> list[ETDRecord]:
        """Read ETD data (part_no, etd_date, qty) from row 2 until empty part_no."""
        ...
    
    def write_status(self, sheet_name: str, row: int, status: str) -> None:
        """Write processing status to column 4 of the given row."""
        ...
    
    def save(self) -> None:
        """Save the workbook."""
        ...

class ExcelError(Exception):
    """Raised on workbook operation failure."""
    ...

@dataclass
class ETDRecord:
    row: int
    part_number: str
    etd_date: str
    quantity: str
```

### 4. BlueZone Client (`src/bluezone_client.py`)

COM automation wrapper for BlueZone terminal emulator interaction.

```python
class BlueZoneClient:
    """COM automation client for BlueZone terminal emulator."""
    
    def __init__(self, prog_id: str = "BZWhll.WhllObj", timeout_ms: int = 30000):
        """Create COM connection. Raises BlueZoneError if unavailable."""
        ...
    
    def get_string(self, row: int, col: int, length: int) -> str:
        """Read text from the screen at the given position."""
        ...
    
    def send_keys(self, keys: str) -> None:
        """Send keystrokes to the terminal. Supports <Enter>, <PFn> notation."""
        ...
    
    def move_to(self, row: int, col: int) -> None:
        """Move cursor to the specified row and column. Retries until positioned."""
        ...
    
    def wait_for_string(self, text: str, row: int, col: int, 
                        timeout_ms: int | None = None) -> bool:
        """Wait for specific text to appear at position. Returns False on timeout."""
        ...
    
    def wait_host_quiet(self, duration_ms: int = 500) -> None:
        """Wait for the host to become quiet (stop transmitting)."""
        ...
    
    def get_current_screen_id(self) -> str:
        """Read the screen identifier from the standard position."""
        ...
    
    def disconnect(self) -> None:
        """Release COM references."""
        ...

class BlueZoneError(Exception):
    """Raised on COM connection or interaction failure."""
    ...
```


### 5. NPOPS Navigator (`src/npops_navigator.py`)

State machine for navigating NPOPS mainframe screens to reach the ETD data entry screen.

```python
class NPOPSNavigator:
    """State machine for NPOPS screen navigation."""
    
    # Screen transition table: {current_screen: (command, target_screen, target_row, target_col)}
    TRANSITIONS = {
        "M009000G": ("13<Enter>", "M009001G", 6, 71),
        "M009001G": ("11<Enter>", "NPS025M0", 3, 3),
        "NPS025M0": ("1<Enter>",  "NPS025P1", 3, 3),
    }
    
    # Screen identification positions: {screen_id: (row, col)}
    SCREEN_POSITIONS = {
        "M009000G": (3, 14),
        "M009001G": (3, 13),
        "NPS025M0": (3, 13),
        "NPS025P1": (3, 3),
    }
    
    TARGET_SCREEN = "NPS025P1"
    
    def __init__(self, bluezone_client: BlueZoneClient):
        ...
    
    def navigate_to_etd_entry(self) -> None:
        """Navigate from current screen to NPS025P1. Raises NavigationError on failure."""
        ...
    
    def identify_current_screen(self) -> str:
        """Determine which NPOPS screen is currently displayed."""
        ...
    
    def return_to_entry_screen(self) -> None:
        """Send PF11 to return to NPS025P1 after submission."""
        ...

class NavigationError(Exception):
    """Raised when screen navigation fails."""
    def __init__(self, expected_screen: str, actual_screen: str):
        ...
```

```mermaid
stateDiagram-v2
    [*] --> M009000G : Start
    M009000G --> M009001G : Send "13" + Enter
    M009001G --> NPS025M0 : Send "11" + Enter
    NPS025M0 --> NPS025P1 : Send "1" + Enter
    NPS025P1 --> NPS025P1 : Submit ETD (PF8) → Success
    NPS025P1 --> ErrorScreen : Submit ETD (PF8) → Error
    ErrorScreen --> NPS025P1 : Send PF11 (recover)
```

### 6. ETD Formatter (`src/etd_formatter.py`)

Pure-function module for ETD data transformation — date calculation, sorting, deduplication.

```python
class ETDFormatter:
    """Pure data transformation functions for ETD processing."""
    
    @staticmethod
    def calculate_etd_date(original_date: date) -> date:
        """Add 7 days to the original date."""
        ...
    
    @staticmethod
    def format_date_ddmmyy(d: date) -> str:
        """Format date as 6-character ddmmyy string."""
        ...
    
    @staticmethod
    def sort_etd_data(records: list[dict]) -> list[dict]:
        """Sort by priority DESC, part_number ASC (numeric text), date ASC."""
        ...
    
    @staticmethod
    def deduplicate(records: list[dict], key: str = "part_number") -> list[dict]:
        """Remove duplicates by key, keeping first occurrence."""
        ...
    
    @staticmethod
    def process_pipeline(raw_records: list[dict]) -> list[dict]:
        """Run the full formatting pipeline: calculate dates, sort, deduplicate."""
        ...
```


### 7. ETD Processor (`src/etd_processor.py`)

Orchestrates the full ETD pipeline: import → format → submit to mainframe.

```python
class ETDProcessor:
    """Orchestrates the ETD processing pipeline."""
    
    def __init__(self, config: ConfigManager):
        ...
    
    def run_full_process(self) -> ProcessResult:
        """Execute the full pipeline: import BO data → format → submit to NPOPS."""
        ...
    
    def format_only(self) -> list[dict]:
        """Import and format data without submitting to mainframe."""
        ...
    
    def export_npops_only(self, formatted_data: list[dict] | None = None) -> ProcessResult:
        """Submit pre-formatted data to NPOPS (skips import/format)."""
        ...
    
    def zvor_export(self) -> None:
        """Export ZVOR ETD parts data to Excel workbook."""
        ...
    
    def run_query(self, query_name: str) -> list[dict]:
        """Execute a named database query and return results."""
        ...

@dataclass
class ProcessResult:
    total_rows: int
    success_count: int
    error_count: int
    row_results: list[RowResult]

@dataclass
class RowResult:
    row_number: int
    part_number: str
    status: str
    is_success: bool
```

### 8. Report Generator (`src/report_generator.py`)

Generates picker claim reports using stored procedure data.

```python
@dataclass
class ReportFilters:
    start_date: date
    end_date: date
    stock_urgent_type: str  # "Stock", "VOR", or "All"
    dealer_account: str | None = None
    part_number: str | None = None
    picker_name: str | None = None
    team_id: str | None = None
    zones: dict[str, bool] = field(default_factory=lambda: {chr(i): True for i in range(65, 91)})
    cost_centres: dict[str, bool] = field(default_factory=dict)

class ReportGenerator:
    """Generates picker claim reports (summary and detailed)."""
    
    STOCK_TYPE_MAP = {"Stock": "S%", "VOR": "V%", "All": "%"}
    
    def __init__(self, config: ConfigManager, db_client: DatabaseClient):
        ...
    
    def generate_summary(self, filters: ReportFilters) -> str:
        """Generate summary report. Returns output file path."""
        ...
    
    def generate_detailed(self, filters: ReportFilters) -> str:
        """Generate detailed report. Returns output file path."""
        ...
    
    def _apply_filters(self, filters: ReportFilters) -> None:
        """Call reset then set stored procedures with filter values."""
        ...
    
    def _translate_zone_filter(self, zones: dict[str, bool]) -> dict[str, str]:
        """Convert {A: True, B: False, ...} to {txtZoneA: 'A', txtZoneB: '-', ...}"""
        ...
    
    def _translate_cost_centre_filter(self, centres: dict[str, bool]) -> dict[str, str]:
        """Convert {10: True, 11: False, ...} to {txtCC10: '10', txtCC11: '0', ...}"""
        ...
    
    def _get_windows_username(self) -> str:
        """Get the current Windows login username."""
        ...
```


### 9. CLI Entry Point (`main.py`)

```python
def main():
    parser = argparse.ArgumentParser(
        prog="nissan_etd",
        description="Nissan UK RDC ETD Processing and Reporting Tools"
    )
    parser.add_argument("--config", help="Path to config.yaml", default=None)
    
    subparsers = parser.add_subparsers(dest="operation", required=True)
    
    # ETD operations
    sub_full = subparsers.add_parser("full-etd-process", help="Run full ETD pipeline")
    sub_format = subparsers.add_parser("format-only", help="Import and format without submission")
    sub_export = subparsers.add_parser("export-npops-only", help="Submit to NPOPS only")
    sub_zvor = subparsers.add_parser("zvor-export", help="Export ZVOR data to Excel")
    
    # Query operations
    sub_query = subparsers.add_parser("run-query", help="Execute a named database query")
    sub_query.add_argument("query_name", help="Name of the query to execute")
    
    # Report operations
    sub_report = subparsers.add_parser("report", help="Generate picker claim report")
    sub_report.add_argument("--type", choices=["summary", "detailed"], required=True)
    sub_report.add_argument("--start-date", required=True, help="Start date (YYYY-MM-DD)")
    sub_report.add_argument("--end-date", required=True, help="End date (YYYY-MM-DD)")
    sub_report.add_argument("--stock-type", choices=["Stock", "VOR", "All"], default="All")
    sub_report.add_argument("--dealer", default=None)
    sub_report.add_argument("--part-number", default=None)
    sub_report.add_argument("--picker", default=None)
    sub_report.add_argument("--team", default=None)
    sub_report.add_argument("--zones", default=None, help="Included zones, e.g. 'A,B,C,D'")
    sub_report.add_argument("--cost-centres", default=None, help="Included CCs, e.g. '10,11,21'")
```

## Data Models

### Configuration Schema (`config.yaml`)

```yaml
database:
  connection_string: "DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=P:\\UKRDC\\database.accdb"
  query_timeout: 60

etd:
  excel_path: "P:\\UKRDC\\ETD\\Assign New ETD.xls"
  backorder_path: "P:\\UKRDC\\BO_UK-RDC.xlsx"
  zvor_path: "G:\\xxNPO\\VOR files\\ZVOR_Search.xlsm"
  dropoff_sheet: "Dropoff"
  data_start_row: 2

bluezone:
  prog_id: "BZWhll.WhllObj"
  timeout_ms: 30000
  host_quiet_ms: 500

npops:
  screens:
    M009000G: {row: 3, col: 14}
    M009001G: {row: 3, col: 13}
    NPS025M0: {row: 3, col: 13}
    NPS025P1: {row: 3, col: 3}
  entry_fields:
    part_number: {row: 5, col: 24}
    etd_date: {row: 13, col: 29}
    quantity: {row: 13, col: 45}

logging:
  directory: "./logs"
  level: "INFO"
  format: "%(asctime)s [%(levelname)s] %(name)s: %(message)s"

queries:
  etd_count_date: "ETD COUNT DATE QRY"
  zvor_etd_parts: "ZVOR_ETD_PARTs"
  find_etd_info: "find etd information"
  ics_requests_all: "ICS Requets all Info"
  ics_requests_ams: "ICS Requests to Ams"
  ics_requests_no_response: "ICS Requests No Response"
  outstanding_etd: "Outstanding ETD Requests"
  archive_solved: "archive solved requests"
  delete_solved: "delete solved requests"
  part_search: "MCR_Part number search"
```


### Internal Data Structures

```python
# ETD Record flowing through the pipeline
@dataclass
class ETDRecord:
    row: int              # Source row in Excel (for status write-back)
    part_number: str      # Column A
    etd_date: str         # Column B (formatted as ddmmyy after processing)
    quantity: str         # Column C
    priority: float | None = None  # Column E (for sorting, from raw import)

# Backorder import columns
BACKORDER_COLUMNS = [
    "buyer", "sales_part_number", "sl_part_number", "description",
    "dealer_code", "order_number", "reference_number", "item_number",
    "backorder_date", "backorder_quantity", "etd_reply", "reply_deadline",
    "comment", "auto_etd", "rolos_code", "controller_comment"
]

# Navigation state
@dataclass
class ScreenState:
    screen_id: str
    row: int
    col: int
```

### ETD Processing Pipeline Flow

```mermaid
flowchart TD
    A[Import BO_UK-RDC.xlsx] --> B[Load raw backorder data]
    B --> C[Calculate ETD dates +7 days]
    C --> D[Format dates as ddmmyy]
    D --> E[Sort: priority DESC, part_no ASC, date ASC]
    E --> F[Deduplicate by part number]
    F --> G[Write formatted data to ETD workbook]
    G --> H{Export to NPOPS?}
    H -->|Yes| I[Connect BlueZone COM]
    I --> J[Navigate to NPS025P1]
    J --> K[For each row: enter fields + PF8]
    K --> L[Record status per row]
    L --> M[Write statuses to Excel col 4]
    H -->|No| N[Done - format only]
    M --> O[Log summary + save workbook]
```


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Configuration loading with environment override

*For any* valid YAML configuration dictionary and any subset of keys overridden via environment variables, the loaded configuration SHALL return the environment variable value for overridden keys and the YAML file value for non-overridden keys.

**Validates: Requirements 1.1, 1.2**

### Property 2: Configuration validation rejects incomplete configs

*For any* configuration dictionary missing at least one required key, the Config_Manager validation SHALL raise an error whose message contains the name of each missing key.

**Validates: Requirements 1.3**

### Property 3: Database result set mapping

*For any* query result with N rows and M columns, the Database_Client SHALL return a list of exactly N dictionaries, each containing exactly M key-value pairs with correct column names and values.

**Validates: Requirements 2.2**

### Property 4: Parameterised query binding

*For any* stored procedure call with K parameters, the Database_Client SHALL pass all K parameters via the ODBC parameter binding mechanism (not string interpolation), preserving parameter names and values.

**Validates: Requirements 2.3**

### Property 5: Excel write-then-read round trip

*For any* list of N record tuples written to a worksheet, reading back from the same range SHALL produce the same N records with identical values. Previously existing content in the range SHALL be absent after the write.

**Validates: Requirements 3.2, 3.3**

### Property 6: ETD data reading with stop condition

*For any* worksheet containing K data rows (starting row 2) followed by a row with an empty part number cell, the Excel_Handler SHALL return exactly K ETDRecord objects with correct part_number (col 1), etd_date (col 2), and quantity (col 3) values.

**Validates: Requirements 3.4, 3.5**

### Property 7: ETD date calculation and formatting

*For any* valid date, the ETD_Processor SHALL produce a date exactly 7 days later, formatted as a 6-character string in ddmmyy format where dd is zero-padded day, mm is zero-padded month, and yy is two-digit year.

**Validates: Requirements 4.1, 4.2, 4.5**

### Property 8: ETD sort ordering invariant

*For any* dataset with priority, part_number, and date columns, after sorting, every adjacent pair of rows (i, i+1) SHALL satisfy: priority[i] >= priority[i+1], OR (priority[i] == priority[i+1] AND part_number[i] <= part_number[i+1]), OR (priority[i] == priority[i+1] AND part_number[i] == part_number[i+1] AND date[i] <= date[i+1]).

**Validates: Requirements 4.3**

### Property 9: Deduplication preserves first occurrence and ensures uniqueness

*For any* sorted dataset, after deduplication by part_number, all part_numbers in the result SHALL be unique, the result SHALL be a subset of the input, and for each surviving row its position in the original sorted data SHALL precede any other row with the same part_number.

**Validates: Requirements 4.4**

### Property 10: NPOPS navigation state machine correctness

*For any* screen in the TRANSITIONS table, the navigator SHALL send the defined command and wait for the defined target screen at the defined (row, col) position. The transition sequence from any reachable starting screen SHALL terminate at NPS025P1.

**Validates: Requirements 6.1, 6.2, 6.3, 6.4**


### Property 11: ETD field entry positioning

*For any* ETDRecord (part_number, etd_date, quantity), the BlueZone_Client SHALL move the cursor to (5, 24) before sending the part_number, to (13, 29) before sending the etd_date, and to (13, 45) before sending the quantity.

**Validates: Requirements 7.1, 7.2, 7.3**

### Property 12: Submission response status parsing

*For any* part_number string, if the mainframe response line contains "Part: {part_number} - ETD Table Updated", the recorded status SHALL indicate success. For any other non-empty response text, the recorded status SHALL equal the verbatim response text.

**Validates: Requirements 7.5, 7.6**

### Property 13: Zone and cost centre filter translation

*For any* combination of zone selections (26 booleans for A–Z) and cost centre selections (17 booleans), the translated filter values SHALL map each included zone to its letter and each excluded zone to "-", and each included cost centre to its code string and each excluded cost centre to "0".

**Validates: Requirements 9.2, 9.3**

### Property 14: CLI operation validation

*For any* string in the valid operations set {full-etd-process, format-only, export-npops-only, zvor-export, run-query, report}, the CLI parser SHALL accept the operation without error. *For any* string NOT in the valid set, the CLI SHALL reject the operation and exit with a non-zero return code.

**Validates: Requirements 14.1, 14.4**

### Property 15: Backorder column import completeness

*For any* backorder Excel file with data in all 16 specified columns, the ETD_Processor import SHALL produce records containing all 16 fields (buyer, sales_part_number, sl_part_number, description, dealer_code, order_number, reference_number, item_number, backorder_date, backorder_quantity, etd_reply, reply_deadline, comment, auto_etd, rolos_code, controller_comment) with values matching the source cells.

**Validates: Requirements 11.2**


## Error Handling

### Error Hierarchy

```
Exception
├── ConfigError              # Configuration loading/validation failures
├── DatabaseError            # Connection and query execution failures  
├── ExcelError               # Workbook/worksheet operation failures
├── BlueZoneError            # COM connection and interaction failures
│   └── NavigationError      # Screen navigation timeout/mismatch
└── ETDProcessError          # Pipeline orchestration failures
```

### Error Handling Strategy

| Component | Error Condition | Behaviour |
|-----------|----------------|-----------|
| Config_Manager | Missing file | Raise ConfigError with expected path |
| Config_Manager | Missing required key | Raise ConfigError listing all missing keys |
| Database_Client | Connection failure | Log error details, raise DatabaseError |
| Database_Client | Query failure | Log SQL error, rollback transaction, raise DatabaseError |
| Excel_Handler | File not found | Raise ExcelError with attempted path |
| Excel_Handler | Invalid sheet name | Raise ExcelError with available sheet names |
| BlueZone_Client | COM creation failure | Raise BlueZoneError ("BlueZone not available") |
| BlueZone_Client | No active session | Raise BlueZoneError ("No active session") |
| NPOPS_Navigator | Screen timeout | Log expected vs actual, raise NavigationError |
| ETD_Processor | Row submission error | Log error, record status, continue to next row |
| ETD_Processor | Unhandled exception | Log full stack trace, exit code 1 |

### Resilience Approach

- **Row-level failures do not halt the batch**: If a single ETD row submission fails on the mainframe, the error status is recorded and processing continues with the next row.
- **Navigation failures are fatal**: If NPOPS navigation cannot reach the target screen, the process halts to avoid data corruption.
- **All errors are logged**: Every exception includes context (operation, parameters, timestamps).
- **Exit codes**: 0 = success, 1 = fatal error, 2 = partial success (some rows failed).

## Testing Strategy

### Testing Approach

The testing strategy uses a dual approach:

1. **Property-based tests** (using `hypothesis` library) for universal properties that should hold across all valid inputs — focused on pure logic modules (ETD formatter, config validation, filter translation, screen navigation logic).

2. **Unit tests** (using `pytest`) for specific examples, integration points, error conditions, and COM interaction behaviour (mocked via `unittest.mock`).

### Property-Based Testing Configuration

- Library: **hypothesis** (Python)
- Minimum iterations: 100 per property (`@settings(max_examples=100)`)
- Each property test references its design document property via tag comment:
  ```python
  # Feature: bluezone-macro-to-python, Property 7: ETD date calculation and formatting
  ```

### Test Coverage by Module

| Module | Property Tests | Unit Tests | Integration Tests |
|--------|---------------|------------|-------------------|
| config_manager | Properties 1, 2 | File-not-found, env var format | — |
| database_client | Properties 3, 4 | Connection failure, rollback, stored procs | Actual DB connection |
| excel_handler | Properties 5, 6 | File-not-found, save behaviour | — |
| etd_formatter | Properties 7, 8, 9 | Edge cases (leap years, year boundary) | — |
| npops_navigator | Property 10 | Timeout handling, PF11 recovery | — |
| bluezone_client | Property 11 | COM creation failure, session errors | Live BlueZone (manual) |
| etd_processor | Property 12 | Full pipeline (mocked), ZVOR export | — |
| report_generator | Property 13 | Report type routing, filter ordering | — |
| main (CLI) | Property 14 | Help text, invalid args | — |
| etd_processor (import) | Property 15 | Missing file, partial data | — |

### Key Testing Decisions

- **BlueZone COM is mocked** in all automated tests. Live COM testing requires manual execution on a machine with BlueZone running.
- **Database interactions are mocked** for unit/property tests. A separate integration test suite (run manually) validates against the real Access database.
- **openpyxl is used directly** in tests (not mocked) since it operates on in-memory workbooks — fast and deterministic.
- **hypothesis** strategies will generate: random date ranges, part number strings, varying record counts, zone/cost-centre bitmasks, and screen state sequences.

### Dependencies (`requirements.txt`)

```
pywin32==306
openpyxl==3.1.2
pyodbc==5.1.0
PyYAML==6.0.1
hypothesis==6.100.0
pytest==8.1.1
reportlab==4.1.0
```

### Minimum Python Version

Python 3.10+ (for `match` statements and `X | Y` union type syntax). Must be **32-bit Python** to interact with 32-bit BlueZone COM objects in the Citrix environment.
