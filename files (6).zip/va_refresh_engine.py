"""
va_refresh_engine.py  —  v1.0
=================================================================
Refreshes the Nissan VA master workbook for a chosen scenario + month,
operating DIRECTLY on the master (no template file).

What it does for the selected scenario(s) and month:
  1. Copies the master to the output folder (original untouched).
  2. Sets 'Summary month'!E2 to the selected 3-letter month.  All the
     month/quarter logic (mapping sheet + SUMIFS/flag rows) follows from E2.
  3. Shifts the MTD comparison sheet's 'Summary month' month-position column
     references by (new_position - base_position).  The three month columns of
     each block are laid out p1|p2|p3; the sheet is authored for the master's
     current month, so we just move to the selected month's position.
     The YTD sheet uses single cumulative columns (E2-driven) and needs NO
     shift.
  4. Hides every sheet except the selected scenario's MTD + YTD sheets.
  5. Turns on full recalculation on load so Excel recomputes everything
     (including the external links, which are left exactly as-is for now).

All edits are raw-XML surgery on the .xlsx zip, so every other feature of the
workbook (44 external links, cached values, styles, charts) is preserved.
Excel recalculates on open.

This module uses NO third-party packages (no openpyxl) — only the Python
standard library — so it runs anywhere and won't hit memory limits loading the
big workbook.  External links are repointed only when an input_path is given.
"""

import os
import re
import shutil
import stat
import zipfile
import tempfile
import urllib.parse
# NOTE: deliberately NO openpyxl — it loads the whole 44-sheet workbook into
# memory and fails on limited-RAM / 32-bit Python.  Everything is read straight
# from the XML instead, which is tiny and cheap.


def get_column_letter(idx: int) -> str:
    """1 -> 'A', 27 -> 'AA'."""
    s = ""
    while idx > 0:
        idx, r = divmod(idx - 1, 26)
        s = chr(65 + r) + s
    return s


def _cidx(letter: str) -> int:
    """'A' -> 1, 'AA' -> 27."""
    n = 0
    for ch in letter:
        n = n * 26 + (ord(ch.upper()) - 64)
    return n

SUMMARY_MONTH = "Summary month"

# Fiscal-year month order (Apr = period 1).  Position in quarter = idx % 3 + 1.
_FY_MONTHS = ["Apr", "May", "Jun", "Jul", "Aug", "Sep",
              "Oct", "Nov", "Dec", "Jan", "Feb", "Mar"]
_FULL_TO_3 = {"april": "Apr", "may": "May", "june": "Jun", "july": "Jul",
              "august": "Aug", "september": "Sep", "october": "Oct",
              "november": "Nov", "december": "Dec", "january": "Jan",
              "february": "Feb", "march": "Mar"}


def _m3(month: str) -> str:
    """Normalise a month string (full or 3-letter) to title-case 3-letter."""
    m = (month or "").strip()
    if m.lower() in _FULL_TO_3:
        return _FULL_TO_3[m.lower()]
    return m[:3].title()


def _quarter_pos(m3: str) -> int:
    """Position of the month within its fiscal quarter: 1, 2 or 3."""
    idx = _FY_MONTHS.index(m3)        # 0..11
    return (idx % 3) + 1


# fiscal period (Apr=1 ... Mar=12)  <->  3-letter month
_PERIOD_OF = {m: i + 1 for i, m in enumerate(_FY_MONTHS)}     # 'Feb'->11
_MONTH_OF_PERIOD = {i + 1: m for i, m in enumerate(_FY_MONTHS)}
_FULL_OF_3 = {v.title(): k.title() for k, v in _FULL_TO_3.items()}  # 'Feb'->'February'


def _wrap_period(p: int):
    """Wrap a fiscal period into 1..12; return (period, year_delta)."""
    yd = 0
    while p < 1:
        p += 12; yd -= 1
    while p > 12:
        p -= 12; yd += 1
    return p, yd


def _detect_source_period(name: str):
    """
    Find the fiscal period referenced by a FILE NAME.  Looks for a 'PERnn'
    code, a full month name, or a 3-letter month, using letter-only
    boundaries (so '_Feb', 'Jan26' are matched).  Returns 1..12 or None.
    """
    m = re.search(r'(?i)per\s*0*([1-9]|1[0-2])(?![0-9])', name)
    if m:
        return int(m.group(1))
    low = name.lower()
    for full, three in _FULL_TO_3.items():            # full names first
        if re.search(r'(?<![a-z])' + full + r'(?![a-z])', low):
            return _PERIOD_OF[three]
    for three in _FY_MONTHS:
        if re.search(r'(?<![a-z])' + three.lower() + r'(?![a-z])', low):
            return _PERIOD_OF[three]
    return None


def _all_periods_in(name: str) -> set:
    """Every fiscal period referenced anywhere in a filename (for detecting a
    second/leftover month token after a swap).  Returns a set of 1..12."""
    found = set()
    for m in re.finditer(r'(?i)per\s*0*([1-9]|1[0-2])(?![0-9])', name):
        found.add(int(m.group(1)))
    low = name.lower()
    for full, three in _FULL_TO_3.items():
        if re.search(r'(?<![a-z])' + full + r'(?![a-z])', low):
            found.add(_PERIOD_OF[three])
    for three in _FY_MONTHS:
        if re.search(r'(?<![a-z])' + three.lower() + r'(?![a-z])', low):
            found.add(_PERIOD_OF[three])
    return found


def _is_fixed_name(name: str) -> bool:
    """Prior-year / clearly-fixed reference files that must NOT be month-shifted."""
    low = name.lower()
    if re.search(r'fy2[0-4]\b', low):                 # FY20..FY24 (prior years)
        return True
    if re.search(r'(?<!\d)20(1\d|2[0-4])(?!\d)', low):  # a 2010-2024 calendar year
        return True
    return False


def _swap_month_tokens(filename: str, src_p: int, tgt_p: int) -> str:
    """Replace the source month's tokens in a filename with the target month's,
    preserving case style (Title / UPPER / full) and PERnn codes.  Uses
    letter-only boundaries so '_Feb'/'Jan26' are handled."""
    s3, t3 = _MONTH_OF_PERIOD[src_p], _MONTH_OF_PERIOD[tgt_p]
    sfull, tfull = _FULL_OF_3[s3], _FULL_OF_3[t3]
    L = lambda s: r'(?<![A-Za-z])' + s + r'(?![A-Za-z])'
    out = filename
    out = re.sub(r'(?i)(PER\s*)0*%d(?![0-9])' % src_p,
                 lambda m: m.group(1) + "%02d" % tgt_p, out)
    out = re.sub(L(sfull), tfull, out)
    out = re.sub(L(sfull.upper()), tfull.upper(), out)
    out = re.sub(L(sfull.lower()), tfull.lower(), out)
    out = re.sub(L(s3), t3, out)
    out = re.sub(L(s3.upper()), t3.upper(), out)
    out = re.sub(L(s3.lower()), t3.lower(), out)
    return out


def _collect_ext_ref_formulas(read_fn, names):
    """Every formula that reads from an external link (contains a [n] index),
    as (sheet_part, cell, formula) tuples — used to prove repointing didn't
    move any of the cells/rows the sheets read from those links."""
    refs = []
    for n in names:
        if re.match(r'xl/worksheets/sheet\d+\.xml$', n):
            txt = read_fn(n).decode("utf-8", "replace")
            for cm in re.finditer(r'<c\b[^>]*\br="([A-Z]+\d+)"[^>]*>(.*?)</c>',
                                  txt, re.DOTALL):
                fm = re.search(r'<f[^>]*>([^<]*\[\d+\][^<]*)</f>', cm.group(2))
                if fm:
                    refs.append((n, cm.group(1), _xml_unescape(fm.group(1))))
    return sorted(refs)


def _verify_refs_unchanged(master_path, xdir):
    """Compare every external cell reference in the master vs the repointed
    output. Returns (ok, count, sample_of_differences)."""
    with zipfile.ZipFile(master_path) as mz:
        before = _collect_ext_ref_formulas(mz.read, mz.namelist())
    names = []
    for root, _d, files in os.walk(os.path.join(xdir, "xl", "worksheets")):
        for f in files:
            if f.endswith(".xml"):
                names.append("xl/worksheets/" + f)
    rd = lambda n: open(os.path.join(xdir, n), "rb").read()
    after = _collect_ext_ref_formulas(rd, names)
    diffs = [(b, a) for b, a in zip(before, after) if b != a]
    ok = (before == after)
    return ok, len(before), diffs[:5]


def list_external_links(master_path: str):
    """Every external link in the master: {link, filename, orig_path, cells},
    where 'cells' is how many formula cells across the workbook read from that
    link (its [n] source) — the same set Excel's Edit Links would re-source."""
    with zipfile.ZipFile(master_path) as z:
        names = z.namelist()
        wb = z.read("xl/workbook.xml").decode("utf-8", "replace")
        wbrels = z.read("xl/_rels/workbook.xml.rels").decode("utf-8", "replace")
        ridtgt = dict(re.findall(r'Id="(rId\d+)"[^>]*?Target="([^"]+)"', wbrels))
        # the n-th <externalReference> (1-based) is the [n] used in formulas
        pos_to_link = {}
        for i, rid in enumerate(re.findall(r'<externalReference\s+r:id="(rId\d+)"', wb), 1):
            mm = re.search(r'externalLink(\d+)\.xml', ridtgt.get(rid, ""))
            if mm:
                pos_to_link[i] = "externalLink" + mm.group(1)
        # worksheet file -> display sheet name
        sheetfile_name = {}
        for sm in re.finditer(r'<sheet\b([^>]*?)/?>', wb):
            nm = re.search(r'name="([^"]*)"', sm.group(1))
            rid = re.search(r'r:id="(rId\d+)"', sm.group(1))
            if nm and rid and rid.group(1) in ridtgt:
                t = ridtgt[rid.group(1)].lstrip("/")
                sheetfile_name["xl/" + (t if not t.startswith("xl/") else t[3:])
                               if not t.startswith("xl/") else t] = nm.group(1)
        # count [k] occurrences in worksheet formulas + record sheets
        counts = {}
        pos_sheets = {}
        for n in names:
            if re.match(r'xl/worksheets/sheet\d+\.xml$', n):
                sname = sheetfile_name.get(n, n.split('/')[-1])
                txt = z.read(n).decode("utf-8", "replace")
                for f in re.findall(r'<f[^>]*>([^<]*)</f>', txt):
                    for k in re.findall(r'\[(\d+)\]', f):
                        k = int(k)
                        counts[k] = counts.get(k, 0) + 1
                        pos_sheets.setdefault(k, set()).add(sname)
        link_cells, link_sheets = {}, {}
        for pos, link in pos_to_link.items():
            link_cells[link] = link_cells.get(link, 0) + counts.get(pos, 0)
            link_sheets.setdefault(link, set()).update(pos_sheets.get(pos, set()))

        rels = [n for n in names
                if re.match(r'xl/externalLinks/_rels/externalLink\d+\.xml\.rels$', n)]
        rels.sort(key=lambda n: int(re.search(r'(\d+)', n.split('/')[-1]).group(1)))
        out = []
        for n in rels:
            mt = re.search(r'Target="([^"]+)"', z.read(n).decode("utf-8", "replace"))
            if not mt:
                continue
            clean = re.sub(r'^file:/{0,3}', '',
                           urllib.parse.unquote(mt.group(1)).replace("&amp;", "&"))
            link = n.split('/')[-1].replace(".xml.rels", "")
            out.append({"link": link,
                        "filename": re.split(r'[\\/]', clean)[-1],
                        "orig_path": clean,
                        "cells": link_cells.get(link, 0),
                        "sheets": sorted(link_sheets.get(link, set()))})
    return out


def scan_input_files(folder: str):
    """Spreadsheet files present in the input folder (sorted)."""
    try:
        fs = os.listdir(folder)
    except Exception:
        return []
    return sorted(f for f in fs
                  if f.lower().endswith((".xlsx", ".xlsm", ".xlsb", ".xls")))


_NAME_STOP = {"", "the", "of", "and", "file", "master", "new", "last", "with",
              "only", "update", "no", "vs", "r"}


def _name_tokens(name: str, drop_months: bool = True):
    """Significant lowercase tokens of a filename; months/period codes dropped so
    a Jan file still matches its Mar counterpart.  '+' kept so 5+7 / 2+10 survive."""
    base = os.path.splitext(name)[0].lower()
    months = {m.lower() for m in _FY_MONTHS} | set(_FULL_TO_3.keys())
    toks = []
    for t in re.split(r'[^a-z0-9+]+', base):
        if not t or t in _NAME_STOP:
            continue
        if drop_months and (t in months
                            or re.fullmatch(r'per\s*0*([1-9]|1[0-2])', t)
                            or re.fullmatch(r'(fy)?\d{2,4}', t)):
            continue
        toks.append(t)
    return toks


_SCEN_WORDS = {"actual", "act", "bp", "ly", "ol", "fc", "budget"}


def auto_match_file(orig_filename: str, input_files: list, threshold: float = 0.40):
    """Best-matching input file for a link filename, ignoring month/year.
    Uses a Dice token score (forgiving of extra words) and treats scenario
    codes (5+7, 2+10, …) and type words (Actual/BP/LY/OL/FC) as decisive so
    different scenarios don't cross-match.  ALWAYS returns the closest file
    plus a 0..1 confidence; 'confident' is confidence >= threshold."""
    a = set(_name_tokens(orig_filename))
    a_codes = {t for t in a if '+' in t}
    a_type = a & _SCEN_WORDS
    best, best_s = None, -1.0
    for f in input_files:
        b = set(_name_tokens(f))
        if not a or not b:
            continue
        inter = len(a & b)
        s = 2.0 * inter / (len(a) + len(b))          # Dice coefficient
        b_codes = {t for t in b if '+' in t}
        code_decided = False
        if a_codes and b_codes:                       # both name a scenario code
            if a_codes & b_codes:
                s += 0.30                             # codes agree -> decisive
            else:
                s -= 0.45                             # 5+7 vs 7+5 vs 2+10 -> reject
            code_decided = True
        elif a_codes or b_codes:
            s -= 0.12                                 # one has a code, other none
        if not code_decided:                          # else fall back to type word
            b_type = b & _SCEN_WORDS
            if a_type & b_type:
                s += 0.10
            elif a_type and b_type:
                s -= 0.30
        if s > best_s:
            best_s, best = s, f
    conf = round(max(0.0, min(1.0, best_s)), 2)
    return (best, conf)


def repoint_external_links(xdir: str, input_path: str, run_month3: str,
                           base_month3: str, keep_offsets: bool = True,
                           overrides: dict = None, move_unmatched: bool = False,
                           mapping: dict = None):
    """
    Repoint every dated external link to  <input_path>\\<filename>, where the
    filename keeps its structure but has its MONTH token updated.

    keep_offsets=True  : a link that referred to a prior month stays that many
                         months back from the run month.
    keep_offsets=False : every dated link's month becomes the run month (flat).
    move_unmatched     : if True, links with NO month token and fixed prior-year
                         links are ALSO moved into <input_path> (same filename).
                         If False (default) those links are left untouched on
                         their original path.
    overrides          : optional {link_name: "fixed" | "exact_filename.xlsx"}.

    ONLY the Target string in each externalLinkN.xml.rels is changed — the
    link index, sheet names, and every cell reference in the formulas are left
    exactly as they are, so nothing the sheets read from the link moves.
    Returns a list of report rows (dicts) describing every change.
    """
    overrides = overrides or {}
    base_p = _PERIOD_OF.get(base_month3, 11)
    run_p = _PERIOD_OF.get(run_month3, 11)
    eldir = os.path.join(xdir, "xl", "externalLinks", "_rels")
    report = []
    if not os.path.isdir(eldir):
        return report
    ip = input_path.rstrip("\\/")

    for fn in sorted(os.listdir(eldir),
                     key=lambda n: int(re.search(r'(\d+)', n).group(1))):
        if not fn.endswith(".xml.rels"):
            continue
        link_name = fn.replace(".xml.rels", "")
        p = os.path.join(eldir, fn)
        text = _rt(p)
        m = re.search(r'(Target=")([^"]+)(")', text)
        if not m:
            continue
        raw = m.group(2)
        old = urllib.parse.unquote(raw).replace("&amp;", "&")
        old_clean = re.sub(r'^file:/{0,3}', '', old)
        filename = re.split(r'[\\/]', old_clean)[-1]

        # ---- mapping-driven mode: the caller chose a real input file per link ----
        if mapping is not None:
            chosen = (mapping.get(link_name) or "").strip()
            if not chosen or chosen.lower() in ("keep", "keep original", "— keep original —"):
                report.append({"link": link_name, "old_file": filename,
                               "new_file": filename, "status": "kept on original path",
                               "new_target": old_clean, "uncertain": False, "reason": ""})
                continue
            new_path = ip + "\\" + chosen
            new_target = "file:///" + urllib.parse.quote(new_path, safe=":/\\")
            # IMPORTANT: each .rels has TWO targets (externalLinkPath + the
            # xxl21:absoluteUrl alternate). Replace BOTH or Excel keeps using
            # the absolute alternate and the link looks 'not updated'.
            text2 = re.sub(r'Target="[^"]*"',
                           lambda _m: 'Target="' + new_target + '"', text)
            _wt(p, text2)
            missing = os.path.isdir(ip) and not os.path.exists(new_path)
            report.append({"link": link_name, "old_file": filename,
                           "new_file": chosen,
                           "status": "mapped -> " + chosen,
                           "new_target": new_path,
                           "uncertain": bool(missing),
                           "reason": "chosen file not found in folder" if missing else ""})
            continue

        ov = overrides.get(link_name)
        uncertain, reason = False, ""
        to_folder = True              # dated links always go to the input folder
        if ov == "fixed":
            new_filename, to_folder, status = filename, move_unmatched, "OVERRIDE: fixed"
        elif ov:
            new_filename, status = ov, "OVERRIDE: " + ov
        elif _is_fixed_name(filename):
            new_filename, to_folder = filename, move_unmatched
            status = ("fixed (prior-year) -> input folder" if move_unmatched
                      else "fixed (prior-year) -> left on original path")
        else:
            src_p = _detect_source_period(filename)
            if src_p is None:
                new_filename, to_folder = filename, move_unmatched
                if move_unmatched:
                    status = "no month token -> moved to input folder"
                    uncertain, reason = True, ("no month in name — moved to folder, "
                                               "confirm the file is there")
                else:
                    status = "no month token -> left on original path"
            else:
                if keep_offsets:
                    tgt_p, yd = _wrap_period(run_p + (src_p - base_p))
                else:
                    tgt_p, yd = run_p, 0
                new_filename = _swap_month_tokens(filename, src_p, tgt_p)
                off = src_p - base_p
                status = (f"{_MONTH_OF_PERIOD[src_p]}->{_MONTH_OF_PERIOD[tgt_p]}"
                          + (f"  (offset {off:+d})" if keep_offsets and off else "")
                          + ("  [PREV FY]" if yd < 0 else "  [NEXT FY]" if yd > 0 else ""))
                # leftover-token check: any month token != the target still present?
                leftover = _all_periods_in(new_filename) - {tgt_p}
                if leftover:
                    uncertain = True
                    reason = ("extra month token still in name ("
                              + ", ".join(_MONTH_OF_PERIOD[p] for p in sorted(leftover))
                              + ") — verify")

        if not to_folder:
            # leave this link exactly as it is in the master (path untouched)
            report.append({"link": link_name, "old_file": filename,
                           "new_file": filename, "status": status,
                           "new_target": old_clean,
                           "uncertain": uncertain, "reason": reason})
            continue

        new_path = ip + "\\" + new_filename
        # percent-encode for a valid file URI; only path separators/colon stay
        # literal, so '&', '#', spaces, etc. are encoded -> always valid XML.
        new_target = "file:///" + urllib.parse.quote(new_path, safe=":/\\")
        # replace BOTH targets in the .rels (path + absoluteUrl alternate)
        text = re.sub(r'Target="[^"]*"',
                      lambda _m: 'Target="' + new_target + '"', text)
        _wt(p, text)
        if os.path.isdir(ip) and not os.path.exists(new_path) and not uncertain:
            uncertain = True
            reason = "file not found in input folder — pick the right one"
        report.append({"link": link_name, "old_file": filename,
                       "new_file": new_filename, "status": status,
                       "new_target": new_path,
                       "uncertain": uncertain, "reason": reason})
    return report


# ── raw text read / write ────────────────────────────────────────────────────

def _rt(path):
    with open(path, "rb") as f:
        raw = f.read()
    m = re.match(rb'<\?xml[^>]+encoding=["\']([^"\']+)["\']', raw[:80])
    enc = m.group(1).decode("ascii") if m else "utf-8"
    return raw.decode(enc, errors="replace")


def _wt(path, text):
    with open(path, "wb") as f:
        f.write(text.encode("utf-8"))


def _make_writable(path):
    try:
        os.chmod(path, stat.S_IWRITE | stat.S_IREAD)
    except Exception:
        pass


# ── sheet-name -> worksheet-xml path map (from a directory of extracted xlsx) ─

def _attr(s, key):
    m = re.search(r'\b' + re.escape(key) + r'\s*=\s*["\']([^"\']*)["\']', s)
    return m.group(1) if m else ""


def _sheet_files(xdir):
    """Return ordered list of (sheet_name, state, worksheet_path) from workbook.xml."""
    wb = _rt(os.path.join(xdir, "xl", "workbook.xml"))
    rels = _rt(os.path.join(xdir, "xl", "_rels", "workbook.xml.rels"))
    rid2tgt = {}
    for m in re.finditer(r'<Relationship\b([^>]+)>', rels):
        a = m.group(1)
        if "worksheet" in _attr(a, "Type"):
            rid2tgt[_attr(a, "Id")] = _attr(a, "Target")
    out = []
    for m in re.finditer(r'<sheet\b([^>]*)/?>', wb):
        a = m.group(1)
        name = _attr(a, "name")
        rid = _attr(a, "r:id")
        state = _attr(a, "state") or "visible"
        if name and rid in rid2tgt:
            tgt = rid2tgt[rid].lstrip("/")
            if not tgt.startswith("xl/"):
                tgt = "xl/" + tgt
            out.append((name, state, os.path.join(xdir, tgt)))
    return out


# ── scenario discovery ───────────────────────────────────────────────────────

_SCEN_RE = re.compile(r'^(MTD|YTD)\s+VA\s*(?:vs)?\s*(.+?)\s*$', re.I)


def _xml_unescape(s: str) -> str:
    return (s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
             .replace("&quot;", '"').replace("&apos;", "'"))


def list_scenarios(master_path: str):
    """
    Discover scenarios that have BOTH an 'MTD VA vs X' and 'YTD VA vs X' sheet.
    Reads sheet names straight from workbook.xml (no openpyxl, ~no memory).
    Returns a sorted list of dicts: {scenario, mtd_sheet, ytd_sheet}.
    """
    with zipfile.ZipFile(master_path) as z:
        wb = z.read("xl/workbook.xml").decode("utf-8", "replace")
    mtd, ytd = {}, {}
    for m in re.finditer(r'<sheet\b([^>]*?)/?>', wb):
        name = _xml_unescape(_attr(m.group(1), "name"))
        if not name:
            continue
        sm = _SCEN_RE.match(name.strip())
        if not sm:
            continue
        kind = sm.group(1).upper()
        scen = sm.group(2).strip()
        (mtd if kind == "MTD" else ytd)[scen.lower()] = (scen, name)
    out = []
    for key in sorted(set(mtd)):           # every MTD scenario; YTD optional
        scen = mtd[key][0]
        out.append({"scenario": scen,
                    "mtd_sheet": mtd[key][1],
                    "ytd_sheet": ytd[key][1] if key in ytd else None})
    return out


def _quarter_view_kind(name: str) -> str:
    """'quarterly' = a QTD view that tracks the CURRENT quarter (reads quarter
    totals, auto-updates from E2, no shift). 'fixed' = a period-specific
    snapshot (Q1 vs Q2, Q3 vs Q4, vs PM, …) that compares set periods."""
    s = name.lower()
    qnums = set(re.findall(r'q\s*([1-4])\b', s))
    if "vs pm" in s or "mom" in s:
        return "fixed"
    if s.strip().startswith("qtd") and len(qnums) <= 1:
        return "quarterly"
    return "fixed"


def list_quarterly_views(master_path: str):
    """Comparison sheets that are NOT the monthly MTD/YTD scenario pairs:
    QTD (quarter-to-date), Q-vs-Q, MoM, etc.  Each: {sheet, kind}.
    'quarterly' ones auto-update from E2 (no shift); 'fixed' ones are
    period-specific snapshots (kept as authored)."""
    monthly = set()
    for s in list_scenarios(master_path):
        monthly.add(s["mtd_sheet"])
        if s["ytd_sheet"]:
            monthly.add(s["ytd_sheet"])
    with zipfile.ZipFile(master_path) as z:
        wb = z.read("xl/workbook.xml").decode("utf-8", "replace")
    out = []
    for m in re.finditer(r'<sheet\b([^>]*?)/?>', wb):
        name = _xml_unescape(_attr(m.group(1), "name"))
        if not name or name in monthly:
            continue
        low = name.strip().lower()
        if name in monthly or low.startswith("ytd"):
            continue            # already a monthly scenario, or a YTD partner
        if _is_comparison_sheet(name):
            out.append({"sheet": name, "kind": _quarter_view_kind(name)})
    return out


# ── classify Summary month columns referenced by a sheet ─────────────────────

def _summary_month_totals(sheet_path: str):
    """
    Return the set of Summary-month column LETTERS that are totals / labels
    (must NOT be shifted): quarter/FY totals and the month-label column E.
    Reads the worksheet XML directly (no openpyxl).
    """
    skip = {"E"}                      # E2 holds the selected-month label
    if not sheet_path or not os.path.exists(sheet_path):
        return skip
    text = _rt(sheet_path)
    for rownum in (6, 7):
        rm = re.search(r'<row r="%d"[^>]*>(.*?)</row>' % rownum, text, re.DOTALL)
        if not rm:
            continue
        row = rm.group(1)
        for cm in re.finditer(r'<c r="([A-Z]+)%d"[^>]*>(.*?)</c>' % rownum,
                              row, re.DOTALL):
            col, body = cm.group(1), cm.group(2)
            if rownum == 7 and "SUM(" in body.upper():
                skip.add(col)                       # quarter/FY total column
            if rownum == 6:
                t = re.search(r'<t[^>]*>([^<]*)</t>', body)
                if t and t.group(1).strip() in {"Q1", "Q2", "Q3", "Q4", "FY"}:
                    skip.add(col)
    return skip


def _read_month_e2(sheet_path: str, xdir: str):
    """Read the current 'Summary month'!E2 month text from XML (no openpyxl)."""
    if not sheet_path or not os.path.exists(sheet_path):
        return None
    text = _rt(sheet_path)
    m = re.search(r'<c r="E2"([^>]*?)(?:/>|>(.*?)</c>)', text, re.DOTALL)
    if not m:
        return None
    attrs, body = m.group(1), (m.group(2) or "")
    if "<is>" in body:                              # inline string
        t = re.search(r'<t[^>]*>([^<]*)</t>', body)
        return _xml_unescape(t.group(1)) if t else None
    v = re.search(r'<v>([^<]*)</v>', body)
    if not v:
        return None
    val = v.group(1)
    tm = re.search(r't="([^"]*)"', attrs)
    if tm and tm.group(1) == "s":                   # shared-string index
        ss = os.path.join(xdir, "xl", "sharedStrings.xml")
        if os.path.exists(ss):
            sstext = _rt(ss)
            for i, sm in enumerate(re.finditer(r'<si>(.*?)</si>', sstext, re.DOTALL)):
                if i == int(val):
                    t = re.search(r'<t[^>]*>([^<]*)</t>', sm.group(1))
                    return _xml_unescape(t.group(1)) if t else None
        return None
    return val


# ── XML editors ──────────────────────────────────────────────────────────────

def _set_e2(ws_path: str, month3: str):
    """Set cell E2 of the Summary-month worksheet to an inline string."""
    text = _rt(ws_path)
    # preserve the style index if present
    m = re.search(r'<c r="E2"([^>]*?)(/>|>.*?</c>)', text, re.DOTALL)
    style = ""
    if m:
        sm = re.search(r'\bs="(\d+)"', m.group(1))
        if sm:
            style = f' s="{sm.group(1)}"'
        new = f'<c r="E2"{style} t="inlineStr"><is><t>{month3}</t></is></c>'
        text = text[:m.start()] + new + text[m.end():]
    else:
        # insert into row 2 (create if necessary) — fallback
        new = f'<c r="E2" t="inlineStr"><is><t>{month3}</t></is></c>'
        rm = re.search(r'(<row r="2"[^>]*>)', text)
        if rm:
            text = text[:rm.end()] + new + text[rm.end():]
    _wt(ws_path, text)


def _detect_base_pos(ws_path: str):
    """Detect the quarter-position a sheet is authored at, from its dominant
    Actual-block column reference (F=1, G=2, H=3 in 'Summary month').
    Returns (pos or None, mixed); mixed=True means several month positions are
    referenced and the sheet can't be safely shifted by a single uniform delta."""
    if not ws_path or not os.path.exists(ws_path):
        return None, False
    text = _rt(ws_path)
    cnt = {1: 0, 2: 0, 3: 0}
    for m in re.finditer(r"'Summary month'!\$?([A-Z]{1,3})\$?\d+", text):
        ci = _cidx(m.group(1))
        if ci in (6, 7, 8):          # F / G / H = Actual block month-slots
            cnt[ci - 5] += 1
    total = sum(cnt.values())
    if total == 0:
        return None, False
    top = max(cnt, key=cnt.get)
    others = total - cnt[top]
    mixed = others > 0 and others >= 0.25 * total
    return top, mixed


def _shift_summary_cols(ws_path: str, delta: int, skip_cols: set):
    """
    Shift the column of every  'Summary month'!<col><row>  reference by delta,
    except columns in skip_cols.  delta = new_position - base_position.
    """
    if delta == 0:
        return 0
    text = _rt(ws_path)
    count = [0]

    def repl(m):
        pre, dollar_c, col, rest = m.group(1), m.group(2), m.group(3), m.group(4)
        if col in skip_cols or _cidx(col) < 6:   # A-E are labels, never month-slots
            return m.group(0)
        # Leave RANGE references untouched — e.g. the fixed INDEX/MATCH lookups
        #   =INDEX('Summary month'!$AC$83:$AE$83,1,MATCH($C$1,'Summary month'!$X$6:$Z$6))
        # These self-select the month via MATCH, so their columns must NOT move.
        # A ref that is immediately next to a ':' is one end of a range.
        nxt = text[m.end():m.end() + 1]
        prv = text[m.start() - 1:m.start()] if m.start() > 0 else ""
        if nxt == ":" or prv == ":":
            return m.group(0)
        new_idx = _cidx(col) + delta
        if new_idx < 1:
            return m.group(0)
        count[0] += 1
        return f"{pre}{dollar_c}{get_column_letter(new_idx)}{rest}"

    # 'Summary month'! then optional $ , column letters, optional $ + row
    text = re.sub(
        r"('Summary month'!)(\$?)([A-Z]{1,3})(\$?\d+)",
        repl, text)
    _wt(ws_path, text)
    return count[0]


def _is_comparison_sheet(name: str) -> bool:
    """A variance/comparison sheet (vs another scenario) — as opposed to an
    input/data sheet (Act, BP, LY, FC*, OL, Summary*, mapping, ...)."""
    return bool(re.search(r'(?i)\bvs\b', name)
                or re.match(r'(?i)^\s*(MTD|YTD|QTD|Q\d)\b', name))


def _set_visibility(xdir: str, keep_names: set):
    """
    Keep the selected scenarios' sheets visible and INPUT/data sheets exactly
    as they are in the master.  Only the OTHER comparison sheets get hidden, so
    a single clean file shows: input sheets + the scenarios you picked.
    """
    path = os.path.join(xdir, "xl", "workbook.xml")
    text = _rt(path)
    order = []     # (name, hidden_bool) in document order

    def repl(m):
        tag = m.group(0)
        name = _attr(tag, "name")
        rid = _attr(tag, "r:id")
        if not (name and rid):
            return tag
        orig_state = _attr(tag, "state") or "visible"
        if name in keep_names:
            new_state = "visible"                     # selected scenario -> show
        elif _is_comparison_sheet(name):
            new_state = "hidden"                      # other scenario -> hide
        else:
            new_state = orig_state                    # input sheet -> leave as-is
        order.append((name, new_state != "visible"))
        inner = tag[len("<sheet"):].rstrip(">").rstrip("/").rstrip()
        inner = re.sub(r'\s+state\s*=\s*["\'][^"\']*["\']', '', inner)
        if new_state == "visible":
            return f"<sheet{inner}/>"
        return f'<sheet{inner} state="{new_state}"/>'

    text = re.sub(r'<sheet\b[^>]*>', repl, text)

    # point activeTab/firstSheet at the first visible sheet (a selected scenario
    # if possible) so Excel doesn't open on a hidden tab
    first_keep = next((i for i, (n, _h) in enumerate(order) if n in keep_names), None)
    first_visible = first_keep if first_keep is not None else \
        next((i for i, (_n, h) in enumerate(order) if not h), 0)
    if re.search(r'<workbookView\b', text):
        def wv(m):
            t = m.group(0)
            sc = t.rstrip().endswith("/>")
            body = (t[:-2] if sc else t[:-1]).rstrip()
            body = re.sub(r'\s+activeTab\s*=\s*["\'][^"\']*["\']', '', body)
            body = re.sub(r'\s+firstSheet\s*=\s*["\'][^"\']*["\']', '', body)
            body += f' firstSheet="{first_visible}" activeTab="{first_visible}"'
            return body + ("/>" if sc else ">")
        text = re.sub(r'<workbookView\b[^>]*?>', wv, text, count=1)
    _wt(path, text)


def _excel_open_friendly(xdir: str):
    """
    Make the output open cleanly in Excel:
      * delete the stale calcChain.xml (it no longer matches the edited
        formulas; leaving it makes Excel run its 'repair' loop) and remove its
        [Content_Types] override + workbook relationship;
      * strip read-only / protection / mark-as-final flags carried over from
        the master (fileSharing readOnlyRecommended, workbookProtection,
        _MarkAsFinal) so the output is editable and doesn't nag on open;
      * set workbookPr updateLinks="always" so Excel refreshes the external
        link VALUES on open (mandatory refresh).  Note: this can make open
        slower and Excel may still show a one-time security bar unless the
        source folder is a Trusted Location.
    """
    cc = os.path.join(xdir, "xl", "calcChain.xml")
    if os.path.exists(cc):
        os.remove(cc)
    ctp = os.path.join(xdir, "[Content_Types].xml")
    ct = _rt(ctp)
    ct = re.sub(r'<Override[^>]*calcChain\.xml"[^>]*/>', '', ct)
    _wt(ctp, ct)
    rp = os.path.join(xdir, "xl", "_rels", "workbook.xml.rels")
    rl = _rt(rp)
    rl = re.sub(r'<Relationship[^>]*Target="[^"]*calcChain\.xml"[^>]*/>', '', rl)
    _wt(rp, rl)
    wp = os.path.join(xdir, "xl", "workbook.xml")
    wb = _rt(wp)
    # strip read-only / protection flags inherited from the master
    wb = re.sub(r'<fileSharing\b[^>]*/>', '', wb)
    wb = re.sub(r'<fileSharing\b[^>]*>.*?</fileSharing>', '', wb, flags=re.DOTALL)
    wb = re.sub(r'<workbookProtection\b[^>]*/>', '', wb)
    wb = re.sub(r'<workbookProtection\b[^>]*>.*?</workbookProtection>', '', wb, flags=re.DOTALL)
    if re.search(r'<workbookPr\b', wb):
        def fix(m):
            t = m.group(0)
            sc = t.rstrip().endswith("/>")
            body = (t[:-2] if sc else t[:-1]).rstrip()
            body = re.sub(r'\s+updateLinks\s*=\s*"[^"]*"', '', body)
            body = re.sub(r'\s+saveExternalLinkValues\s*=\s*"[^"]*"', '', body)
            body += ' updateLinks="always" saveExternalLinkValues="1"'
            return body + ("/>" if sc else ">")
        wb = re.sub(r'<workbookPr\b[^>]*?>', fix, wb, count=1)
    else:
        wb = re.sub(r'(<workbook\b[^>]*>)',
                    r'\1<workbookPr updateLinks="always" saveExternalLinkValues="1"/>',
                    wb, count=1)
    _wt(wp, wb)
    # remove _MarkAsFinal custom property if present
    cup = os.path.join(xdir, "docProps", "custom.xml")
    if os.path.exists(cup):
        cu = _rt(cup)
        cu = re.sub(r'<property\b[^>]*name="_MarkAsFinal"[^>]*>.*?</property>',
                    '', cu, flags=re.DOTALL)
        _wt(cup, cu)


def _force_full_recalc(xdir: str):
    """Make Excel recompute every formula when the file is opened.
    Sets fullCalcOnLoad + calcMode=auto and forces calcId="0" so Excel cannot
    decide the cached values are 'current' and skip the recalculation."""
    path = os.path.join(xdir, "xl", "workbook.xml")
    text = _rt(path)
    if re.search(r'<calcPr\b', text):
        def fix(m):
            t = m.group(0)
            sc = t.rstrip().endswith("/>")
            body = (t[:-2] if sc else t[:-1]).rstrip()
            body = re.sub(r'\s+fullCalcOnLoad\s*=\s*["\'][^"\']*["\']', '', body)
            body = re.sub(r'\s+calcMode\s*=\s*["\'][^"\']*["\']', '', body)
            body = re.sub(r'\s+calcId\s*=\s*["\'][^"\']*["\']', '', body)
            body += ' calcId="0" calcMode="auto" fullCalcOnLoad="1"'
            return body + ("/>" if sc else ">")
        text = re.sub(r'<calcPr\b[^>]*?>', fix, text, count=1)
    else:
        text = text.replace("</workbook>",
                            '<calcPr calcId="0" calcMode="auto" '
                            'fullCalcOnLoad="1"/></workbook>', 1)
    _wt(path, text)


def _repack(src_dir, out_path):
    tmp = out_path + ".tmp"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, _d, files in os.walk(src_dir):
            if root == src_dir and "[Content_Types].xml" in files:
                files = ["[Content_Types].xml"] + [f for f in files
                                                    if f != "[Content_Types].xml"]
            for fn in files:
                ap = os.path.join(root, fn)
                zf.write(ap, os.path.relpath(ap, src_dir).replace("\\", "/"))
    if os.path.exists(out_path):
        _make_writable(out_path)
    os.replace(tmp, out_path)


# ── main entry point ─────────────────────────────────────────────────────────

def _write_run_report(out_path, master_path, base_month3, run_month3, chosen,
                      shift_log, rep, input_path, move_unmatched, refs_ok,
                      refs_count, repointed, kept_orig, warnings, extra_sheets=None):
    """Write a plain-text .txt describing exactly what this run did."""
    import datetime as _dt
    extra_sheets = extra_sheets or []
    rp = os.path.splitext(out_path)[0] + "_report.txt"
    bar = "=" * 70
    dash = "-" * 70
    L = []
    L.append(bar)
    L.append("VA MASTER REFRESH - RUN REPORT")
    L.append(bar)
    L.append(f"Generated : {_dt.datetime.now():%Y-%m-%d %H:%M:%S}")
    L.append(f"Master    : {os.path.basename(master_path)}")
    L.append(f"Output    : {os.path.basename(out_path)}")
    L.append(f"Month     : {base_month3} (master)  ->  {run_month3} (this run)")
    L.append(f"Monthly scenarios : "
             + (", ".join(c["scenario"] for c in chosen) or "(none)"))
    if extra_sheets:
        L.append(f"Quarterly/period  : " + ", ".join(extra_sheets))
    L.append("")
    L.append(dash)
    L.append("1. INTERNAL REFRESH (formulas)")
    L.append(dash)
    L.append("'Summary month'!E2 was set to the chosen month. The workbook's own")
    L.append("formulas recompute the quarter and the three month columns on open")
    L.append("(a full recalc is forced).")
    L.append("")
    if shift_log:
        L.append("Month-position shift applied to each MTD sheet (YTD needs none):")
        L.append(f"  {'MTD sheet':38s} {'refs':>5}  {'by':>3}  position")
        for sheet, n, delta, bp, npos in shift_log:
            L.append(f"  {sheet:38s} {n:5d}  {delta:+3d}  {bp} -> {npos}")
        L.append("")
    L.append("Reference safety check: "
             + (f"OK - all {refs_count} external cell references unchanged "
                "(only file paths were updated)."
                if refs_ok else
                "WARNING - some references changed unexpectedly; do not use this file."))
    L.append("")
    L.append(dash)
    L.append("2. EXTERNAL LINKS")
    L.append(dash)
    if input_path:
        L.append(f"Input folder        : {input_path}")
        L.append(f"Repointed to folder : {repointed}")
        L.append(f"Left on original    : {kept_orig}")
        L.append(f"Move no-month/fixed : {'yes' if move_unmatched else 'no'}")
        L.append("")
        try:
            lk_sheets = {x["link"]: x["sheets"] for x in list_external_links(master_path)}
        except Exception:
            lk_sheets = {}
        L.append(f"  {'link':14s} {'old file':40s} -> new file   | status")
        for r in rep:
            L.append(f"  {r['link']:14s} {r['old_file'][:40]:40s} -> "
                     f"{r['new_file']}  | {r['status']}")
            sh = ", ".join(lk_sheets.get(r["link"], [])[:4])
            if sh:
                L.append(f"                 feeds: {sh}")
        L.append("")
        needed = sorted({r["new_file"] for r in rep
                         if r["new_target"].startswith(input_path.rstrip('\\/'))})
        if needed:
            L.append("Source files this output expects in the input folder:")
            for f in needed:
                L.append(f"  - {f}")
            L.append("")
    else:
        L.append("External links were left exactly as in the master "
                 "(no input folder given).")
        L.append("")
    if warnings:
        L.append(dash)
        L.append("3. LINKS TO EYEBALL BEFORE SENDING TO EXCEL")
        L.append(dash)
        for w in warnings:
            L.append(f"  - {w}")
        L.append("")
    L.append(dash)
    L.append("HOW TO FINISH IN EXCEL")
    L.append(dash)
    L.append("1. Open the output file (it recalculates on open).")
    L.append("2. If the three month columns don't move: Formulas > Calculation")
    L.append("   Options > Automatic, or press Ctrl+Alt+F9.")
    L.append("3. Data > Edit Links > Update Values to load the month's numbers")
    L.append("   from the input files.")
    L.append(bar)
    with open(rp, "w", encoding="utf-8") as fh:
        fh.write("\n".join(L))
    return rp


def refresh_master(master_path: str, scenarios: list, month: str,
                   output_folder: str, timestamp: str = "",
                   input_path: str = None, keep_offsets: bool = True,
                   overrides: dict = None, link_report: bool = False,
                   move_unmatched: bool = False, link_mapping: dict = None,
                   write_report: bool = True, extra_sheets: list = None):
    """
    scenarios : list of scenario tokens (e.g. ['7+5']) matching the discovered
                'MTD VA vs <token>' / 'YTD VA vs <token>' sheets.
    month     : full or 3-letter month (e.g. 'February' or 'Feb').
    input_path: if given, every external link is repointed to
                <input_path>\\<filename-with-month-updated> (no link breakage).
                If None, external links are left exactly as-is.
    Returns the output file path.
    """
    if not os.path.isfile(master_path):
        raise FileNotFoundError(master_path)
    os.makedirs(output_folder, exist_ok=True)

    month3 = _m3(month)
    if month3 not in _FY_MONTHS:
        raise ValueError(f"Unrecognised month: {month!r}")
    new_pos = _quarter_pos(month3)

    # resolve scenarios -> their MTD/YTD sheet names
    available = {s["scenario"].lower(): s for s in list_scenarios(master_path)}
    chosen = []
    for sc in scenarios:
        key = sc.strip().lower()
        if key not in available:
            raise ValueError(f"Scenario '{sc}' not found. Available: "
                             f"{[a['scenario'] for a in available.values()]}")
        chosen.append(available[key])
    if not chosen and not (extra_sheets or []):
        raise ValueError("No scenarios selected.")

    ts = timestamp or ""
    if chosen:
        scen_tag = "_".join(c["scenario"] for c in chosen)
        if len(chosen) > 3 or len(scen_tag) > 40:
            scen_tag = f"{len(chosen)}scenarios"
        if extra_sheets:
            scen_tag += f"+{len(extra_sheets)}q"
    else:
        scen_tag = f"{len(extra_sheets)}quarterly"
    out_name = f"VA_{scen_tag}_{month3}"
    out_name = re.sub(r'[^A-Za-z0-9_+\-]', "_", out_name) + (f"_{ts}" if ts else "") + ".xlsx"
    out_path = os.path.join(output_folder, out_name)
    shutil.copy2(master_path, out_path)
    _make_writable(out_path)

    keep = set()
    for c in chosen:
        keep.add(c["mtd_sheet"])
        if c["ytd_sheet"]:
            keep.add(c["ytd_sheet"])
    for s in (extra_sheets or []):     # quarterly / period sheets: keep, no shift
        keep.add(s)
    warnings = []   # links whose month-swap needs eyeballing
    rep = []        # per-link repoint report rows
    shift_log = []  # (sheet, n_refs, delta, base_pos, new_pos)

    with tempfile.TemporaryDirectory() as tmp:
        xdir = os.path.join(tmp, "x")
        with zipfile.ZipFile(out_path) as z:
            z.extractall(xdir)

        sheets = _sheet_files(xdir)
        by_name = {n: p for (n, _s, p) in sheets}
        sm_path = by_name.get(SUMMARY_MONTH)

        # base month (from current E2) -> base position; column totals to skip
        base_e2 = _read_month_e2(sm_path, xdir)
        base_month3 = _m3(str(base_e2)) if base_e2 else "Feb"
        base_pos = _quarter_pos(base_month3) if base_month3 in _FY_MONTHS else 2
        delta = new_pos - base_pos
        skip_cols = _summary_month_totals(sm_path)

        # 1) set E2
        if sm_path:
            _set_e2(sm_path, month3)
            print(f"[va] Set '{SUMMARY_MONTH}'!E2 = {month3} (base was {base_month3})")

        # 2) shift each MTD sheet by ITS OWN authored position -> the target.
        #    (sheets are authored at different positions: 7+5/5+7 at pos2,
        #    BP/2+10/OL/etc at pos1 — a single global base is wrong for those.)
        for c in chosen:
            mtd_path = by_name.get(c["mtd_sheet"])
            if not mtd_path:
                continue
            sheet_base, mixed = _detect_base_pos(mtd_path)
            if sheet_base is None:
                sheet_base = base_pos            # fallback: global base
            if mixed:
                warnings.append(
                    f"{c['mtd_sheet']}: references more than one month position; "
                    "left UNSHIFTED to avoid corrupting it - check its month "
                    "columns by hand.")
                shift_log.append((c["mtd_sheet"], 0, 0, sheet_base, new_pos))
                print(f"[va] {c['mtd_sheet']}: mixed positions -> left unshifted")
                continue
            d = new_pos - sheet_base
            n = _shift_summary_cols(mtd_path, d, skip_cols)
            shift_log.append((c["mtd_sheet"], n, d, sheet_base, new_pos))
            print(f"[va] {c['mtd_sheet']}: shifted {n} 'Summary month' "
                  f"column refs by {d} (pos {sheet_base}->{new_pos})")

        # 3) hide all but the kept sheets
        _set_visibility(xdir, keep)
        print(f"[va] Visible sheets: {sorted(keep)}")

        # 3b) optionally repoint external links to the input path (no breakage)
        moved = kept_orig = repointed = 0
        if input_path:
            rep = repoint_external_links(xdir, input_path, month3,
                                         base_month3, keep_offsets=keep_offsets,
                                         overrides=overrides,
                                         move_unmatched=move_unmatched,
                                         mapping=link_mapping)
            for r in rep:
                if r["new_target"].startswith(input_path.rstrip("\\/")):
                    repointed += 1
                else:
                    kept_orig += 1
            moved = sum(1 for r in rep if "moved to input folder" in r["status"]
                        or "-> input folder" in r["status"])
            print(f"[va] Repointed {repointed} external links to: {input_path}"
                  + (f"  ({kept_orig} left on original path)" if kept_orig else ""))
            warnings = [f"{r['old_file']}  ->  {r['new_file']}   ({r['reason']})"
                        for r in rep if r.get("uncertain")]
            if warnings:
                print(f"[va] {len(warnings)} link(s) need a look:")
                for w in warnings:
                    print("      - " + w)
            if link_report:
                try:
                    import csv
                    rp = os.path.splitext(out_path)[0] + "_links.csv"
                    with open(rp, "w", newline="", encoding="utf-8") as fh:
                        w = csv.DictWriter(fh, fieldnames=["link", "old_file",
                                           "new_file", "status", "new_target"])
                        w.writeheader()
                        w.writerows({k: r[k] for k in ("link", "old_file",
                                     "new_file", "status", "new_target")}
                                    for r in rep)
                    print(f"[va] Link report: {os.path.basename(rp)}")
                except Exception as e:
                    print(f"[va] (could not write link report: {e})")

        # 3c) CONFIRM the cell/row references that read from the links are intact
        refs_ok, refs_count, diffs = _verify_refs_unchanged(master_path, xdir)
        if refs_ok:
            print(f"[va] Verified: all {refs_count} external cell references "
                  f"unchanged (only file paths were updated).")
        else:
            print(f"[va] WARNING: {len(diffs)} external cell reference(s) changed! "
                  f"e.g. {diffs[:2]}")

        # 4) make it open cleanly in Excel (drop stale calcChain, no auto link
        #    update on open) and recompute on open
        _excel_open_friendly(xdir)
        _force_full_recalc(xdir)

        _repack(xdir, out_path)

    report_path = None
    if write_report:
        try:
            report_path = _write_run_report(
                out_path, master_path, base_month3, month3, chosen, shift_log,
                rep, input_path, move_unmatched, refs_ok, refs_count,
                repointed, kept_orig, warnings, extra_sheets or [])
            print(f"[va] Run report: {os.path.basename(report_path)}")
        except Exception as e:
            print(f"[va] (could not write run report: {e})")

    info = {"warnings": warnings, "refs_ok": refs_ok, "refs_count": refs_count,
            "repointed": repointed, "kept_original": kept_orig,
            "moved_unmatched": moved, "report_path": report_path}
    print(f"[va] Done: {os.path.basename(out_path)}")
    return out_path, info


if __name__ == "__main__":
    import json, sys
    mp = sys.argv[1] if len(sys.argv) > 1 else "Copy_of_VA_master_file_Feb.xlsx"
    print(json.dumps(list_scenarios(mp), indent=2))
