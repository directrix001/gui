"""
va_master_app.py  —  Nissan VA Master Refresh (light UI)
=================================================================
Workflow (no template file — operates on the master itself):
  1. Pick the VA master workbook.
  2. Scenarios are auto-detected from the master's 'MTD/YTD VA vs X' sheets.
  3. Pick the month and the scenario(s).
  4. Generate -> for each scenario, a workbook with only that scenario's
     MTD + YTD sheets visible, E2 set to the month, the MTD month-position
     columns shifted, and full recalc-on-open.  External links untouched.

Requires va_refresh_engine.py in the same folder.
"""
import os, sys, threading
from datetime import datetime

_APP_DIR = os.path.dirname(os.path.abspath(__file__))
if _APP_DIR not in sys.path:
    sys.path.insert(0, _APP_DIR)

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

C = {"bg":"#F4F5F7","card":"#FFFFFF","input":"#EDEFF2","red":"#C3002F",
     "red2":"#A80029","text":"#1B1B1F","soft":"#5C5F66","dim":"#9AA0A6",
     "border":"#E3E6EA","ok":"#1E8E3E","on_red":"#FFFFFF"}

MONTHS = ["April","May","June","July","August","September",
          "October","November","December","January","February","March"]

KEEP_LABEL = "— keep original —"


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Nissan  |  VA Master Refresh")
        self.geometry("900x720"); self.minsize(820,640)
        self.configure(bg=C["bg"])
        self.master_path = tk.StringVar()
        self.month_var = tk.StringVar(value="February")
        self.scenario_vars = {}     # scenario -> BooleanVar (tick boxes)
        self.scenarios = []         # detected scenarios (dicts from engine)
        self._engine = None
        self._styles(); self._build()

    def _styles(self):
        s=ttk.Style(self); s.theme_use("clam")
        s.configure("Red.TButton",background=C["red"],foreground=C["on_red"],
                    font=("Helvetica Neue",10,"bold"),borderwidth=0,padding=(12,8))
        s.map("Red.TButton",background=[("active",C["red2"])])
        s.configure("Ghost.TButton",background=C["input"],foreground=C["soft"],
                    font=("Helvetica Neue",10,"bold"),borderwidth=1,padding=(10,7),
                    bordercolor=C["border"])
        s.map("Ghost.TButton",background=[("active",C["border"])])
        s.configure("TCombobox",fieldbackground=C["card"],background=C["card"],
                    foreground=C["text"],arrowcolor=C["red"],bordercolor=C["border"])
        s.map("TCombobox",fieldbackground=[("readonly",C["card"])],
              foreground=[("readonly",C["text"])])
        s.configure("TProgressbar",troughcolor=C["input"],background=C["red"],
                    borderwidth=0,thickness=5)
        # scenario tick boxes — clear, visible indicator on Windows
        s.configure("Scen.TCheckbutton",background=C["card"],foreground=C["text"],
                    font=("Helvetica Neue",10),indicatorforeground=C["red"],
                    indicatorbackground="#FFFFFF",focuscolor=C["card"],padding=2)
        s.map("Scen.TCheckbutton",
              background=[("active",C["card"]),("selected",C["card"])],
              foreground=[("active",C["text"]),("selected",C["text"])],
              indicatorbackground=[("selected","#FFFFFF"),("pressed","#FFFFFF")])

    def _section(self,parent,title):
        tk.Frame(parent,bg=C["red"],height=3).pack(fill="x")
        tk.Label(parent,text="  "+title,bg=C["bg"],fg=C["soft"],
                 font=("Helvetica Neue",9,"bold")).pack(anchor="w",pady=(8,4))
        card=tk.Frame(parent,bg=C["card"],highlightbackground=C["border"],
                      highlightthickness=1); card.pack(fill="x",pady=(0,12))
        return card

    def _build(self):
        hdr=tk.Frame(self,bg=C["card"],height=64); hdr.pack(fill="x"); hdr.pack_propagate(False)
        tk.Frame(hdr,bg=C["red"],height=3).pack(fill="x")
        tk.Label(hdr,text="VA MASTER REFRESH",bg=C["card"],fg=C["text"],
                 font=("Georgia",16,"bold")).pack(side="left",padx=20,pady=10)
        tk.Label(hdr,text=datetime.now().strftime("%d %b %Y"),bg=C["card"],
                 fg=C["dim"],font=("Courier",9)).pack(side="right",padx=20)

        # fixed footer (always visible) — Generate never scrolls out of reach
        footer=tk.Frame(self,bg=C["card"]); footer.pack(side="bottom",fill="x")
        tk.Frame(footer,bg=C["border"],height=1).pack(fill="x")
        fpad=tk.Frame(footer,bg=C["card"]); fpad.pack(fill="x",padx=20,pady=(8,10))
        self.progress=ttk.Progressbar(fpad,mode="indeterminate",style="TProgressbar")
        self.progress.pack(fill="x",pady=(0,8))
        ttk.Button(fpad,text="  GENERATE",style="Red.TButton",
                   command=self._generate).pack(fill="x",ipady=6)
        self.status=tk.Label(fpad,text="Ready",bg=C["card"],fg=C["dim"],
                             font=("Helvetica Neue",8)); self.status.pack(anchor="w",pady=(6,0))

        # scrollable body
        outer=tk.Frame(self,bg=C["bg"]); outer.pack(fill="both",expand=True)
        canvas=tk.Canvas(outer,bg=C["bg"],highlightthickness=0)
        vsb=ttk.Scrollbar(outer,orient="vertical",command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right",fill="y")
        canvas.pack(side="left",fill="both",expand=True)
        body=tk.Frame(canvas,bg=C["bg"])
        win=canvas.create_window((20,10),window=body,anchor="nw")
        canvas.bind("<Configure>",lambda e:canvas.itemconfig(win,width=e.width-40))
        body.bind("<Configure>",lambda e:canvas.configure(scrollregion=canvas.bbox("all")))
        def _wheel_to(c):
            def h(e):
                d=int(-e.delta/120) if getattr(e,"delta",0) else (1 if getattr(e,"num",5)==5 else -1)
                c.yview_scroll(d,"units")
            return h
        self._wheel_main=_wheel_to(canvas); self._main_canvas=canvas
        for seq in ("<MouseWheel>","<Button-4>","<Button-5>"):
            canvas.bind_all(seq,self._wheel_main)

        # 01 master file
        card=self._section(body,"01  Master File")
        row=tk.Frame(card,bg=C["card"]); row.pack(fill="x",padx=14,pady=12)
        e=tk.Entry(row,textvariable=self.master_path,bg=C["input"],fg=C["soft"],
                   relief="flat",font=("Courier",9),bd=0,highlightthickness=1,
                   highlightbackground=C["border"])
        e.pack(side="left",fill="x",expand=True,ipady=6,ipadx=6)
        ttk.Button(row,text="Browse",style="Ghost.TButton",
                   command=self._pick_master).pack(side="left",padx=(8,0))

        # 02 month
        card=self._section(body,"02  Month")
        r=tk.Frame(card,bg=C["card"]); r.pack(fill="x",padx=14,pady=12)
        ttk.Combobox(r,textvariable=self.month_var,values=MONTHS,state="readonly",
                     font=("Helvetica Neue",10),width=20).pack(side="left",ipady=3)
        tk.Label(r,text="  (sets 'Summary month'!E2; quarter is derived)",
                 bg=C["card"],fg=C["dim"],font=("Helvetica Neue",8,"italic")).pack(side="left")

        # 03 scenarios (tick boxes; code finds each scenario's MTD+YTD pair)
        card=self._section(body,"03  Scenarios  (detected from the master)")
        self.scen_hint=tk.Label(card,text="Select a master file to load its scenarios.",
                                bg=C["card"],fg=C["dim"],font=("Helvetica Neue",8,"italic"),
                                wraplength=820,justify="left")
        self.scen_hint.pack(anchor="w",padx=14,pady=(10,0))
        self.scen_frame=tk.Frame(card,bg=C["card"]); self.scen_frame.pack(fill="x",padx=14,pady=10)
        self.q_hint=tk.Label(card,text="",bg=C["card"],fg=C["dim"],
                             font=("Helvetica Neue",8,"italic"),wraplength=820,justify="left")
        self.q_hint.pack(anchor="w",padx=14)
        self.q_frame=tk.Frame(card,bg=C["card"]); self.q_frame.pack(fill="x",padx=14,pady=(0,10))
        self.quarterly_vars={}   # sheet -> BooleanVar

        # 04 output
        card=self._section(body,"04  Output Folder")
        r=tk.Frame(card,bg=C["card"]); r.pack(fill="x",padx=14,pady=12)
        self.out_entry=tk.Entry(r,bg=C["input"],fg=C["soft"],relief="flat",
                                font=("Courier",9),bd=0,highlightthickness=1,
                                highlightbackground=C["border"])
        self.out_entry.pack(side="left",fill="x",expand=True,ipady=6,ipadx=6)
        self.out_entry.insert(0,"Select output folder...")
        ttk.Button(r,text="Browse",style="Ghost.TButton",
                   command=self._pick_out).pack(side="left",padx=(8,0))

        # 05 external links
        card=self._section(body,"05  External Links")
        tk.Label(card,text="Input folder holding this month's source files. Every external "
                 "link is repointed here and its month set to the month you picked above.\n"
                 "Leave blank to keep the links exactly as they are in the master.",
                 bg=C["card"],fg=C["soft"],font=("Helvetica Neue",8),justify="left",
                 anchor="w").pack(anchor="w",padx=14,pady=(10,4))
        r=tk.Frame(card,bg=C["card"]); r.pack(fill="x",padx=14,pady=(0,12))
        self.input_entry=tk.Entry(r,bg=C["input"],fg=C["soft"],relief="flat",
                                  font=("Courier",9),bd=0,highlightthickness=1,
                                  highlightbackground=C["border"])
        self.input_entry.pack(side="left",fill="x",expand=True,ipady=6,ipadx=6)
        self.input_entry.insert(0,r"e.g.  I:\4. Consolidation\...\12. Mar")
        self.input_btn=ttk.Button(r,text="Browse",style="Ghost.TButton",
                                  command=self._pick_input)
        self.input_btn.pack(side="left",padx=(8,0))
        self.move_unmatched=tk.BooleanVar(value=False)
        tk.Checkbutton(card,text="Also move the no-month / fixed-year links into this "
                       "folder (otherwise they stay on their original path)",
                       variable=self.move_unmatched,bg=C["card"],fg=C["soft"],
                       selectcolor=C["card"],activebackground=C["card"],
                       font=("Helvetica Neue",8)).pack(anchor="w",padx=14,pady=(0,6))

        # scan the folder and let the user map each link to a real file in it
        br=tk.Frame(card,bg=C["card"]); br.pack(fill="x",padx=14,pady=(2,4))
        ttk.Button(br,text="Scan folder & map links",style="Ghost.TButton",
                   command=self._scan_and_map).pack(side="left")
        ttk.Button(br,text="Load mapping",style="Ghost.TButton",
                   command=self._load_mapping).pack(side="left",padx=(6,0))
        ttk.Button(br,text="Save mapping",style="Ghost.TButton",
                   command=self._save_mapping).pack(side="left",padx=(6,0))
        ttk.Button(br,text="Check files",style="Ghost.TButton",
                   command=self._check_files).pack(side="left",padx=(6,0))
        self._loaded_mapping=None
        self.map_hint=tk.Label(card,text="auto-matches each link to a file in the "
                   "folder (month-independent); change any below",bg=C["card"],fg=C["dim"],
                   font=("Helvetica Neue",8)); self.map_hint.pack(anchor="w",padx=14)
        self.map_wrap=tk.Frame(card,bg=C["card"]); self.map_wrap.pack(fill="x",padx=14,pady=(0,10))
        self.map_canvas=tk.Canvas(self.map_wrap,bg=C["input"],highlightthickness=0,height=0)
        self.map_inner=tk.Frame(self.map_canvas,bg=C["input"])
        self.map_sb=ttk.Scrollbar(self.map_wrap,orient="vertical",
                                  command=self.map_canvas.yview)
        self.map_canvas.configure(yscrollcommand=self.map_sb.set)
        self.map_win=self.map_canvas.create_window((0,0),window=self.map_inner,anchor="nw")
        self.map_inner.bind("<Configure>",lambda e:self.map_canvas.configure(
            scrollregion=self.map_canvas.bbox("all")))
        self.map_canvas.bind("<Configure>",lambda e:self.map_canvas.itemconfig(
            self.map_win,width=e.width))
        _wheel_map=lambda e:(self.map_canvas.yview_scroll(
            int(-e.delta/120) if getattr(e,"delta",0) else (1 if getattr(e,"num",5)==5 else -1),
            "units"))
        def _map_enter(e):
            for seq in ("<MouseWheel>","<Button-4>","<Button-5>"):
                self.map_canvas.bind_all(seq,_wheel_map)
        def _map_leave(e):
            for seq in ("<MouseWheel>","<Button-4>","<Button-5>"):
                self._main_canvas.bind_all(seq,self._wheel_main)
        self.map_canvas.bind("<Enter>",_map_enter)
        self.map_canvas.bind("<Leave>",_map_leave)
        self.link_rows=[]   # (link_name, StringVar)

    def _engine_mod(self):
        if self._engine is None:
            import importlib.util
            p=os.path.join(_APP_DIR,"va_refresh_engine.py")
            if not os.path.isfile(p):
                raise FileNotFoundError("va_refresh_engine.py must be in the same folder.")
            spec=importlib.util.spec_from_file_location("va_refresh_engine",p)
            self._engine=importlib.util.module_from_spec(spec); spec.loader.exec_module(self._engine)
        return self._engine

    def _pick_master(self):
        p=filedialog.askopenfilename(title="Select VA master",
            filetypes=[("Excel","*.xlsx *.xlsm"),("All","*.*")])
        if not p: return
        self.master_path.set(p)
        self.status.config(text="Loading scenarios...")
        threading.Thread(target=self._load_scenarios,args=(p,),daemon=True).start()

    def _load_scenarios(self,p):
        try:
            eng=self._engine_mod()
            scen=eng.list_scenarios(p)
            try: qv=eng.list_quarterly_views(p)
            except Exception: qv=[]
        except Exception as e:
            msg=str(e) or repr(e)
            self.after(0,lambda m=msg:messagebox.showerror("Couldn't load scenarios",m))
            self.after(0,lambda:self.status.config(text="Failed to load scenarios."))
            return
        self.after(0,self._show_scenarios,scen,qv)

    def _show_scenarios(self,scen,qv=None):
        for w in self.scen_frame.winfo_children(): w.destroy()
        for w in self.q_frame.winfo_children(): w.destroy()
        self.scenario_vars={}; self.scenarios=scen
        self.quarterly_vars={}; qv=qv or []
        if not scen and not qv:
            self.scen_hint.config(text="No 'MTD/YTD VA vs X' scenario sheets found."); return
        self.scen_hint.config(text=f"MONTHLY — {len(scen)} scenario(s); each gives its "
                                   "MTD sheet (+ YTD where one exists), month-shifted:")
        for i,s in enumerate(scen):
            v=tk.BooleanVar(value=False); self.scenario_vars[s["scenario"]]=v
            ttk.Checkbutton(self.scen_frame,text="  "+s["scenario"],variable=v,
                            onvalue=True,offvalue=False,style="Scen.TCheckbutton"
                            ).grid(row=i//3,column=i%3,sticky="w",padx=6,pady=3)
        # quarterly / period sheets
        quart=[x for x in qv if x["kind"]=="quarterly"]
        fixed=[x for x in qv if x["kind"]=="fixed"]
        if qv:
            self.q_hint.config(text=f"QUARTERLY/PERIOD — {len(quart)} quarter-to-date "
                "(auto-update with the month, no shift) + "
                f"{len(fixed)} fixed-period snapshots (kept as-is):")
            r=0
            for grp,tag in ((quart,"Q"),(fixed,"fixed")):
                for x in grp:
                    v=tk.BooleanVar(value=False); self.quarterly_vars[x["sheet"]]=v
                    txt=("  ▸ "+x["sheet"]) if tag=="Q" else ("  · "+x["sheet"])
                    ttk.Checkbutton(self.q_frame,text=txt,variable=v,onvalue=True,
                                    offvalue=False,style="Scen.TCheckbutton"
                                    ).grid(row=r//2,column=r%2,sticky="w",padx=6,pady=2)
                    r+=1
        self.status.config(text=f"Loaded {len(scen)} monthly + {len(qv)} quarterly/period.")

    def _pick_out(self):
        p=filedialog.askdirectory(title="Output folder")
        if p: self.out_entry.delete(0,"end"); self.out_entry.insert(0,p)

    def _scan_and_map(self):
        master=self.master_path.get().strip()
        folder=self.input_entry.get().strip()
        if not master or not os.path.isfile(master):
            messagebox.showwarning("Master","Pick the master file first."); return
        if not folder or folder.startswith("e.g.") or not os.path.isdir(folder):
            messagebox.showwarning("Input folder","Pick a valid input folder first."); return
        try:
            eng=self._engine_mod()
            links=eng.list_external_links(master)
            files=eng.scan_input_files(folder)
        except Exception as e:
            messagebox.showerror("Scan failed",str(e)); return
        if not files:
            messagebox.showwarning("No files",
                "No .xlsx / .xlsm / .xlsb files found in that folder."); return
        for w in self.map_inner.winfo_children(): w.destroy()
        self.link_rows=[]
        opts=[KEEP_LABEL]+files
        saved=self._loaded_mapping or {}

        # which comparison sheets will be VISIBLE in this run (current ticks)
        visible_comp=set()
        for s in getattr(self,"scenarios",[]):
            v=self.scenario_vars.get(s["scenario"])
            if v and v.get():
                visible_comp.add(s["mtd_sheet"])
                if s["ytd_sheet"]: visible_comp.add(s["ytd_sheet"])
        for sh,v in getattr(self,"quarterly_vars",{}).items():
            if v.get(): visible_comp.add(sh)

        def is_priority(lk):
            for sh in lk.get("sheets",[]):
                if not eng._is_comparison_sheet(sh):   # input/data sheet -> always in output
                    return True
                if sh in visible_comp:                  # a sheet you ticked
                    return True
            return False

        prio=[lk for lk in links if is_priority(lk)]
        rest=[lk for lk in links if not is_priority(lk)]
        confident=[0]

        def header(txt,color):
            h=tk.Label(self.map_inner,text=txt,bg=C["input"],fg=color,
                       font=("Helvetica Neue",8,"bold"),anchor="w")
            h.pack(fill="x",padx=4,pady=(8,2))

        def add_row(lk,dim=False):
            src_for_match=saved.get(lk["link"]) if saved else None
            if src_for_match==KEEP_LABEL:
                best,conf=None,0.0
            else:
                best,conf=eng.auto_match_file(src_for_match or lk["filename"],files)
            default=best if (best and conf>=0.40) else KEEP_LABEL
            if default!=KEEP_LABEL: confident[0]+=1
            col=(C["dim"] if dim else
                 C["text"] if conf>=0.65 else "#caa24a" if conf>=0.40 else C["dim"])
            var=tk.StringVar(value=default)
            row=tk.Frame(self.map_inner,bg=C["input"]); row.pack(fill="x",pady=(4,2))
            top=tk.Frame(row,bg=C["input"]); top.pack(fill="x")
            feeds=lk.get("cells",0); shts=lk.get("sheets",[])
            dot="🔴 " if not dim else "⚪ "
            pct=f"  [{int(conf*100)}%]" if best else ""
            lbl=dot+lk["filename"][:32]+(f"   ·{feeds} cells" if feeds else "")+pct
            tk.Label(top,text=lbl,bg=C["input"],fg=col,font=("Courier",8),
                     width=48,anchor="w").pack(side="left",padx=(4,6))
            ttk.Combobox(top,values=opts,textvariable=var,state="readonly",
                         font=("Helvetica Neue",8),width=40).pack(side="left",
                         fill="x",expand=True,padx=(0,4),pady=1)
            feed_txt=("       ↳ data feeds: " + ", ".join(shts[:6]) +
                      (f"   +{len(shts)-6} more" if len(shts) > 6 else "")) if shts \
                     else "       ↳ (not used by any sheet)"
            tk.Label(row,text=feed_txt,bg=C["input"],fg=C["dim"],
                     font=("Helvetica Neue",8,"italic"),anchor="w",
                     justify="left").pack(fill="x",padx=(4,6))
            self.link_rows.append((lk["link"],var))

        header(f"🔴  PRIORITY — update these  ({len(prio)})   "
               "input/data sheets + your selected scenarios", C["text"])
        for lk in prio: add_row(lk,dim=False)
        if rest:
            header(f"⚪  Lower priority — feed hidden/unselected sheets only  "
                   f"({len(rest)})   safe to keep original", C["dim"])
            for lk in rest: add_row(lk,dim=True)
        confident=confident[0]
        self.map_canvas.configure(height=260)
        self.map_canvas.pack(side="left",fill="x",expand=True)
        self.map_sb.pack(side="right",fill="y")
        src=" (from loaded mapping)" if saved else ""
        self.map_hint.config(text=f"{len(links)} links · {len(files)} files · "
                             f"{confident} matched{src} · 🔴 priority = input/data + your "
                             "scenarios · ⚪ lower = hidden sheets · '↳ data feeds' lists each "
                             "link's sheets · yellow=check, grey=kept")

    def _save_mapping(self):
        if not getattr(self,"link_rows",None):
            messagebox.showwarning("Save mapping","Scan & map links first."); return
        import json
        data={"master":os.path.basename(self.master_path.get().strip()),
              "map":{lk:v.get() for lk,v in self.link_rows}}
        fp=filedialog.asksaveasfilename(title="Save link mapping",defaultextension=".json",
              initialfile="va_link_mapping.json",filetypes=[("Mapping","*.json")])
        if not fp: return
        try:
            with open(fp,"w",encoding="utf-8") as fh: json.dump(data,fh,indent=2)
            messagebox.showinfo("Saved",f"Mapping saved:\n{os.path.basename(fp)}\n\n"
                "Next month, click Load mapping after choosing the new folder — your "
                "per-link choices are re-matched to that month's files automatically.")
        except Exception as e:
            messagebox.showerror("Save failed",str(e))

    def _load_mapping(self):
        import json
        fp=filedialog.askopenfilename(title="Load link mapping",
              filetypes=[("Mapping","*.json"),("All","*.*")])
        if not fp: return
        try:
            with open(fp,encoding="utf-8") as fh: data=json.load(fh)
            self._loaded_mapping=data.get("map",{})
        except Exception as e:
            messagebox.showerror("Load failed",str(e)); return
        # apply immediately by (re)scanning with the loaded choices as defaults
        if self.master_path.get().strip() and os.path.isdir(self.input_entry.get().strip() or ""):
            self._scan_and_map()
        else:
            messagebox.showinfo("Loaded","Mapping loaded. Pick the input folder, then "
                "click 'Scan folder & map links' to apply your saved choices.")

    def _check_files(self):
        if not getattr(self,"link_rows",None):
            messagebox.showwarning("Check files","Scan & map links first."); return
        folder=self.input_entry.get().strip()
        missing=[v.get() for _lk,v in self.link_rows
                 if v.get()!=KEEP_LABEL and not os.path.exists(os.path.join(folder,v.get()))]
        if missing:
            messagebox.showwarning("Missing files",
                f"{len(missing)} chosen file(s) are NOT in the folder:\n\n"
                +"\n".join("  • "+m for m in sorted(set(missing))[:20])
                +"\n\nFix the dropdowns or add the files before generating.")
        else:
            messagebox.showinfo("All present",
                "Every chosen file exists in the input folder. Good to generate.")

    def _pick_input(self):
        p=filedialog.askdirectory(title="Input folder (where this month's source files live)")
        if p: self.input_entry.delete(0,"end"); self.input_entry.insert(0,p)

    def _generate(self):
        master=self.master_path.get().strip()
        if not master or not os.path.isfile(master):
            messagebox.showwarning("Master","Pick a valid master file."); return
        chosen=[s for s,v in self.scenario_vars.items() if v.get()]
        extra=[sh for sh,v in getattr(self,"quarterly_vars",{}).items() if v.get()]
        if not chosen and not extra:
            messagebox.showwarning("Scenarios",
                "Tick at least one monthly scenario or quarterly/period sheet."); return
        out=self.out_entry.get().strip()
        if not out or out=="Select output folder...":
            messagebox.showwarning("Output","Pick an output folder."); return
        # input path filled -> repoint every link to it with the selected month (flat).
        # blank -> links left untouched.
        input_path=None
        ip=self.input_entry.get().strip()
        if ip and not ip.startswith("e.g."):
            input_path=ip
        # per-link mapping (if the user scanned & mapped)
        link_mapping=None
        if getattr(self,"link_rows",None):
            link_mapping={lk:(None if v.get()==KEEP_LABEL else v.get())
                          for lk,v in self.link_rows}
        os.makedirs(out,exist_ok=True)
        self.progress.start(12); self.status.config(text="Generating...")
        threading.Thread(target=self._run,args=(master,chosen,self.month_var.get(),
                         out,input_path,self.move_unmatched.get(),link_mapping,extra),
                         daemon=True).start()

    def _run(self,master,chosen,month,out,input_path,move_unmatched,link_mapping,extra=None):
        path=None; info=None; err=None
        try:
            eng=self._engine_mod()
            ts=datetime.now().strftime("%Y%m%d_%H%M%S")
            # ONE file containing every selected scenario; flat month update
            path,info=eng.refresh_master(master,chosen,month,out,timestamp=ts,
                           input_path=input_path,keep_offsets=False,
                           move_unmatched=move_unmatched,link_mapping=link_mapping,
                           extra_sheets=extra or [])
        except Exception as e:
            err=str(e)
        self.after(0,self._done,path,info,err,out)

    def _done(self,path,info,err,out):
        self.progress.stop()
        if err:
            self.status.config(text="Failed."); messagebox.showerror("Error",err); return
        info=info or {}
        warnings=info.get("warnings",[])
        refs_ok=info.get("refs_ok",True); refs_count=info.get("refs_count",0)
        self.status.config(text=("Done — "+(f"{len(warnings)} link(s) to check. " if warnings
                            else "")+f"saved to {out}"))
        msg="Generated one file:\n\n"+os.path.basename(path)
        # the reference safety confirmation, first
        if refs_ok:
            msg+=(f"\n\n\u2713 Verified: all {refs_count} cell/row references that read "
                  "from the links are unchanged — only the file paths were updated.")
        else:
            msg+=("\n\n\u26a0 Some cell references changed unexpectedly — do NOT use this "
                  "file; please send it to me to check.")
        if info.get("repointed"):
            msg+=(f"\n\nLinks repointed to the folder: {info['repointed']}"
                  + (f"   (left on original path: {info['kept_original']})"
                     if info.get("kept_original") else ""))
        if warnings:
            msg+=("\n\n\u26a0 "+str(len(warnings))+" link(s) couldn't be confidently "
                  "month-updated — eyeball these before sending to Excel:\n\n"
                  +"\n".join("  \u2022 "+w for w in warnings))
        if info.get("report_path"):
            msg+=("\n\nA detailed run report was saved next to the file:\n  "
                  +os.path.basename(info["report_path"]))
        msg+=("\n\nOpen in Excel and update links (Data > Edit Links) so the "
              "month's data fills in.")
        messagebox.showinfo("Done",msg)


if __name__=="__main__":
    App().mainloop()
