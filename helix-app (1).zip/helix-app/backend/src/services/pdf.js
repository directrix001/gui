const libre = require("libreoffice-convert");
const { PDFDocument } = require("@cantoo/pdf-lib");

if (process.env.LIBREOFFICE_PATH && process.env.LIBREOFFICE_PATH.trim()) {
  process.env.SOFFICE_BIN = process.env.LIBREOFFICE_PATH.trim();
}

function convertToPdf(docxBuffer) {
  return new Promise((resolve, reject) => {
    libre.convert(docxBuffer, ".pdf", undefined, (err, out) => {
      if (err) {
        reject(
          new Error(
            "Word → PDF conversion failed. Make sure LibreOffice is installed and " +
              "'soffice' is on your PATH (or set LIBREOFFICE_PATH in backend/.env). " +
              `Details: ${err.message}`
          )
        );
      } else resolve(out);
    });
  });
}

async function encryptPdf(pdfBuffer, password) {
  if (!password) return pdfBuffer;
  const doc = await PDFDocument.load(pdfBuffer);
  doc.encrypt({
    userPassword: String(password),
    ownerPassword: String(password),
    permissions: { printing: "highResolution" },
  });
  return Buffer.from(await doc.save());
}

async function docxToPdf(docxBuffer, password) {
  const pdf = await convertToPdf(docxBuffer);
  return encryptPdf(pdf, password);
}

module.exports = { docxToPdf };
