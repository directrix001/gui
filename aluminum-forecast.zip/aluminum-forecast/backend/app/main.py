"""
Aluminum Price Intelligence — FastAPI backend
Genpact | Metals Analytics

Serves mock (deterministic) data for:
  • LME Aluminum base price + US Midwest Premium  →  All-in price = LME + MWP
  • 12-month monthly ML forecast with confidence bands
  • 4 input drivers (historical + forecast)
  • Feature importance, model backtest metrics
  • Data-source validation (link health checks)
  • CSV/XLSX upload endpoint (replace mock data with real data later)
"""
from datetime import date
from io import BytesIO
from typing import Optional

import numpy as np
from dateutil.relativedelta import relativedelta
from fastapi import FastAPI, File, UploadFile, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(
    title="Aluminum Price Intelligence API",
    version="1.0.0",
    description="Backend for the Genpact aluminum price forecasting platform (LME + Midwest Premium).",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

RNG = np.random.default_rng(42)
TODAY = date.today().replace(day=1)
HIST_MONTHS = 36
FCST_MONTHS = 12

# ---------------------------------------------------------------- data build
def _month_labels(start: date, n: int) -> list[str]:
    return [(start + relativedelta(months=i)).strftime("%Y-%m") for i in range(n)]

def _series(base: float, drift: float, vol: float, n: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    shocks = rng.normal(0, vol, n).cumsum()
    trend = np.linspace(0, drift, n)
    season = 0.02 * base * np.sin(np.linspace(0, 3 * np.pi, n))
    return base + trend + shocks + season

HIST_START = TODAY - relativedelta(months=HIST_MONTHS - 1)
HIST_LABELS = _month_labels(HIST_START, HIST_MONTHS)
FCST_LABELS = _month_labels(TODAY + relativedelta(months=1), FCST_MONTHS)

LME_HIST = _series(2350, 280, 45, HIST_MONTHS, 1)          # USD / tonne
MWP_HIST = _series(420, 160, 18, HIST_MONTHS, 2)           # USD / tonne (duty-paid premium)
ALLIN_HIST = LME_HIST + MWP_HIST

# 4 input drivers referenced in the discussion (historical only → to be forecast)
DRIVERS = {
    "alumina_price":  {"name": "Alumina Price (USD/t)",        "series": _series(360, 60, 9, HIST_MONTHS, 3)},
    "energy_index":   {"name": "Energy Cost Index",            "series": _series(102, 14, 3.2, HIST_MONTHS, 4)},
    "usd_index":      {"name": "USD Index (DXY)",              "series": _series(103, -4, 1.1, HIST_MONTHS, 5)},
    "china_output":   {"name": "China Smelter Output (kt/mo)", "series": _series(3480, 190, 38, HIST_MONTHS, 6)},
}

def _forecast(hist: np.ndarray, n: int, seed: int, widen: float = 1.0):
    rng = np.random.default_rng(seed)
    slope = (hist[-1] - hist[-9]) / 9.0
    last = hist[-1]
    mean = last + slope * np.arange(1, n + 1) * 0.85 + rng.normal(0, np.std(hist) * 0.05, n).cumsum()
    band = np.std(np.diff(hist)) * np.sqrt(np.arange(1, n + 1)) * 1.28 * widen
    return mean, mean - band, mean + band

LME_F, LME_LO, LME_HI = _forecast(LME_HIST, FCST_MONTHS, 11)
MWP_F, MWP_LO, MWP_HI = _forecast(MWP_HIST, FCST_MONTHS, 12)
ALLIN_F = LME_F + MWP_F
ALLIN_LO = LME_LO + MWP_LO
ALLIN_HI = LME_HI + MWP_HI

def _round(a): return [round(float(x), 2) for x in a]

# ------------------------------------------------------------------- routes
@app.get("/api/summary")
def summary():
    def chg(s): return round(float((s[-1] - s[-2]) / s[-2] * 100), 2)
    return {
        "as_of": HIST_LABELS[-1],
        "lme": {"value": round(float(LME_HIST[-1]), 2), "mom_pct": chg(LME_HIST)},
        "midwest_premium": {"value": round(float(MWP_HIST[-1]), 2), "mom_pct": chg(MWP_HIST)},
        "all_in": {"value": round(float(ALLIN_HIST[-1]), 2), "mom_pct": chg(ALLIN_HIST)},
        "forecast_12m_avg": round(float(np.mean(ALLIN_F)), 2),
        "forecast_peak": {"month": FCST_LABELS[int(np.argmax(ALLIN_F))],
                          "value": round(float(np.max(ALLIN_F)), 2)},
        "model": {"name": "GBM-Ensemble v2.3", "mape_pct": 3.7, "last_trained": str(TODAY)},
    }

@app.get("/api/history")
def history(months: int = Query(36, ge=6, le=HIST_MONTHS)):
    s = HIST_MONTHS - months
    return {
        "labels": HIST_LABELS[s:],
        "lme": _round(LME_HIST[s:]),
        "midwest_premium": _round(MWP_HIST[s:]),
        "all_in": _round(ALLIN_HIST[s:]),
    }

@app.get("/api/forecast")
def forecast(component: str = Query("all_in", pattern="^(all_in|lme|midwest_premium)$")):
    comp = {
        "all_in": (ALLIN_F, ALLIN_LO, ALLIN_HI, ALLIN_HIST),
        "lme": (LME_F, LME_LO, LME_HI, LME_HIST),
        "midwest_premium": (MWP_F, MWP_LO, MWP_HI, MWP_HIST),
    }[component]
    mean, lo, hi, hist = comp
    return {
        "component": component,
        "history": {"labels": HIST_LABELS[-12:], "values": _round(hist[-12:])},
        "forecast": {"labels": FCST_LABELS, "mean": _round(mean),
                     "lower_80": _round(lo), "upper_80": _round(hi)},
        "horizon": "12 months, monthly granularity",
    }

@app.get("/api/drivers")
def drivers():
    out = []
    for i, (key, d) in enumerate(DRIVERS.items()):
        f, lo, hi = _forecast(d["series"], FCST_MONTHS, 20 + i)
        s = d["series"]
        out.append({
            "key": key, "name": d["name"],
            "latest": round(float(s[-1]), 2),
            "yoy_pct": round(float((s[-1] - s[-13]) / s[-13] * 100), 2),
            "history": {"labels": HIST_LABELS, "values": _round(s)},
            "forecast": {"labels": FCST_LABELS, "mean": _round(f),
                         "lower_80": _round(lo), "upper_80": _round(hi)},
        })
    return {"drivers": out, "note": "All four inputs have historical data only; the model forecasts each driver, then predicts the target price column."}

@app.get("/api/drivers/importance")
def importance():
    return {"model": "GBM-Ensemble v2.3", "importance": [
        {"feature": "LME 3-month lag", "weight": 0.31},
        {"feature": "Alumina Price", "weight": 0.22},
        {"feature": "Energy Cost Index", "weight": 0.18},
        {"feature": "China Smelter Output", "weight": 0.16},
        {"feature": "USD Index (DXY)", "weight": 0.13},
    ]}

@app.get("/api/model/metrics")
def model_metrics():
    rng = np.random.default_rng(7)
    actual = ALLIN_HIST[-12:]
    pred = actual * (1 + rng.normal(0, 0.03, 12))
    return {
        "model": "GBM-Ensemble v2.3",
        "metrics": {"mape_pct": 3.7, "rmse_usd": 78.4, "mae_usd": 61.2, "r2": 0.91,
                    "coverage_80_pct": 84.0},
        "backtest": {"labels": HIST_LABELS[-12:], "actual": _round(actual), "predicted": _round(pred)},
        "candidates": [
            {"name": "GBM-Ensemble v2.3", "mape_pct": 3.7, "status": "champion"},
            {"name": "SARIMAX + drivers", "mape_pct": 4.6, "status": "challenger"},
            {"name": "Prophet baseline", "mape_pct": 6.1, "status": "baseline"},
            {"name": "LSTM (multivariate)", "mape_pct": 4.9, "status": "challenger"},
        ],
    }

@app.get("/api/validation")
def validation():
    return {"last_checked": str(date.today()), "sources": [
        {"name": "LME Aluminium Official Price", "url": "https://www.lme.com/en/Metals/Non-ferrous/LME-Aluminium",
         "field": "LME base price (USD/t)", "status": "linked", "latency_ms": 412},
        {"name": "Platts / S&P Global – US Midwest Premium", "url": "https://www.spglobal.com/commodityinsights",
         "field": "Midwest Premium (duty-paid)", "status": "linked", "latency_ms": 655},
        {"name": "Westmetall Market Data", "url": "https://www.westmetall.com/en/markdaten.php",
         "field": "Cross-check: LME cash settlement", "status": "linked", "latency_ms": 380},
        {"name": "Client Excel — 4 input drivers", "url": "internal://uploads/latest",
         "field": "Alumina, Energy, DXY, China output", "status": "pending_validation", "latency_ms": None},
    ], "rules": [
        {"rule": "All-in price must equal LME + Midwest Premium", "status": "pass"},
        {"rule": "No missing months in any driver series", "status": "pass"},
        {"rule": "Driver history ≥ 4–5 quarters (per kickoff)", "status": "warning",
         "detail": "China output has only 5 quarters of clean history — treat early quarters with caution."},
        {"rule": "Outliers flagged beyond 3σ", "status": "pass"},
    ]}

@app.post("/api/upload")
async def upload(file: UploadFile = File(...)):
    if not file.filename or not file.filename.lower().endswith((".csv", ".xlsx", ".xls")):
        raise HTTPException(400, "Upload a .csv or .xlsx file.")
    content = await file.read()
    try:
        import pandas as pd
        df = pd.read_csv(BytesIO(content)) if file.filename.lower().endswith(".csv") \
            else pd.read_excel(BytesIO(content))
    except Exception as e:
        raise HTTPException(422, f"Could not parse file: {e}")
    return {"filename": file.filename, "rows": int(df.shape[0]), "columns": list(map(str, df.columns)),
            "message": "File parsed. Wire this into the data layer to replace mock series."}

@app.get("/api/health")
def health():
    return {"status": "ok"}
