import { NavLink, Routes, Route, useLocation, Navigate } from 'react-router-dom'
import Dashboard from './pages/Dashboard.jsx'
import Forecast from './pages/Forecast.jsx'
import Drivers from './pages/Drivers.jsx'
import Validation from './pages/Validation.jsx'
import ModelPerformance from './pages/ModelPerformance.jsx'
import DataManager from './pages/DataManager.jsx'

const NAV = [
  { to: '/dashboard', label: 'Dashboard', icon: 'M3 13h4v8H3zM10 8h4v13h-4zM17 3h4v18h-4z' },
  { to: '/forecast', label: '12-Month Forecast', icon: 'M3 17l6-6 4 4 8-8M15 7h6v6' },
  { to: '/drivers', label: 'Input Drivers', icon: 'M12 3v18M5 8l7-5 7 5M5 16l7 5 7-5' },
  { to: '/validation', label: 'Data Validation', icon: 'M9 12l2 2 4-4M12 21a9 9 0 100-18 9 9 0 000 18z' },
  { to: '/model', label: 'Model Performance', icon: 'M4 19h16M6 16V9M10 16V5M14 16v-6M18 16V8' },
  { to: '/data', label: 'Data Manager', icon: 'M4 6c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3zM4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6' },
]

const TITLES = {
  '/dashboard': ['Dashboard', 'Aluminum all-in price · LME + US Midwest Premium'],
  '/forecast': ['12-Month Forecast', 'Monthly ML forecast with 80% confidence bands'],
  '/drivers': ['Input Drivers', 'Four historical inputs, each forecast before predicting the target'],
  '/validation': ['Data Validation', 'Source links and rule checks from the kickoff'],
  '/model': ['Model Performance', 'Backtest, error metrics and challenger models'],
  '/data': ['Data Manager', 'Upload real data to replace mock series'],
}

function Icon({ d }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"
      strokeLinecap="round" strokeLinejoin="round"><path d={d} /></svg>
  )
}

export default function App() {
  const { pathname } = useLocation()
  const [title, crumb] = TITLES[pathname] || ['Dashboard', '']
  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">genpact<span className="dot">•</span></div>
          <div className="brand-sub">Metals Analytics</div>
        </div>
        <nav className="nav">
          {NAV.map(n => (
            <NavLink key={n.to} to={n.to}
              className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
              <Icon d={n.icon} />{n.label}
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-foot">
          <strong>Aluminum Price Intelligence</strong><br />
          Client engagement · v1.0<br />Transformation happens here
        </div>
      </aside>

      <div className="main">
        <header className="topbar">
          <div>
            <h1>{title}</h1>
            <div className="crumb">{crumb}</div>
          </div>
          <div className="topbar-right">
            <span className="pill">GBM-Ensemble v2.3 · live</span>
            <div className="avatar">GP</div>
          </div>
        </header>

        <Routes>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/forecast" element={<Forecast />} />
          <Route path="/drivers" element={<Drivers />} />
          <Route path="/validation" element={<Validation />} />
          <Route path="/model" element={<ModelPerformance />} />
          <Route path="/data" element={<DataManager />} />
        </Routes>
      </div>
    </div>
  )
}
