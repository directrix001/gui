# Leaver Pay Calculator — NestJS Backend

NestJS port of `Leavers_Pay_Once___Leave_Calc.py`. Reads the leaver's merged Excel
workbook, runs all 27 payroll calculations, writes the answers into the right cells,
and returns both a JSON breakdown and a processed copy of the workbook.

**Verified against the real files**: run on the merged Duggan workbook it reproduces
every known value on the master sheet — C5 = 1620.31, C20 (PILON) = 2294.78,
C21 (LIEU) = 917.91, the full Holidays chain L2–L10 = {7, 6, 0, 0, −1, −11, 0, 0} → 1,
L14 = 114.739, L15 = 13.77, C15 = 128.51, ECSF −280, ESSF −100, GOODS 6, CAR DRAW 10,
HOL DRAW 2, SAFC 15, NUFC 17, LONDON 68.18, HOUSING 136.36.

---

## 1. Can everything from the Python tool be replicated?

**Yes.** One thing is *replaced* rather than copied, and a few things are *improved*:

| Python tool | This backend |
|---|---|
| Tkinter "browse for a file" desktop dialog | Browser upload page at `http://localhost:3000/` (or plain API upload) — the only piece a server can't do natively, and the web page replicates the exact same UX |
| `openpyxl` reads/writes cells | `exceljs` does the same, plus a **resilient loader**: if the workbook contains logos/drawings that break strict parsers (the real master file does), it strips them or repairs the file via SheetJS automatically (`loadMode` in the response tells you which path ran) |
| Saves **over the original file** | Saves a **timestamped copy** in `outputs/`; your original is never touched |
| Absence £-values **hard-coded** in the script | Read from the **"Absence Table" sheet** when it's in the workbook (the sheet is now the source of truth); falls back to the script's constants when absent |
| `print()` trail in a console window | `logs` array in the JSON response |
| Silent `except:` swallowing errors | Per-section `error` fields in the JSON |

### Bug fixes applied (vs. the Python script)
1. **Indentation bug**: in the script, J9–J14, shift detection and the whole paid/unpaid
   absence engine (J22/J23) sit *inside* the "Early Shift Overtime" branch — they only run
   if such a row exists, on partial sums. Here every section always runs on complete sums.
2. `SAFCDRAW` mirrored to `D19` (colliding with NUFCDRAW); fixed to `D18`.
3. `J3` written as a number, not a string.
4. Payslip says `HOL EXTRA`, the script searched only `HOLIDAY EXTRA` (so it always got 0);
   both spellings match now.
5. Two constants in the script disagree with the Absence Table sheet
   (DL unpaid day-shift on Mon–Thu; MF unpaid Sunday day 23.66 vs 23.86) — in
   table-driven mode the **sheet wins**.
6. Dates work in any server timezone and even when the workbook stores raw Excel
   serial numbers.

Everything else — every formula, every gate (NMUK 7.8 vs NDE 7.5, DL/DF/MF, D18/D19,
leave-day windows), every output cell — is byte-for-byte the script's logic.

---

## 2. Run it

```bash
npm install
npm run start:dev        # http://localhost:3000  (hot reload)
# production: npm run build && npm run start:prod
```

You should see `Payroll backend running on http://localhost:3000`.

### Prepare the workbook
Same as for the Python tool: take `Pay_Once_and_Leave_Calc_Sheet.xlsx` and paste the
four exports in as tabs named exactly **ExcelPaySlip**, **T&A**, **Holidays**, and
(optionally) **Absence Table**. Required sheets: `Calculations`, `ExcelPaySlip`, `T&A`.
Optional: `Leaver Form`, `Holidays`, `Absence Table` — sections that need a missing
sheet report `skipped` instead of failing.

---

## 3. API

| Method | URL | Purpose |
|---|---|---|
| GET | `/` | Browser upload page (the Tkinter-dialog replacement) |
| GET | `/payroll/sections` | Lists all 27 section names in run order |
| POST | `/payroll/process` | Multipart upload, field **`file`** → runs ALL sections, saves a processed copy, returns JSON |
| POST | `/payroll/process?sections=pilon,lieu` | Run only named sections (`basic` + `shift-type` auto-run as prerequisites) |
| POST | `/payroll/process?save=false` | Compute-only, no output file |
| GET | `/payroll/download/:name` | Download a processed workbook (name comes from the process response) |

Section names:
`basic, overtime, shift-overtime, day-shift-change, shift-type, paid-absence,
unpaid-absence, absence-count, deputising, pilon, lieu, ecsf-essf, car-draw, fit-cent,
nssc-gym, hol-draw, safcdraw, nufcdraw, shift-allowance, goods, date-copy, housing,
london-allowance, lump-sum, holidays-requirements, holiday-balance, holiday-overtime`

Response shape:

```json
{
  "file": "merged.xlsx",
  "loadMode": "direct | drawings-stripped | sheetjs-repack",
  "sectionsRun": ["basic", "..."],
  "results": { "pilon": { "weeks": 4, "basePilon": 2294.78, "C20": 2294.78 }, "...": {} },
  "logs": ["BASIC: j3=14.7101, ..."],
  "outputFile": "merged-processed-2026-08-20T...xlsx",
  "downloadUrl": "/payroll/download/merged-processed-...xlsx"
}
```

> `loadMode: "sheetjs-repack"` means the workbook needed repair to be parsed; values and
> formulas survive, but cell styling of untouched cells is not preserved in the saved copy.

---

## 4. Test every aspect

### Option A — browser (fastest sanity check)
Open `http://localhost:3000/`, pick the merged workbook, press **Run calculations**.
JSON appears below; the processed file is one click away.

### Option B — VS Code REST Client
Install the **REST Client** extension, open `test.http`, put your workbook at
`./sample.xlsx`, click *Send Request* on any block (full run, per-section runs,
download).

### Option C — curl (any terminal)
```bash
# everything
curl -F "file=@merged.xlsx" http://localhost:3000/payroll/process | jq .

# one functionality, no file written
curl -F "file=@merged.xlsx" "http://localhost:3000/payroll/process?sections=pilon&save=false" | jq .results.pilon

# download the processed workbook
curl -O http://localhost:3000/payroll/download/<outputFile-from-response>
```

### Per-section expectations (with the real Duggan workbook)

| Section | Check in `results.<section>` |
|---|---|
| `basic` | `J3: 14.7101`, `workingDays: 3` (Apr 1–3), `entityFactor: 7.8`, `J4: 344.22` |
| `shift-allowance` | `C5: 1620.31` (matches master), `shiftCode: "DL"` |
| `pilon` | `weeks: 4`, `basePilon: 2294.78`, `shiftPercent: 0` (D19 empty), `C20: 2294.78` |
| `lieu` | `C21: 917.91` (D18 = "4 Month" contains "Month") |
| `holidays-requirements` | `L2:7, L3:6, L4:0, L5:0, L6:-1, L7:-11, L8:0, L9:0, L10:1` |
| `holiday-balance` | `L14: 114.739`, `L15: 13.77`, `C15: 128.51` |
| `ecsf-essf` | `monthCount: 2` (April), `C27: -280`, `C28: -100` |
| `car-draw` / `hol-draw` | leave day 3 → `C32: 10`, `C33: 2` |
| `safcdraw` / `nufcdraw` | day 3 outside 7–24 → `C18: 15`, `C19: 17` |
| `housing` / `london-allowance` | `C36: 136.36`, `C35: 68.18` (3 of 22 working days) |
| `goods` | `C31: 6` (18 ÷ 12 × month 4) |
| `deputising` | `J17: 17.31` (125 × 12 ÷ 260 × 3) |
| `paid-absence` / `unpaid-absence` | `J22: 17.29` over 11 rows, `J23: 84.64` over 9 rows — values priced from the Absence Table sheet; each row's £ is also written into T&A column F |
| `absence-count` | `matched: 43` approved weekday absences → `J25: 950` SSP-style deduction |
| `holiday-overtime` | `holidayExtra: 50` (the `HOL EXTRA` payslip line is now found), `C24: 54.83` |
| `shift-type` | `shiftType: "DL"` |
| `lump-sum` | `skipped: true` — the payslip is NMUK and the rule is NDE-gated, exactly like the script |

### Error cases
```bash
curl -X POST http://localhost:3000/payroll/process                          # 400 no file
curl -F "file=@README.md" http://localhost:3000/payroll/process             # 400 invalid xlsx
curl -F "file=@merged.xlsx" "http://localhost:3000/payroll/process?sections=nope"  # 400 unknown section
curl http://localhost:3000/payroll/download/missing.xlsx                    # 404
```

### Verifying the written cells
Every run (unless `save=false`) writes a copy to `outputs/`. Open it and check the
cells against the JSON: `Calculations` J3–J25 and C5–C40, `T&A` column F per-row
values, `Holidays` L2–L15.

---

## 5. Project layout

```
src/
├── main.ts / app.module.ts / app.controller.ts   # bootstrap + browser upload page
└── payroll/
    ├── payroll.controller.ts                     # /payroll endpoints
    ├── payroll.service.ts                        # section registry + orchestration
    ├── helpers/
    │   ├── excel.helper.ts                       # cell IO, parsing, working-day math
    │   ├── constants.ts                          # entity factors, shift %, fallback tables
    │   ├── absence-table.ts                      # data-driven Absence Table rules
    │   └── sanitize.ts                           # resilient workbook loader
    └── calculations/
        ├── basic-overtime.calc.ts                # J3–J14
        ├── shift-rules.calc.ts                   # shift type, J22, J23, J25
        ├── leaver.calc.ts                        # J17, PILON C20, LIEU C21
        ├── payslip-items.calc.ts                 # ECSF…GOODS, shift allowance, C40
        ├── prorated.calc.ts                      # housing, London, lump sum
        └── holidays.calc.ts                      # L2–L15, C15, C24
```
