import { useRef, useState } from 'react'
import { COLORS } from '../components/ui.jsx'

const FIELDS = [
  ['weight', 'Part Weight (PWt)', 3.6],
  ['current_price', 'Current Price (P_Current)', 47.09],
  ['ppi_q', 'PPI — Current Qtr', 281.07],
  ['ppi_q1', 'PPI — Previous Qtr', 263.8],
  ['drauss_factor', 'Drauss Factor (DF_c)', 1.44],
  ['mc_q', 'Metal Cost — Current Qtr', 3.26],
  ['mc_q_1', 'Metal Cost — Previous Qtr', 2.90],
  ['cng_q', 'CNG — Current Qtr', 0.97],
  ['cng_q_1', 'CNG — Previous Qtr', 0.72],
]

const SAMPLE = Object.fromEntries(FIELDS.map(([k, , d]) => [k, d]))

const SAMPLE_ROWS = [
  ['Part-A101', 3.6, 47.09, 281.07, 263.8, 1.44, 3.26, 2.90, 0.97, 0.72],
  ['Part-B202', 2.1, 30.00, 281.07, 263.8, 1.44, 3.26, 2.90, 0.97, 0.72],
  ['Part-C303', 5.4, 61.75, 281.07, 263.8, 1.44, 3.26, 2.90, 0.97, 0.72],
  ['Part-D404', 1.8, 22.40, 281.07, 263.8, 1.44, 3.26, 2.90, 0.97, 0.72],
]

const num = (v, d = 4) =>
  v == null || Number.isNaN(Number(v)) ? '—' : Number(v).toLocaleString('en-US', { maximumFractionDigits: d })

function downloadBlob(text, filename, type = 'text/csv') {
  const url = URL.createObjectURL(new Blob([text], { type }))
  const a = document.createElement('a')
  a.href = url; a.download = filename; a.click()
  URL.revokeObjectURL(url)
}

function ManualCalc() {
  const [form, setForm] = useState({ ...SAMPLE })
  const [result, setResult] = useState(null)
  const [calcErr, setCalcErr] = useState(null)
  const [busy, setBusy] = useState(false)
  const [showFormula, setShowFormula] = useState(false)

  const [drag, setDrag] = useState(false)
  const [batch, setBatch] = useState(null)
  const [batchErr, setBatchErr] = useState(null)
  const [batchBusy, setBatchBusy] = useState(false)
  const inputRef = useRef()

  async function calculate() {
    setBusy(true); setCalcErr(null)
    try {
      const payload = Object.fromEntries(
        Object.entries(form).map(([k, v]) => [k, parseFloat(v)]))
      if (Object.values(payload).some(v => Number.isNaN(v)))
        throw new Error('All fields must be valid numbers.')
      const res = await fetch('/api/calculator/single', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.detail || 'Calculation failed')
      setResult(data)
    } catch (e) { setCalcErr(e.message); setResult(null) }
    finally { setBusy(false) }
  }

  async function handleFile(file) {
    if (!file) return
    setBatchBusy(true); setBatchErr(null); setBatch(null)
    try {
      const fd = new FormData()
      fd.append('file', file)
      const res = await fetch('/api/calculator/batch', { method: 'POST', body: fd })
      const data = await res.json()
      if (!res.ok) throw new Error(data.detail || 'Upload failed')
      setBatch(data)
    } catch (e) { setBatchErr(e.message) }
    finally { setBatchBusy(false) }
  }

  function downloadSample() {
    const header = 'Part_ID,PWt,P_Current,PPI_Q,PPI_Q-1,DF_c,MC_Q,MC_Q-1,CNG_Q,CNG_Q-1'
    downloadBlob([header, ...SAMPLE_ROWS.map(r => r.join(','))].join('\n'),
      'sample_parts.csv')
  }

  function downloadResults() {
    if (!batch?.results?.length) return
    const cols = Object.keys(batch.results[0])
    const esc = v => {
      const s = v == null ? '' : String(v)
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s
    }
    downloadBlob(
      [cols.join(','), ...batch.results.map(r => cols.map(c => esc(r[c])).join(','))].join('\n'),
      'new_price_results.csv')
  }

  const previewCols = batch?.results?.length ? Object.keys(batch.results[0]) : []

  return (
    <>
      {/* ── manual: inputs left, live result right — no scrolling ── */}
      <div className="card">
        <div className="card-head">
          <h3>Manual Calculation</h3>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
            <button className="btn ghost" style={{ padding: '6px 12px', fontSize: 12 }}
              onClick={() => setShowFormula(f => !f)}>
              {showFormula ? 'Hide formula' : 'View formula'}
            </button>
            <button className="btn ghost" style={{ padding: '6px 12px', fontSize: 12 }}
              onClick={() => { setForm({ ...SAMPLE }); setCalcErr(null) }}>
              Load sample values
            </button>
          </div>
        </div>
        <div className="card-body">
          <div className="calc-layout">
            <div>
              <div className="calc-grid three">
                {FIELDS.map(([key, label]) => (
                  <label key={key} className="calc-field">
                    <span>{label}</span>
                    <input type="number" step="any" value={form[key]}
                      onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))} />
                  </label>
                ))}
              </div>
              <button className="btn" style={{ marginTop: 14 }} onClick={calculate} disabled={busy}>
                {busy ? 'Calculating…' : 'Calculate New Price'}
              </button>
              {calcErr && <div className="calc-alert err">{calcErr}</div>}
            </div>

            <div className="calc-result-panel">
              <div className="calc-main">
                <span>New Price (P_New)</span>
                <strong>{result ? num(result.new_price) : '—'}</strong>
              </div>
              <div className="calc-sub">
                <div><span>AMS_Q</span><strong>{result ? num(result.ams_q) : '—'}</strong></div>
                <div><span>AMS_Q-1</span><strong>{result ? num(result.ams_q_1) : '—'}</strong></div>
                <div><span>PPI Factor</span><strong>{result ? num(result.ppi_factor, 6) : '—'}</strong></div>
              </div>
              {showFormula && (
                <div className="calc-formula">
                  P_New = P_Current + [(AMS_Q − AMS_Q-1) × PWt] + (PPI_Factor × P_Current)<br />
                  AMS_Q = (MC_Q × DF_c) + CNG_Q<br />
                  AMS_Q-1 = (MC_Q-1 × DF_c) + CNG_Q-1<br />
                  PPI_Factor = (PPI_Q − PPI_Q-1) / PPI_Q-1
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* ── excel batch below ── */}
      <div className="card">
        <div className="card-head">
          <h3>Excel / CSV Batch</h3>
          <button className="btn ghost" style={{ padding: '6px 12px', fontSize: 12 }}
            onClick={downloadSample}>
            Download sample file
          </button>
        </div>
        <div className="card-body">
          <div
            className={`dropzone${drag ? ' drag' : ''}`}
            style={{ padding: 26 }}
            onDragOver={e => { e.preventDefault(); setDrag(true) }}
            onDragLeave={() => setDrag(false)}
            onDrop={e => { e.preventDefault(); setDrag(false); handleFile(e.dataTransfer.files[0]) }}
          >
            <h4>{batchBusy ? 'Computing…' : 'Drop your Excel or CSV here'}</h4>
            <p style={{ marginBottom: 14, fontSize: 12.5 }}>
              Columns: PWt, P_Current, PPI_Q, PPI_Q-1, MC_Q, MC_Q-1, CNG_Q, CNG_Q-1
              (DF_c optional → 1.44). Naming is flexible; extra columns like Part_ID pass through.
            </p>
            <button className="btn" onClick={() => inputRef.current.click()} disabled={batchBusy}>
              Choose file
            </button>
            <input ref={inputRef} type="file" accept=".csv,.xlsx,.xls" hidden
              onChange={e => { handleFile(e.target.files[0]); e.target.value = '' }} />
          </div>

          {batchErr && <div className="calc-alert err">{batchErr}</div>}
          {batch && (
            <div style={{ marginTop: 14 }}>
              <div className="calc-alert ok">
                <strong>{batch.filename}</strong> — {batch.count} rows calculated
                {batch.errors.length > 0 && `, ${batch.errors.length} row(s) skipped`}.
                <button className="btn" style={{ marginLeft: 12, padding: '6px 14px', fontSize: 12 }}
                  onClick={downloadResults}>
                  Download results CSV
                </button>
              </div>
              {batch.errors.length > 0 && (
                <div className="calc-alert warn">
                  {batch.errors.slice(0, 5).map(e => `Row ${e.row}: ${e.error}`).join(' · ')}
                  {batch.errors.length > 5 && ` · +${batch.errors.length - 5} more`}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {batch?.results?.length > 0 && (
        <div className="card">
          <div className="card-head">
            <h3>Results Preview</h3>
            <span className="hint">
              First {Math.min(batch.results.length, 50)} of {batch.count} rows — new_price appended
            </span>
          </div>
          <div className="card-body" style={{ overflowX: 'auto' }}>
            <table>
              <thead>
                <tr>{previewCols.map(c => (
                  <th key={c} style={c === 'new_price' ? { color: COLORS.coralDark } : undefined}>{c}</th>
                ))}</tr>
              </thead>
              <tbody>
                {batch.results.slice(0, 50).map((r, i) => (
                  <tr key={i}>
                    {previewCols.map(c => (
                      <td key={c} className="mono"
                        style={c === 'new_price' ? { fontWeight: 700, color: COLORS.coralDark } : undefined}>
                        {typeof r[c] === 'number' ? num(r[c]) : String(r[c] ?? '—')}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </>
  )
}


// ─────────────────────────────────────────────────────────────────────────
// New Part Calculation — DB-linked autofill + manual fallback + bulk upload
// ─────────────────────────────────────────────────────────────────────────
function NewPartCalc() {
  const [month, setMonth] = useState('2026-08')
  const [pn, setPn] = useState('')
  const [tier, setTier] = useState('NA')
  const [weight, setWeight] = useState('')
  const [price, setPrice] = useState('')
  const [status, setStatus] = useState(null)      // 'found' | 'new' | null
  const [tiers, setTiers] = useState([])
  const [checking, setChecking] = useState(false)
  const [busy, setBusy] = useState(false)
  const [result, setResult] = useState(null)
  const [err, setErr] = useState(null)

  const [bulk, setBulk] = useState(null)
  const [bulkBusy, setBulkBusy] = useState(false)
  const [bulkErr, setBulkErr] = useState(null)
  const [activeSheet, setActiveSheet] = useState('summary')
  const [bulkFile, setBulkFile] = useState(null)
  const fileRef = useRef()

  async function lookup() {
    const p = pn.trim()
    if (!p) return
    setChecking(true); setErr(null); setResult(null)
    try {
      const r = await fetch('/api/parts/lookup', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ part_number: p, tier_1: tier || 'NA' }),
      })
      const j = await r.json()
      if (j.found) {
        setWeight(String(j.weight_lbs)); setPrice(String(j.current_price))
        setTier(j.tier_1); setTiers(j.tiers || []); setStatus('found')
      } else {
        setStatus('new'); setTiers([])
      }
    } catch (e) { setErr(e.message) }
    finally { setChecking(false) }
  }

  async function calculate() {
    const p = pn.trim()
    if (!p) { setErr('Enter a part number first.'); return }
    setBusy(true); setErr(null); setResult(null)
    try {
      // Existing part → forecast engine reads weight+price from the store.
      // New part → the store has no row, so we can't run the engine (it needs
      // stored market data per month). We surface a clear message for new parts.
      const r = await fetch('/api/v1/forecast-excel', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ part_number: p, tier_1: tier || 'NA' }),
      })
      const j = await r.json()
      if (!r.ok) throw new Error(j.detail || 'Calculation failed')
      setResult(j)
    } catch (e) { setErr(e.message) }
    finally { setBusy(false) }
  }

  async function runBulkPreview(f) {
    if (!f) return
    setBulkBusy(true); setBulkErr(null); setBulk(null); setBulkFile(f); setActiveSheet('summary')
    const fd = new FormData(); fd.append('file', f)
    try {
      const r = await fetch('/api/v1/forecast-batch-preview', { method: 'POST', body: fd })
      const j = await r.json()
      if (!r.ok) throw new Error(j.detail || 'Bulk preview failed')
      setBulk(j)
    } catch (e) { setBulkErr(e.message) }
    finally { setBulkBusy(false) }
  }

  async function downloadBulk() {
    if (!bulkFile) return
    const fd = new FormData(); fd.append('file', bulkFile)
    try {
      const r = await fetch('/api/v1/forecast-batch', { method: 'POST', body: fd })
      if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error(j.detail || 'Download failed') }
      const blob = await r.blob(); const url = URL.createObjectURL(blob)
      const a = document.createElement('a'); a.href = url
      a.download = `new_part_forecast_${new Date().toISOString().slice(0, 10)}.xlsx`; a.click()
      URL.revokeObjectURL(url)
    } catch (e) { setBulkErr(e.message) }
  }

  const money = v => v == null ? '—' : '$' + v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })

  return (
    <>
      <div className="card">
        <div className="card-head">
          <h3>New Part — single</h3>
          <span className="hint">Enter a part number; existing parts autofill from the database</span>
        </div>
        <div className="card-body">
          <div className="np-form">
            <label>Month
              <input type="month" value={month} onChange={e => setMonth(e.target.value)} />
            </label>
            <label>Part Number
              <input value={pn} placeholder="e.g. 09-0052-003"
                onChange={e => { setPn(e.target.value); setStatus(null) }}
                onBlur={lookup} />
            </label>
            <label>Tier 1
              {tiers.length > 1
                ? <select value={tier} onChange={e => { setTier(e.target.value); lookup() }}>
                    {tiers.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                : <input value={tier} onChange={e => setTier(e.target.value)} onBlur={lookup} />}
            </label>
            <label>Part Weight (lbs)
              <input type="number" step="any" value={weight}
                onChange={e => setWeight(e.target.value)}
                readOnly={status === 'found'}
                className={status === 'found' ? 'auto' : ''} />
            </label>
            <label>Current Price ($)
              <input type="number" step="any" value={price}
                onChange={e => setPrice(e.target.value)}
                readOnly={status === 'found'}
                className={status === 'found' ? 'auto' : ''} />
            </label>
            <div className="np-actions">
              <button className="btn" onClick={calculate} disabled={busy || !pn.trim()}>
                {busy ? 'Calculating…' : 'New Price Calculation'}
              </button>
            </div>
          </div>

          {checking && <div className="hint" style={{ marginTop: 8 }}>Checking database…</div>}
          {status === 'found' && (
            <div className="calc-alert ok" style={{ marginTop: 10 }}>
              ✓ Part found in database — weight and current price auto-filled. Just click New Price Calculation.
            </div>
          )}
          {status === 'new' && (
            <div className="calc-alert warn" style={{ marginTop: 10 }}>
              New part — not in the database. Fill in weight and current price above.
              (A forecast needs this part added to the data store first; use bulk upload
              or the Data tab to register it, then calculate.)
            </div>
          )}
          {err && <div className="calc-alert err" style={{ marginTop: 10 }}>{err}</div>}

          {result && (
            <div className="np-result" style={{ marginTop: 14 }}>
              <div className="np-result-head">
                <span>Forecast for <b>{result.part_number}</b> · {result.tier_1} · base {result.base_year_month}</span>
                <span className="np-base">Base {money(result.base_price)} → M12 {money(result.forecasts[11].predicted_price)}</span>
              </div>
              <div className="sql-table-wrap" style={{ maxHeight: 260, marginTop: 8 }}>
                <table className="sql-table">
                  <thead><tr><th>Month</th><th>Quarter</th><th>Base used</th><th>Predicted</th></tr></thead>
                  <tbody>
                    {result.forecasts.map(f => (
                      <tr key={f.year_month}>
                        <td>{f.year_month}</td><td>{f.quarter_context.quarter_label}</td>
                        <td>{money(f.base_price_used)}</td>
                        <td style={{ fontWeight: 700 }}>{money(f.predicted_price)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <h3>New Part — bulk</h3>
          <span className="hint">Upload .xlsx with Part Number + Tier 1 — preview all sheets, then download</span>
        </div>
        <div className="card-body">
          <input ref={fileRef} type="file" accept=".xlsx"
            onChange={e => runBulkPreview(e.target.files?.[0])} disabled={bulkBusy} />
          {bulkBusy && <div className="loading" style={{ padding: 10 }}>Processing…</div>}
          {bulkErr && <div className="calc-alert err" style={{ marginTop: 10 }}>{bulkErr}</div>}

          {bulk && (
            <div style={{ marginTop: 12 }}>
              <div className="card-head" style={{ padding: 0, marginBottom: 10, flexWrap: 'wrap', gap: 10 }}>
                <div className="fc-summary-stats">
                  <span className="badge ok">{bulk.ok} ok</span>
                  {bulk.failed > 0 && <span className="badge err">{bulk.failed} failed</span>}
                  <span className="hint">{bulk.part_count} part(s) · {bulk.months.length} months</span>
                </div>
                <button className="btn" onClick={downloadBulk}>⬇ Download workbook</button>
              </div>
              <div className="sheet-tabs">
                <button className={activeSheet === 'summary' ? 'active' : ''}
                  onClick={() => setActiveSheet('summary')}>Summary</button>
                {bulk.monthly_sheets.map((sh, i) => (
                  <button key={sh.year_month} className={activeSheet === i ? 'active' : ''}
                    onClick={() => setActiveSheet(i)}>{sh.label.split(' ')[0].slice(0, 3)} {sh.year_month.slice(2, 4)}</button>
                ))}
              </div>
              {activeSheet === 'summary' ? (
                <div className="sql-table-wrap" style={{ maxHeight: 400 }}>
                  <table className="sql-table batch-table">
                    <thead><tr>
                      <th>Part Number</th><th>Tier 1</th><th>Weight</th><th>Base</th>
                      {bulk.months.map(m => <th key={m.year_month}>{m.year_month.slice(2)}</th>)}
                    </tr></thead>
                    <tbody>
                      {bulk.summary.map((r, i) => (
                        <tr key={i} className={r.error ? 'err-row' : ''}>
                          <td>{r.part_number}</td><td>{r.tier_1}</td>
                          {r.error
                            ? <td colSpan={2 + bulk.months.length} className="err-cell">ERROR: {r.error}</td>
                            : <><td>{r.weight_lbs}</td><td>{money(r.base_price)}</td>
                                {r.monthly.map((v, k) => <td key={k}>{money(v)}</td>)}</>}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="sql-table-wrap" style={{ maxHeight: 400 }}>
                  <table className="sql-table batch-table">
                    <thead><tr>
                      {['Part', 'Tier 1', 'Base', 'Qtr', 'MC_Q', 'PPI Fac', 'AMS_Q', 'ΔAMS', 'Predicted'].map(h => <th key={h}>{h}</th>)}
                    </tr></thead>
                    <tbody>
                      {bulk.monthly_sheets[activeSheet].rows.map((r, i) => (
                        <tr key={i} className={r.error ? 'err-row' : ''}>
                          <td>{r.part_number}</td><td>{r.tier_1}</td>
                          {r.error
                            ? <td colSpan={7} className="err-cell">ERROR: {r.error}</td>
                            : <><td>{money(r.base_price_used)}</td><td>{r.quarter}</td>
                                <td>{r.mc_q?.toFixed(3)}</td><td>{(r.ppi_factor * 100).toFixed(3)}%</td>
                                <td>{r.ams_q?.toFixed(3)}</td><td>{r.ams_delta?.toFixed(3)}</td>
                                <td style={{ fontWeight: 700 }}>{money(r.predicted_price)}</td></>}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  )
}

export default function Calculator() {
  const [tab, setTab] = useState('new')
  return (
    <div className="page">
      <div className="fc-viewswitch" style={{ marginBottom: 4 }}>
        <button className={tab === 'new' ? 'active' : ''} onClick={() => setTab('new')}>New Part Calculation</button>
        <button className={tab === 'manual' ? 'active' : ''} onClick={() => setTab('manual')}>Manual Calculation</button>
      </div>
      {tab === 'new' ? <NewPartCalc /> : <ManualCalc />}
    </div>
  )
}
