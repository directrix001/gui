import { useEffect, useMemo, useRef, useState } from 'react'
import {
  ResponsiveContainer, ComposedChart, LineChart, BarChart, Area, Line, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ReferenceLine, Cell,
} from 'recharts'
import { COLORS, tooltipStyle } from '../components/ui.jsx'

const ML = '#6D28D9'
const FORMULA = COLORS.coral

export default function Forecast() {
  const [parts, setParts] = useState([])
  const [selected, setSelected] = useState('0')
  const [mode, setMode] = useState('formula')
  const [formula, setFormula] = useState(null)
  const [ml, setMl] = useState(null)
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState(null)
  const [mlErr, setMlErr] = useState(null)
  const [showTable, setShowTable] = useState(false)
  const [showBatch, setShowBatch] = useState(false)
  const [batchBusy, setBatchBusy] = useState(false)
  const [batchMsg, setBatchMsg] = useState(null)
  const fileRef = useRef(null)

  useEffect(() => {
    fetch('/api/v1/forecast-excel/parts').then(r => r.json())
      .then(j => setParts(j.parts || [])).catch(e => setErr(e.message))
  }, [])

  const part = parts[Number(selected)] || null

  useEffect(() => {
    if (!part) return
    let alive = true
    setBusy(true); setErr(null); setMlErr(null); setFormula(null); setMl(null)
    const body = JSON.stringify({ part_number: part.part_number, tier_1: part.tier_1 })
    const opts = { method: 'POST', headers: { 'Content-Type': 'application/json' }, body }
    Promise.allSettled([
      fetch('/api/v1/forecast-excel', opts).then(async r => { const j = await r.json(); if (!r.ok) throw new Error(j.detail); return j }),
      fetch('/api/v1/forecast-ml', opts).then(async r => { const j = await r.json(); if (!r.ok) throw new Error(j.detail); return j }),
    ]).then(([f, m]) => {
      if (!alive) return
      f.status === 'fulfilled' ? setFormula(f.value) : setErr(f.reason.message)
      m.status === 'fulfilled' ? setMl(m.value) : setMlErr(m.reason.message)
      setBusy(false)
    })
    return () => { alive = false }
  }, [selected, parts.length])

  const active = mode === 'ml' ? ml : formula
  const accent = mode === 'ml' ? ML : FORMULA

  const priceChart = useMemo(() => {
    if (!active) return []
    return [
      { month: active.base_year_month, price: active.base_price, band: active.base_price, kind: 'actual' },
      ...active.forecasts.map(f => ({
        month: f.year_month, price: f.predicted_price, kind: 'forecast',
        quarter: f.quarter_context.quarter_label,
      })),
    ]
  }, [active])

  const momChart = useMemo(() => {
    if (!active) return []
    let prev = active.base_price
    return active.forecasts.map(f => {
      const pct = prev ? (f.predicted_price - prev) / prev * 100 : 0
      prev = f.predicted_price
      return { month: f.year_month.slice(2), 'MoM': +pct.toFixed(2) }
    })
  }, [active])

  const compareChart = useMemo(() => {
    if (!formula || !ml) return []
    return [
      { month: formula.base_year_month, Formula: formula.base_price, ML: ml.base_price },
      ...formula.forecasts.map((f, i) => ({
        month: f.year_month, Formula: f.predicted_price, ML: ml.forecasts[i]?.predicted_price ?? null,
      })),
    ]
  }, [formula, ml])

  const totalPct = active ? ((active.forecasts[11].predicted_price - active.base_price) / active.base_price * 100) : null
  const peak = active ? Math.max(...active.forecasts.map(f => f.predicted_price)) : null
  const fmt$ = v => '$' + (v ?? 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })

  async function runBatch(f) {
    if (!f) return
    setBatchBusy(true); setBatchMsg(null)
    const fd = new FormData(); fd.append('file', f)
    try {
      const r = await fetch('/api/v1/forecast-batch', { method: 'POST', body: fd })
      if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error(j.detail || `Batch failed (${r.status})`) }
      const blob = await r.blob(); const url = URL.createObjectURL(blob)
      const a = document.createElement('a'); a.href = url
      a.download = `forecast_${new Date().toISOString().slice(0, 10)}.xlsx`; a.click(); URL.revokeObjectURL(url)
      setBatchMsg({ ok: true, text: `Downloaded — ${r.headers.get('X-Parts-Count') || '?'} part(s), Summary + 12 sheets.` })
    } catch (e) { setBatchMsg({ ok: false, text: e.message }) }
    finally { setBatchBusy(false); if (fileRef.current) fileRef.current.value = '' }
  }

  return (
    <div className="page fc-page">
      {/* Control bar: tabs + part + batch toggle, all in one row */}
      <div className="fc-bar">
        <div className="fc-tabs" role="tablist">
          <button className={mode === 'formula' ? 'active' : ''} onClick={() => setMode('formula')}>
            <span className="fc-dot" style={{ background: FORMULA }} />Calculative
          </button>
          <button className={mode === 'ml' ? 'active ml' : ''} onClick={() => setMode('ml')}>
            <span className="fc-dot" style={{ background: ML }} />ML Forecast
          </button>
        </div>
        <select className="part-select" value={selected} onChange={e => setSelected(e.target.value)}>
          {parts.map((p, i) => (
            <option key={`${p.part_number}|${p.tier_1}`} value={i}>
              {p.part_number} — {p.tier_1} ({p.weight_lbs} lbs)
            </option>
          ))}
        </select>
        <button className="btn ghost fc-batch-btn" onClick={() => setShowBatch(s => !s)}>
          {showBatch ? 'Close batch' : 'Batch upload'}
        </button>
      </div>

      {showBatch && (
        <div className="fc-batch">
          <span className="hint">Upload .xlsx with <b>Part Number</b> + <b>Tier 1</b> → Summary + 12 monthly sheets (formula engine).</span>
          <input ref={fileRef} type="file" accept=".xlsx" onChange={e => runBatch(e.target.files?.[0])} disabled={batchBusy} />
          {batchBusy && <span className="hint">Processing…</span>}
          {batchMsg && <span className={batchMsg.ok ? 'fc-ok' : 'fc-bad'}>{batchMsg.text}</span>}
        </div>
      )}

      {busy && <div className="loading">Running both engines…</div>}
      {mode === 'formula' && err && !busy && <div className="calc-alert err">{err}</div>}
      {mode === 'ml' && mlErr && !busy && <div className="calc-alert err">ML model unavailable: {mlErr}</div>}

      {active && !busy && (
        <div className="fc-grid">
          {/* LEFT: hero price chart */}
          <div className="card fc-main">
            <div className="card-head">
              <h3>{mode === 'ml' ? 'ML' : 'Calculative'} price forecast · 12 months</h3>
              <span className="badge" style={{ background: accent + '18', color: accent, border: `1px solid ${accent}44` }}>
                {mode === 'ml' ? 'ExtraTrees model' : 'quarterly formula'}
              </span>
            </div>
            <div className="card-body" style={{ height: 360 }}>
              <ResponsiveContainer>
                <ComposedChart data={priceChart} margin={{ top: 8, right: 12, bottom: 0, left: 4 }}>
                  <defs>
                    <linearGradient id="fcFill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={accent} stopOpacity={0.22} />
                      <stop offset="100%" stopColor={accent} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid stroke={COLORS.grid} vertical={false} />
                  <XAxis dataKey="month" tick={{ fontSize: 10.5 }} minTickGap={16} />
                  <YAxis tick={{ fontSize: 10.5 }} width={62} domain={['auto', 'auto']}
                    tickFormatter={v => '$' + v.toLocaleString('en-US')} />
                  <Tooltip {...tooltipStyle}
                    formatter={(v, n, p) => ['$' + v.toLocaleString('en-US', { minimumFractionDigits: 4 }),
                      p.payload.kind === 'actual' ? 'Actual base' : `Predicted · ${p.payload.quarter}`]} />
                  <ReferenceLine x={priceChart[0]?.month} stroke={COLORS.navy} strokeDasharray="4 4"
                    label={{ value: 'today', position: 'insideTopLeft', fontSize: 10, fill: COLORS.navy }} />
                  <Area dataKey="price" stroke="none" fill="url(#fcFill)" />
                  <Line dataKey="price" stroke={accent} strokeWidth={2.8}
                    dot={{ r: 3, fill: accent }} activeDot={{ r: 5.5 }} />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* RIGHT: stat rail + two mini charts */}
          <div className="fc-side">
            <div className="fc-stats">
              <div className="fc-stat">
                <span className="fc-stat-label">Base · {active.base_year_month}</span>
                <span className="fc-stat-value">{fmt$(active.base_price)}</span>
              </div>
              <div className="fc-stat">
                <span className="fc-stat-label">Month 12</span>
                <span className="fc-stat-value" style={{ color: accent }}>{fmt$(active.forecasts[11].predicted_price)}</span>
              </div>
              <div className="fc-stat">
                <span className="fc-stat-label">12-mo change</span>
                <span className="fc-stat-value" style={{ color: totalPct >= 0 ? 'var(--gp-coral-dark)' : '#0E7490' }}>
                  {totalPct >= 0 ? '+' : ''}{totalPct.toFixed(1)}%
                </span>
              </div>
              <div className="fc-stat">
                <span className="fc-stat-label">Peak</span>
                <span className="fc-stat-value">{fmt$(peak)}</span>
              </div>
            </div>

            <div className="card fc-mini">
              <div className="mini-chart-title">Month-over-month %</div>
              <div style={{ height: 120 }}>
                <ResponsiveContainer>
                  <BarChart data={momChart} margin={{ top: 4, right: 4, bottom: 0, left: -18 }}>
                    <CartesianGrid stroke={COLORS.grid} vertical={false} />
                    <XAxis dataKey="month" tick={{ fontSize: 8.5 }} interval={1} />
                    <YAxis tick={{ fontSize: 9 }} width={30} tickFormatter={v => v + '%'} />
                    <Tooltip {...tooltipStyle} formatter={v => [v + '%', 'MoM']} />
                    <Bar dataKey="MoM" radius={[3, 3, 0, 0]}>
                      {momChart.map((r, i) => <Cell key={i} fill={r.MoM >= 0 ? accent : '#0E7490'} />)}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="card fc-mini">
              <div className="mini-chart-title">Calculative vs ML</div>
              <div style={{ height: 120 }}>
                {compareChart.length ? (
                  <ResponsiveContainer>
                    <LineChart data={compareChart} margin={{ top: 4, right: 6, bottom: 0, left: -18 }}>
                      <CartesianGrid stroke={COLORS.grid} vertical={false} />
                      <XAxis dataKey="month" tick={{ fontSize: 8.5 }} interval={2} tickFormatter={m => m.slice(2)} />
                      <YAxis tick={{ fontSize: 9 }} width={44} domain={['auto', 'auto']} tickFormatter={v => '$' + v} />
                      <Tooltip {...tooltipStyle} formatter={v => ['$' + v?.toLocaleString('en-US', { minimumFractionDigits: 2 })]} />
                      <Legend wrapperStyle={{ fontSize: 9.5 }} iconSize={8} />
                      <Line dataKey="Formula" stroke={FORMULA} strokeWidth={1.8} dot={false} />
                      <Line dataKey="ML" stroke={ML} strokeWidth={1.8} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                ) : <div className="loading" style={{ height: '100%', fontSize: 12 }}>{mlErr ? 'ML unavailable' : '…'}</div>}
              </div>
            </div>
          </div>
        </div>
      )}

      {active && !busy && (
        <button className="fc-details-toggle" onClick={() => setShowTable(s => !s)}>
          {showTable ? '▾ Hide' : '▸ Show'} formula variables per month
        </button>
      )}
      {active && !busy && showTable && (
        <div className="card">
          <div className="sql-table-wrap" style={{ maxHeight: 280 }}>
            <table className="sql-table">
              <thead><tr>
                {['Month', 'Qtr', 'MC_Q', 'MC_Q-1', 'PPI_Q', 'PPI_Q-1', 'PPI Fac', 'CNG_Q', 'AMS_Q', 'AMS_Q-1', 'ΔAMS', 'Base', 'Predicted'].map(h => <th key={h}>{h}</th>)}
              </tr></thead>
              <tbody>
                {active.forecasts.map(f => {
                  const q = f.quarter_context
                  return (
                    <tr key={f.year_month}>
                      <td>{f.year_month}</td><td>{q.quarter_label}</td>
                      <td>{q.mc_q.toFixed(3)}</td><td>{q.mc_q_prev.toFixed(3)}</td>
                      <td>{q.ppi_q.toFixed(1)}</td><td>{q.ppi_q_prev.toFixed(1)}</td>
                      <td>{(q.ppi_factor * 100).toFixed(3)}%</td>
                      <td>{q.cng_q.toFixed(3)}</td><td>{q.ams_q.toFixed(3)}</td><td>{q.ams_q_prev.toFixed(3)}</td>
                      <td>{q.ams_delta.toFixed(3)}</td><td>${f.base_price_used.toFixed(2)}</td>
                      <td style={{ fontWeight: 700 }}>${f.predicted_price.toFixed(2)}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
