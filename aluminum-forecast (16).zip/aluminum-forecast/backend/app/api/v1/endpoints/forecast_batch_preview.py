"""
Batch preview endpoint - /api/v1/forecast-batch-preview

Returns the SAME forecast data as /forecast-batch but as JSON, so the UI can
render the Summary + monthly sheets in tables before the user downloads the
.xlsx. Reuses the existing engine and batch reader; adds no forecasting logic.
"""
import logging

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, status

from app.data.base import MarketDataRepository, PartRepository
from app.data.excel_store import ExcelMarketDataRepository, ExcelPartRepository
from app.models.response import ForecastResponse
from app.services.batch_forecast import read_parts_from_upload
from app.services.forecast_engine import ForecastEngine

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/forecast-batch-preview", tags=["forecast-batch"])


def get_market_repo() -> MarketDataRepository:
    return ExcelMarketDataRepository()

def get_part_repo() -> PartRepository:
    return ExcelPartRepository()

def get_engine(
    market_repo: MarketDataRepository = Depends(get_market_repo),
    part_repo: PartRepository = Depends(get_part_repo),
) -> ForecastEngine:
    return ForecastEngine(market_repo=market_repo, part_repo=part_repo)


@router.post("", summary="Batch forecast preview as JSON (for on-screen tables)")
async def forecast_batch_preview(
    file: UploadFile = File(...),
    engine: ForecastEngine = Depends(get_engine),
) -> dict:
    if not file.filename or not file.filename.lower().endswith(".xlsx"):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Only .xlsx files are accepted.")
    file_bytes = await file.read()
    try:
        pairs = read_parts_from_upload(file_bytes)
    except ValueError as exc:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc))
    if not pairs:
        raise HTTPException(status.HTTP_400_BAD_REQUEST,
                            "No valid (Part Number, Tier 1) pairs found.")

    results = {}
    for pn, t1 in pairs:
        try:
            results[(pn, t1)] = engine.forecast(part_number=pn, tier_1=t1)
        except Exception as exc:
            results[(pn, t1)] = exc

    month_labels = []
    for r in results.values():
        if isinstance(r, ForecastResponse):
            month_labels = [(f.year_month, f.month_label) for f in r.forecasts]
            break
    if not month_labels:
        raise HTTPException(status.HTTP_400_BAD_REQUEST,
                            "All parts failed — check the part numbers and Tier 1 values.")

    ok = sum(1 for r in results.values() if isinstance(r, ForecastResponse))
    failed = len(results) - ok

    # Summary rows: part, tier, weight, base, then predicted per month
    summary_rows = []
    for (pn, t1), r in results.items():
        if isinstance(r, ForecastResponse):
            summary_rows.append({
                "part_number": pn, "tier_1": t1, "error": None,
                "weight_lbs": r.pwt_lbs, "base_price": r.base_price,
                "monthly": [f.predicted_price for f in r.forecasts],
            })
        else:
            summary_rows.append({
                "part_number": pn, "tier_1": t1, "error": str(r),
                "weight_lbs": None, "base_price": None, "monthly": [],
            })

    # One sheet per month with all intermediate variables
    monthly_sheets = []
    for ym, label in month_labels:
        rows = []
        for (pn, t1), r in results.items():
            if not isinstance(r, ForecastResponse):
                rows.append({"part_number": pn, "tier_1": t1, "error": str(r)})
                continue
            mf = next((f for f in r.forecasts if f.year_month == ym), None)
            if not mf:
                rows.append({"part_number": pn, "tier_1": t1, "error": "no data"})
                continue
            q = mf.quarter_context
            rows.append({
                "part_number": pn, "tier_1": t1, "error": None,
                "weight_lbs": r.pwt_lbs, "base_price_used": mf.base_price_used,
                "quarter": q.quarter_label, "prev_quarter": q.prev_quarter_label,
                "mc_q": q.mc_q, "mc_q_prev": q.mc_q_prev,
                "ppi_q": q.ppi_q, "ppi_q_prev": q.ppi_q_prev,
                "ppi_factor": q.ppi_factor, "cng_q": q.cng_q, "cng_q_prev": q.cng_q_prev,
                "ams_q": q.ams_q, "ams_q_prev": q.ams_q_prev, "ams_delta": q.ams_delta,
                "df_c": mf.df_c, "predicted_price": mf.predicted_price,
            })
        monthly_sheets.append({"year_month": ym, "label": label, "rows": rows})

    return {
        "part_count": len(pairs), "ok": ok, "failed": failed,
        "months": [{"year_month": ym, "label": lb} for ym, lb in month_labels],
        "summary": summary_rows,
        "monthly_sheets": monthly_sheets,
    }
