ML MODEL FILE — best_price_model.pkl
─────────────────────────────────────
This project ships WITHOUT the trained model file (best_price_model.pkl was
removed to avoid antivirus false positives — pickle files are heuristically
flagged by many AV engines even when safe).

The ML Forecast tab needs it. To enable that tab:

  1. Place your best_price_model.pkl in THIS folder (next to main.py / app/),
     OR anywhere and set the ML_MODEL_PATH environment variable to its path:
         Windows : set ML_MODEL_PATH=C:\full\path\to\best_price_model.pkl
         Mac/Linux: export ML_MODEL_PATH=/full/path/to/best_price_model.pkl

  2. Start the backend (or if already running, call:
         POST http://localhost:8000/api/v1/forecast-ml/reload-model )

Until the file is present, everything else works normally; only the
"ML Forecast" tab shows a clear "model unavailable" message. The
"Calculative" forecast tab does not need this file.
