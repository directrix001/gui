import { Link } from 'react-router-dom'

const FEATURES = [
  {
    to: '/dashboard', title: 'Dashboard',
    text: 'Real driver data charted — history and forward months.',
    icon: 'M3 13h4v8H3zM10 8h4v13h-4zM17 3h4v18h-4z',
  },
  {
    to: '/calculator', title: 'Cost Estimation',
    text: 'Compute P_New — one part manually, or a whole Excel at once.',
    icon: 'M4 19h16M6 16V9M10 16V5M14 16v-6M18 16V8',
  },
  {
    to: '/validation', title: 'Validator',
    text: 'FRED vs LME cross-check and automated rule checks.',
    icon: 'M9 12l2 2 4-4M12 21a9 9 0 100-18 9 9 0 000 18z',
  },
  {
    to: '/forecast', title: 'Forecast',
    text: '12-month part forecasts from the quarterly formula engine.',
    icon: 'M3 17l6-6 4 4 8-8M15 7h6v6',
  },
  {
    to: '/data', title: 'Data',
    text: 'Push month + value rows into each factor database — manual or file.',
    icon: 'M4 6c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3zM4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6',
  },
  {
    to: '/news', title: 'News & Intelligence',
    text: 'Live and historical coverage of every driver, with its own News AI.',
    icon: 'M4 5h16v14H4zM4 9h16M8 13h8M8 16h5',
  },
]

function Icon({ d, size = 22 }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke="currentColor"
      strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d={d} /></svg>
  )
}

export default function Landing() {
  return (
    <div className="landing">
      <section className="hero">
        <div className="hero-inner">
          <span className="hero-kicker">Metals Analytics · Aluminum</span>
          <h1>
            Aluminum price intelligence,<br />
            <em>from real data to 12-month forecasts.</em>
          </h1>
          <div className="hero-actions">
            <Link to="/dashboard" className="btn">Open Dashboard</Link>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="feature-grid">
          {FEATURES.map(f => (
            <Link to={f.to} className="feature-card" key={f.to + f.title}>
              <span className="feature-icon"><Icon d={f.icon} /></span>
              <h3>{f.title}</h3>
              <p>{f.text}</p>
              <span className="feature-more">Open →</span>
            </Link>
          ))}
        </div>
      </section>
    </div>
  )
}
