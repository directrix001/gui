# Aluminum Price Intelligence Platform

A full-stack platform for aluminum commodity price analysis, combining a
multi-agent conversational assistant over real factor databases, a two-engine
12-month forecasting system (analytical formula + ML model), live/historical
factor news, and a source-validation dashboard.

Built with **FastAPI** (Python) and **React 18 + Vite + Recharts**.

---

## Features

| Area | What it does |
|------|--------------|
| **Dashboard** | Real driver charts — LME, Midwest Premium (combined + total), CNG, PPI — with history-vs-forward segregation |
| **Cost Estimation** | Compute a new part price from the quarterly formula — single entry or Excel batch |
| **Validator** | FRED vs LME 3-month source cross-check with variance % |
| **Forecast** | Two engines side by side — **Calculative** (analytical quarterly formula) and **ML** (trained model). Single-part view with charts, plus batch upload that previews every sheet on screen and downloads a full workbook |
| **Data** | Read-only searchable view of all four factor databases |
| **News & Intelligence** | Google News (live) + GDELT (historical) coverage of every price driver, with its own News AI |
| **Assistant** | Multi-agent chatbot: text-to-SQL over real databases, movement analysis with web correlation, change (QoQ/MoM/YoY) analysis — streamed, with guardrails |

---

## Architecture

```
aluminum-forecast/
├── backend/                       FastAPI application
│   ├── main.py-equivalent → app/main.py   (single-server: also serves the built frontend)
│   ├── best_price_model.pkl       Trained ML model (ExtraTrees pipeline)
│   ├── aluminium_data.xlsx         Parts + market data for the forecast engine
│   ├── requirements.txt
│   └── app/
│       ├── main.py                 App entry, routes, single-server mount
│       ├── agents.py               Multi-agent assistant (router, SQL, movement, correlation, synthesizer)
│       ├── sql_agent.py            Text-to-SQL generation + validation
│       ├── factor_dbs.py           4 real per-factor SQLite DBs + cross-DB view
│       ├── news.py                 Google News RSS + GDELT news module
│       ├── calculator.py           Price formula calculator
│       ├── api/v1/                 Forecast API (formula, batch, ML) — see app/README
│       ├── core/                   config + logging
│       ├── data/                   repositories (Excel-backed) + real CSVs
│       ├── models/                 Pydantic request/response
│       └── services/               forecast_engine, ml_forecast_engine, batch_forecast
│
├── frontend/                      React + Vite SPA
│   ├── src/pages/                  Dashboard, Forecast, Calculator, Validation, DataManager, News, Landing
│   ├── src/components/             ChatWidget, ui
│   └── src/styles.css
│
├── render.yaml                    Render.com blueprint
├── DEPLOY.md                      Deployment walkthrough
└── README.md                      (this file)
```

**Design principles:** deterministic retrieval (fixed SQL + validated text-to-SQL)
with the LLM only synthesizing from structured evidence; read-only DB connections;
graceful degradation everywhere (no key → template answers; no model → formula
still works; no web → DB-only answers).

---

## Quick start

### Prerequisites
- Python 3.12+
- Node.js 18+
- (optional) An `OPENAI_API_KEY` for LLM-powered chat/news answers — works without one

### 1. Backend
```bash
cd backend
pip install -r requirements.txt
python -m uvicorn app.main:app --reload --port 8000
```
On startup you should see:
```
[ok] master.db built: {'lme': 27, 'midwest_premium': 27, 'gas': 27, 'labour': 30, 'events': 7}
[ok] news ready: {...}
```

### 2. Frontend (dev mode)
```bash
cd frontend
npm install
npm run dev          # → http://localhost:5173
```

### 3. Single-server mode (production layout)
```bash
cd frontend && npm run build      # builds into frontend/dist
cd ../backend && python -m uvicorn app.main:app --port 8000
# → open http://localhost:8000  (site + API on one port, exactly like Render)
```

---

## Optional configuration (environment variables)

| Variable | Purpose | Default |
|----------|---------|---------|
| `OPENAI_API_KEY` | Enables GPT-powered assistant/news answers | none (template mode) |
| `OPENAI_MODEL` | Chat model | `gpt-4o-mini` |
| `OPENAI_NEWS_MODEL` | News AI model | `gpt-4.1-mini` |
| `ML_MODEL_PATH` | Path to `best_price_model.pkl` | `backend/best_price_model.pkl` |
| `ALUMINIUM_EXCEL_PATH` | Path to `aluminium_data.xlsx` | `backend/aluminium_data.xlsx` |

Put these in `backend/.env` (loaded automatically) or your shell.

---

## Forecast engines

**Calculative (formula):**
```
P_next = P_current + [(AMS_Q − AMS_Q-1) × PWt] + (PPI_Factor × P_current)
AMS = (MC × DF_c) + CNG,   MC = avg(LME) + avg(Midwest) over the quarter
PPI_Factor = (PPI_Q − PPI_Q-1) / PPI_Q-1,   DF_c = 1.44
```
Chained month-over-month for 12 months.

**ML:** same request/response contract, `predicted_price` from `best_price_model.pkl`
(feature order: Weight, Current Price, MC_Q, MC_Q-1, PPI_Q, PPI_Q-1, CNG_Q, CNG_Q-1, DF_c).
Swap the model by replacing the pickle and calling `POST /api/v1/forecast-ml/reload-model`.

---

## Key API endpoints

```
GET  /api/real/drivers                     4 factor series (dashboard/data)
POST /api/agent/chat[/stream]              multi-agent assistant
POST /api/calculator/single | /batch       price calculator
GET  /api/comparison                        FRED vs LME
GET  /api/news | /api/news/chat            news + news AI
POST /api/v1/forecast-excel                 single-part formula forecast
POST /api/v1/forecast-ml                    single-part ML forecast
POST /api/v1/forecast-batch                 batch → .xlsx download
POST /api/v1/forecast-batch-preview         batch → JSON (on-screen tables)
GET  /docs                                  interactive API docs
```

---

## Deployment

See **DEPLOY.md**. In short: push to GitHub, connect to Render using `render.yaml`.
The 50 MB model file is tracked via **Git LFS** (see `.gitattributes`) — run
`git lfs install` once before cloning/pushing.

---

## Notes

- `best_price_model.pkl` is a Python pickle; some antivirus tools heuristically
  flag `.pkl` files. This one is a scikit-learn model artifact and is safe.
- Factor databases are rebuilt from `backend/app/data/real/*.csv` at startup, so
  the app is reproducible from source.
