#!/usr/bin/env bash
# Single-server: build frontend, serve everything from :8000
set -e
( cd frontend && npm install && npm run build )
cd backend && pip install -r requirements.txt && python -m uvicorn app.main:app --port 8000
