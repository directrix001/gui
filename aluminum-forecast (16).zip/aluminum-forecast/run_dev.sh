#!/usr/bin/env bash
# Dev mode: backend on :8000, frontend on :5173. Ctrl+C stops both.
set -e
( cd backend && python -m uvicorn app.main:app --reload --port 8000 ) &
BACK=$!
( cd frontend && npm run dev ) &
FRONT=$!
trap "kill $BACK $FRONT 2>/dev/null" EXIT
wait
