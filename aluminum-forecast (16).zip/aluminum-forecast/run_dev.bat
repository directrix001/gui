@echo off
REM Dev mode on Windows: two windows (backend :8000, frontend :5173)
start "backend" cmd /k "cd backend && python -m uvicorn app.main:app --reload --port 8000"
start "frontend" cmd /k "cd frontend && npm run dev"
echo Backend on :8000, frontend on :5173
