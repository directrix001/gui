import { useRef, useState } from 'react'
import { COLORS } from '../components/ui.jsx'

const FIELDS = [
  ['weight', 'Part Weight (PWt)', 3.6],
  ['current_price', 'Current Price (P_Current)', 47.09],
  ['ppi_q', 'PPI — Current Quarter', 281.07],
  ['ppi_q1', 'PPI — Previous Quarter (PPI_Q-1)', 263.8],
  ['drauss_factor', 'Drauss / Conversion Factor (DF_c)', 1.44],
  ['mc_q', 'Metal Cost — Current Quarter (MC_Q)', 3.26],
  ['mc_q_1', 'Metal Cost — Previous Quarter (MC_Q-1)', 2.90],
  ['cng_q', 'CNG Cost — Current Quarter', 0.97],
  ['cng_q_1', 'CNG Cost — Previous Quarter (CNG_Q-1)', 0.72],
]

const num = (v, d = 4) =>
  v == null || Number.isNaN(Number(v)) ? '—' : Number(v).toLocaleString('en-US', { maximumFractionDigits: d })

export default function Calculator() {
  // ---- manual mode ----
  const [form, setForm] = useState(Object.fromEntries(FIELDS.map(([k, , d]) => [k, d])))
  const [result, setResult] = useState(null)
  const [calcErr, setCalcErr] = useState(null)
  const [busy, setBusy] = useState(false)

  // ---- batch mode ----
  const [drag, setDrag] = useState(false)
  const [batch, setBatch] = useState(null)
  const [batchErr, setBatchErr] = useState(null)
  const [batchBusy, setBatchBusy] = useState(false)
  const inputRef = useRef()

  async function calculate() {
    setBusy(true); setCalcErr(null); setResult(null)
    try {
      const payload = Object.fromEntries(
        Object.entries(form).map(([k, v]) => [k, parseFloat(v)]))
      if (Object.values(payload).some(v => Number.isNaN(v)))
        throw new Error('All fields must be valid numbers.')
      const res = await fetch('/api/calculator/single', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.detail || 'Calculation failed')
      setResult(data)
    } catch (e) { setCalcErr(e.message) }
    finally { setBusy(false) }
  }

  async function handleFile(file) {
    if (!file) return
    setBatchBusy(true); setBatchErr(null); setBatch(null)
    try {
      const fd = new FormData()
      fd.append('file', file)
      const res = await fetch('/api/calculator/batch', { method: 'POST', body: fd })
      const data = await res.json()
      if (!res.ok) throw new Error(data.detail || 'Upload failed')
      setBatch(data)
    } catch (e) { setBatchErr(e.message) }
    finally { setBatchBusy(false) }
  }

  function downloadCsv() {
    if (!batch?.results?.length) return
    const cols = Object.keys(batch.results[0])
    const esc = v => {
      const s = v == null ? '' : String(v)
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s
    }
    const csv = [cols.join(','), ...batch.results.map(r => cols.map(c => esc(r[c])).join(','))].join('\n')
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }))
    const a = document.createElement('a')
    a.href = url; a.download = 'new_price_results.csv'; a.click()
    URL.revokeObjectURL(url)
  }

  const previewCols = batch?.results?.length ? Object.keys(batch.results[0]) : []

  return (
    <div className="page">
      {/* formula reference */}
      <div className="card" style={{ padding: '16px 20px' }}>
        <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontWeight: 600, marginBottom: 6 }}>
          Pricing Formula
        </div>
        <div className="mono" style={{ color: COLORS.slate, lineHeight: 1.8, fontSize: 12.5 }}>
          AMS_Q = (MC_Q × DF_c) + CNG_Q &nbsp;·&nbsp; AMS_Q-1 = (MC_Q-1 × DF_c) + CNG_Q-1 &nbsp;·&nbsp;
          PPI_Factor = (PPI_Q − PPI_Q-1) / PPI_Q-1<br />
          <strong style={{ color: COLORS.coralDark }}>
            P_New = P_Current + [(AMS_Q − AMS_Q-1) × PWt] + (PPI_Factor × P_Current)
          </strong>
        </div>
      </div>

      <div className="grid-2e">
        {/* ---- manual entry ---- */}
        <div className="card">
          <div className="card-head">
            <h3>Manual Calculation</h3>
            <span className="hint">Enter values and compute one price</span>
          </div>
          <div className="card-body">
            <div className="calc-grid">
              {FIELDS.map(([key, label]) => (
                <label key={key} className="calc-field">
                  <span>{label}</span>
                  <input
                    type="number" step="any" value={form[key]}
                    onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                  />
                </label>
              ))}
            </div>
            <button className="btn" style={{ marginTop: 16 }} onClick={calculate} disabled={busy}>
              {busy ? 'Calculating…' : 'Calculate New Price'}
            </button>

            {calcErr && (
              <div className="calc-alert err">{calcErr}</div>
            )}
            {result && (
              <div className="calc-result">
                <div className="calc-main">
                  <span>New Price (P_New)</span>
                  <strong>{num(result.new_price)}</strong>
                </div>
                <div className="calc-sub">
                  <div><span>AMS_Q</span><strong>{num(result.ams_q)}</strong></div>
                  <div><span>AMS_Q-1</span><strong>{num(result.ams_q_1)}</strong></div>
                  <div><span>PPI Factor</span><strong>{num(result.ppi_factor, 6)}</strong></div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* ---- excel batch ---- */}
        <div className="card">
          <div className="card-head">
            <h3>Excel / CSV Batch</h3>
            <span className="hint">Upload a file → get the new price column</span>
          </div>
          <div className="card-body">
            <div
              className={`dropzone${drag ? ' drag' : ''}`}
              style={{ padding: 28 }}
              onDragOver={e => { e.preventDefault(); setDrag(true) }}
              onDragLeave={() => setDrag(false)}
              onDrop={e => { e.preventDefault(); setDrag(false); handleFile(e.dataTransfer.files[0]) }}
            >
              <h4>{batchBusy ? 'Computing…' : 'Drop your file here'}</h4>
              <p style={{ marginBottom: 14, fontSize: 12.5 }}>
                Columns: weight/PWt, current_price/P_Current, PPI_Q, PPI_Q-1, MC_Q, MC_Q-1,
                CNG_Q, CNG_Q-1 (DF_c optional, defaults 1.44). Flexible naming.
              </p>
              <button className="btn" onClick={() => inputRef.current.click()} disabled={batchBusy}>
                Choose file
              </button>
              <input ref={inputRef} type="file" accept=".csv,.xlsx,.xls" hidden
                onChange={e => { handleFile(e.target.files[0]); e.target.value = '' }} />
            </div>

            {batchErr && <div className="calc-alert err">{batchErr}</div>}
            {batch && (
              <div style={{ marginTop: 14 }}>
                <div className="calc-alert ok">
                  <strong>{batch.filename}</strong> — {batch.count} rows calculated
                  {batch.errors.length > 0 && `, ${batch.errors.length} row(s) skipped`}.
                  <button className="btn" style={{ marginLeft: 12, padding: '6px 14px', fontSize: 12 }}
                    onClick={downloadCsv}>
                    Download results CSV
                  </button>
                </div>
                {batch.errors.length > 0 && (
                  <div className="calc-alert warn">
                    {batch.errors.slice(0, 5).map(e => `Row ${e.row}: ${e.error}`).join(' · ')}
                    {batch.errors.length > 5 && ` · +${batch.errors.length - 5} more`}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ---- results preview ---- */}
      {batch?.results?.length > 0 && (
        <div className="card">
          <div className="card-head">
            <h3>Results Preview</h3>
            <span className="hint">
              First {Math.min(batch.results.length, 50)} of {batch.count} rows — new_price appended
            </span>
          </div>
          <div className="card-body" style={{ overflowX: 'auto' }}>
            <table>
              <thead>
                <tr>{previewCols.map(c => (
                  <th key={c} style={c === 'new_price' ? { color: COLORS.coralDark } : undefined}>{c}</th>
                ))}</tr>
              </thead>
              <tbody>
                {batch.results.slice(0, 50).map((r, i) => (
                  <tr key={i}>
                    {previewCols.map(c => (
                      <td key={c} className="mono"
                        style={c === 'new_price' ? { fontWeight: 700, color: COLORS.coralDark } : undefined}>
                        {typeof r[c] === 'number' ? num(r[c]) : String(r[c] ?? '—')}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
