"""
Factor database layer — one SQLite database per aluminum price driver, plus a
registry database that holds the factor catalog, historical events, and the
relationships between them.

Layout (backend/app/data/factors/):
    lme.db              monthly_values      ← REAL data (FRED/LME csv, 222 months)
    midwest_premium.db  monthly_values      ← dummy history (replace later)
    gas.db              monthly_values      ← dummy history
    labour.db           monthly_values      ← dummy history
    macro.db            monthly_values      ← dummy history (supply−demand)
    external.db         monthly_values      ← dummy history
    registry.db         factors             catalog: key, name, db file, effect
                        events              historical events with month + impact
                        event_factors       M:N relationship events ↔ factors

Relationships:
  • every monthly_values table shares the same key: month TEXT 'YYYY-MM'
    → cross-factor joins are done on month (see month_snapshot()).
  • registry.factors.key ↔ each factor db (1:1, via db_file column).
  • registry.event_factors(event_id, factor_key) links events to the factors
    they moved (many-to-many).
"""
import sqlite3
from pathlib import Path

FACTOR_DIR = Path(__file__).parent / "data" / "factors"

FACTORS = {
    "lme":             {"name": "LME Base Price",        "effect": "+", "unit": "USD/t", "db": "lme.db"},
    "midwest_premium": {"name": "US Midwest Premium",    "effect": "+", "unit": "USD/t", "db": "midwest_premium.db"},
    "gas":             {"name": "Gas Coefficient",       "effect": "+", "unit": "USD/t", "db": "gas.db"},
    "labour":          {"name": "Labour Index",          "effect": "+", "unit": "USD/t", "db": "labour.db"},
    "macro":           {"name": "Macro (Supply−Demand)", "effect": "-", "unit": "USD/t", "db": "macro.db"},
    "external":        {"name": "External Factor",       "effect": "+", "unit": "USD/t", "db": "external.db"},
}

# Curated historical events (dummy but realistic) linked to factors.
EVENTS = [
    ("2008-10", "Global financial crisis demand collapse", "macro_shock", "down",
     "Industrial demand fell sharply worldwide; aluminum sold off with all commodities.", ["lme", "macro"]),
    ("2018-03", "US Section 232 tariffs (10% on aluminum imports)", "tariff", "up",
     "Import tariffs pushed the US Midwest Premium sharply higher.", ["midwest_premium", "external"]),
    ("2018-04", "Rusal sanctions", "geopolitical", "up",
     "Sanctions on a major producer squeezed global supply expectations.", ["lme", "external"]),
    ("2020-03", "COVID-19 demand shock", "macro_shock", "down",
     "Lockdowns cut transport and construction demand; prices slid to multi-year lows.", ["lme", "macro"]),
    ("2021-09", "China dual-control energy curbs on smelters", "china_supply", "up",
     "Power rationing curtailed Chinese smelter output, tightening supply.", ["lme", "macro", "gas"]),
    ("2021-10", "European energy crisis smelter curtailments", "energy", "up",
     "Record gas/power prices forced EU smelters to cut output.", ["gas", "lme"]),
    ("2022-02", "Russia invades Ukraine", "geopolitical", "up",
     "War risk on Russian metal plus energy spike drove LME to record highs.", ["lme", "gas", "external"]),
    ("2022-03", "LME price spike to all-time highs", "geopolitical", "up",
     "Peak of the supply-fear rally; freight and premiums surged too.", ["lme", "midwest_premium"]),
    ("2022-06", "Global rate hikes cool demand", "macro_shock", "down",
     "Aggressive central-bank tightening hit industrial demand expectations.", ["macro", "lme"]),
    ("2023-08", "Soft China recovery weighs on prices", "china_demand", "down",
     "Weaker-than-hoped Chinese construction demand kept prices subdued.", ["macro", "lme"]),
    ("2024-04", "US/UK ban Russian metal on LME", "geopolitical", "up",
     "New deliveries of Russian aluminum barred from LME warehouses.", ["lme", "external"]),
    ("2025-04", "Tariff escalation uncertainty", "tariff", "down",
     "Broad trade-war fears knocked industrial metals before premiums re-priced.", ["lme", "midwest_premium", "external"]),
    ("2026-01", "Supply deficit narrative builds", "macro_shock", "up",
     "Reports of a widening supply deficit and restocking lifted prices.", ["macro", "lme"]),
    ("2026-04", "Energy cost pass-through accelerates", "energy", "up",
     "Higher gas benchmarks fed directly into smelting cost curves.", ["gas", "lme"]),
]


def _conn(db: str) -> sqlite3.Connection:
    c = sqlite3.connect(FACTOR_DIR / db)
    c.row_factory = sqlite3.Row
    return c


def seed_factor_dbs(series: dict[str, tuple[list[str], list[float]]],
                    lme_real: list[tuple[str, float]] | None = None) -> dict:
    """Create/refresh one DB per factor + the registry. `series` maps factor key
    → (labels, values) dummy history; `lme_real` optionally overrides LME with
    real (month, price) rows."""
    FACTOR_DIR.mkdir(parents=True, exist_ok=True)
    counts = {}

    for key, meta in FACTORS.items():
        conn = _conn(meta["db"])
        try:
            conn.execute("DROP TABLE IF EXISTS monthly_values")
            conn.execute("""CREATE TABLE monthly_values (
                month TEXT PRIMARY KEY, value REAL NOT NULL,
                source TEXT NOT NULL DEFAULT 'dummy')""")
            if key == "lme" and lme_real:
                rows = [(m, v, "real:fred_lme_csv") for m, v in lme_real if v is not None]
            else:
                labels, values = series[key]
                rows = [(m, round(float(v), 2), "dummy") for m, v in zip(labels, values)]
            conn.executemany(
                "INSERT INTO monthly_values (month, value, source) VALUES (?,?,?)", rows)
            conn.commit()
            counts[key] = len(rows)
        finally:
            conn.close()

    reg = _conn("registry.db")
    try:
        reg.executescript("""
            DROP TABLE IF EXISTS factors;
            DROP TABLE IF EXISTS events;
            DROP TABLE IF EXISTS event_factors;
            CREATE TABLE factors (
                key TEXT PRIMARY KEY, name TEXT, effect TEXT, unit TEXT, db_file TEXT);
            CREATE TABLE events (
                id INTEGER PRIMARY KEY, month TEXT, title TEXT,
                category TEXT, impact TEXT, note TEXT);
            CREATE TABLE event_factors (
                event_id INTEGER REFERENCES events(id),
                factor_key TEXT REFERENCES factors(key),
                PRIMARY KEY (event_id, factor_key));
        """)
        reg.executemany("INSERT INTO factors VALUES (?,?,?,?,?)",
            [(k, m["name"], m["effect"], m["unit"], m["db"]) for k, m in FACTORS.items()])
        for i, (month, title, cat, impact, note, fks) in enumerate(EVENTS, start=1):
            reg.execute("INSERT INTO events VALUES (?,?,?,?,?,?)",
                        (i, month, title, cat, impact, note))
            reg.executemany("INSERT INTO event_factors VALUES (?,?)",
                            [(i, fk) for fk in fks])
        reg.commit()
        counts["events"] = len(EVENTS)
    finally:
        reg.close()
    return counts


def get_factor_value(key: str, month: str) -> float | None:
    conn = _conn(FACTORS[key]["db"])
    try:
        r = conn.execute(
            "SELECT value FROM monthly_values WHERE month=?", (month,)).fetchone()
        return r["value"] if r else None
    finally:
        conn.close()


def get_factor_series(key: str, start: str | None = None, end: str | None = None) -> list[dict]:
    conn = _conn(FACTORS[key]["db"])
    try:
        q, args = "SELECT month, value, source FROM monthly_values", []
        conds = []
        if start: conds.append("month >= ?"); args.append(start)
        if end: conds.append("month <= ?"); args.append(end)
        if conds: q += " WHERE " + " AND ".join(conds)
        q += " ORDER BY month"
        return [dict(r) for r in conn.execute(q, args).fetchall()]
    finally:
        conn.close()


def month_snapshot(month: str) -> dict:
    """Cross-database join on the shared month key: every factor's value at
    `month` and the previous month, with absolute / % change."""
    out = {}
    for key, meta in FACTORS.items():
        conn = _conn(meta["db"])
        try:
            rows = conn.execute(
                "SELECT month, value FROM monthly_values WHERE month <= ? "
                "ORDER BY month DESC LIMIT 2", (month,)).fetchall()
        finally:
            conn.close()
        cur = rows[0] if rows and rows[0]["month"] == month else None
        prev = rows[1] if len(rows) > 1 and cur else (rows[0] if rows and not cur else None)
        cv = cur["value"] if cur else None
        pv = prev["value"] if prev else None
        out[key] = {
            "name": meta["name"], "effect": meta["effect"],
            "value": cv, "prev": pv,
            "change": round(cv - pv, 2) if cv is not None and pv is not None else None,
            "change_pct": round((cv - pv) / pv * 100, 2)
                          if cv is not None and pv not in (None, 0) else None,
        }
    return out


def events_near(month: str, window: int = 1) -> list[dict]:
    """Events at `month` ± `window` months, with their linked factors."""
    y, m = int(month[:4]), int(month[5:7])
    keep = set()
    for d in range(-window, window + 1):
        mm = m + d
        yy = y + (mm - 1) // 12
        mm = (mm - 1) % 12 + 1
        keep.add(f"{yy:04d}-{mm:02d}")
    reg = _conn("registry.db")
    try:
        rows = reg.execute(
            f"""SELECT e.*, GROUP_CONCAT(ef.factor_key) AS factor_keys
                FROM events e LEFT JOIN event_factors ef ON ef.event_id = e.id
                WHERE e.month IN ({','.join('?' * len(keep))})
                GROUP BY e.id ORDER BY e.month""", list(keep)).fetchall()
        return [dict(r) for r in rows]
    finally:
        reg.close()


def db_inventory() -> list[dict]:
    inv = []
    for key, meta in FACTORS.items():
        conn = _conn(meta["db"])
        try:
            n, lo, hi = conn.execute(
                "SELECT COUNT(*), MIN(month), MAX(month) FROM monthly_values").fetchone()
            src = conn.execute(
                "SELECT source, COUNT(*) c FROM monthly_values GROUP BY source "
                "ORDER BY c DESC").fetchone()
        finally:
            conn.close()
        inv.append({"key": key, "db": meta["db"], "name": meta["name"],
                    "rows": n, "from": lo, "to": hi,
                    "primary_source": src["source"] if src else None})
    return inv
