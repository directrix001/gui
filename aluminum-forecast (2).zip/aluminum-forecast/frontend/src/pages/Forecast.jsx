import { useEffect, useState } from 'react'
import {
  ResponsiveContainer, ComposedChart, Area, Line, XAxis, YAxis,
  CartesianGrid, Tooltip, Legend, ReferenceLine,
} from 'recharts'
import { api } from '../api/client.js'
import { COLORS, Loading, ErrorBox, usd, tooltipStyle } from '../components/ui.jsx'

const COMPONENTS = [
  { key: 'all_in', label: 'All-in Price' },
  { key: 'lme', label: 'LME Base' },
  { key: 'midwest_premium', label: 'Midwest Premium' },
]

export default function Forecast() {
  const [component, setComponent] = useState('all_in')
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)

  useEffect(() => {
    setData(null)
    api.forecast(component).then(setData).catch(setError)
  }, [component])

  if (error) return <div className="page"><ErrorBox error={error} /></div>
  if (!data) return <div className="page"><Loading label="Building forecast…" /></div>

  const hist = data.history.labels.map((m, i) => ({
    month: m, actual: data.history.values[i],
  }))
  const lastActual = hist[hist.length - 1]
  const fcst = data.forecast.labels.map((m, i) => ({
    month: m,
    mean: data.forecast.mean[i],
    band: [data.forecast.lower_80[i], data.forecast.upper_80[i]],
  }))
  // bridge so the forecast line connects to the last actual point
  const merged = [...hist.slice(0, -1),
    { ...lastActual, mean: lastActual.actual, band: [lastActual.actual, lastActual.actual] },
    ...fcst]

  return (
    <div className="page">
      <div className="card">
        <div className="card-head">
          <h3>Monthly forecast · next 12 months</h3>
          <div className="seg" role="tablist" aria-label="Forecast component">
            {COMPONENTS.map(c => (
              <button key={c.key} className={component === c.key ? 'active' : ''}
                onClick={() => setComponent(c.key)}>{c.label}</button>
            ))}
          </div>
        </div>
        <div className="card-body" style={{ height: 380 }}>
          <ResponsiveContainer>
            <ComposedChart data={merged}>
              <CartesianGrid stroke={COLORS.grid} vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} minTickGap={24} />
              <YAxis tick={{ fontSize: 11 }} tickFormatter={usd} width={64}
                domain={['auto', 'auto']} />
              <Tooltip {...tooltipStyle}
                formatter={(v, name) =>
                  Array.isArray(v) ? [`${usd(v[0])} – ${usd(v[1])}`, '80% band'] : [usd(v), name]} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Area dataKey="band" name="80% confidence" fill={COLORS.band}
                stroke="none" connectNulls />
              <Line dataKey="actual" name="Actual" stroke={COLORS.navy}
                strokeWidth={2.2} dot={false} connectNulls />
              <Line dataKey="mean" name="Forecast" stroke={COLORS.coral}
                strokeWidth={2.4} strokeDasharray="6 4" dot={{ r: 2.5 }} connectNulls />
              <ReferenceLine x={lastActual.month} stroke={COLORS.slate}
                strokeDasharray="3 3"
                label={{ value: 'today', fontSize: 11, fill: COLORS.slate, position: 'top' }} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <h3>Forecast table</h3>
          <span className="hint">{data.horizon} · values in USD/tonne</span>
        </div>
        <div className="card-body" style={{ overflowX: 'auto' }}>
          <table>
            <thead>
              <tr>
                <th>Month</th><th>Forecast</th><th>Lower (80%)</th>
                <th>Upper (80%)</th><th>vs. latest actual</th>
              </tr>
            </thead>
            <tbody>
              {fcst.map((r) => {
                const d = ((r.mean - lastActual.actual) / lastActual.actual) * 100
                return (
                  <tr key={r.month}>
                    <td className="mono">{r.month}</td>
                    <td className="mono" style={{ fontWeight: 600 }}>{usd(r.mean)}</td>
                    <td className="mono">{usd(r.band[0])}</td>
                    <td className="mono">{usd(r.band[1])}</td>
                    <td>
                      <span className={`delta ${d > 0 ? 'up' : d < 0 ? 'down' : 'flat'}`}>
                        {d > 0 ? '▲' : d < 0 ? '▼' : '—'} {Math.abs(d).toFixed(1)}%
                      </span>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
