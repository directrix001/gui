import { useRef, useState } from 'react'
import { api } from '../api/client.js'
import { COLORS } from '../components/ui.jsx'

const EXPECTED = [
  ['month', 'YYYY-MM', 'One row per month, no gaps'],
  ['lme_usd_t', 'number', 'LME Aluminum base price'],
  ['midwest_premium_usd_t', 'number', 'US Midwest duty-paid premium'],
  ['gas_coeff', 'number', 'Adds to price — energy pass-through'],
  ['labour_index', 'number', 'Adds to price — labour cost'],
  ['macro_supply_demand', 'number', 'Subtracts — supply − demand balance'],
  ['external_factor', 'number', 'Adds to price — tariffs, freight, geopolitics'],
]

export default function DataManager() {
  const [drag, setDrag] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const [busy, setBusy] = useState(false)
  const inputRef = useRef()

  async function handleFile(file) {
    if (!file) return
    setBusy(true); setError(null); setResult(null)
    try { setResult(await api.upload(file)) }
    catch (e) { setError(e.message) }
    finally { setBusy(false) }
  }

  return (
    <div className="page">
      <div className="grid-2">
        <div className="card" style={{ padding: 20 }}>
          <div
            className={`dropzone${drag ? ' drag' : ''}`}
            onDragOver={(e) => { e.preventDefault(); setDrag(true) }}
            onDragLeave={() => setDrag(false)}
            onDrop={(e) => { e.preventDefault(); setDrag(false); handleFile(e.dataTransfer.files[0]) }}
          >
            <h4>{busy ? 'Parsing file…' : 'Drop your Excel or CSV here'}</h4>
            <p style={{ marginBottom: 16 }}>
              The mock series stay in place until real data replaces them.
            </p>
            <button className="btn" onClick={() => inputRef.current.click()} disabled={busy}>
              Choose file
            </button>
            <input ref={inputRef} type="file" accept=".csv,.xlsx,.xls" hidden
              onChange={(e) => handleFile(e.target.files[0])} />
          </div>

          {result && (
            <div style={{ marginTop: 16, padding: 16, background: '#e7f8f5', borderRadius: 12, fontSize: 13 }}>
              <strong>{result.filename}</strong> parsed — {result.rows} rows.
              <div style={{ marginTop: 6, color: COLORS.slate }}>
                Columns found: <span className="mono">{result.columns.join(', ')}</span>
              </div>
            </div>
          )}
          {error && (
            <div style={{ marginTop: 16, padding: 16, background: 'var(--gp-coral-soft)', borderRadius: 12, fontSize: 13, color: 'var(--gp-coral-dark)' }}>
              {error}
            </div>
          )}
        </div>

        <div className="card">
          <div className="card-head"><h3>Expected columns</h3></div>
          <div className="card-body" style={{ overflowX: 'auto' }}>
            <table>
              <thead><tr><th>Column</th><th>Type</th><th>Notes</th></tr></thead>
              <tbody>
                {EXPECTED.map(([c, t, n]) => (
                  <tr key={c}>
                    <td className="mono" style={{ fontWeight: 600 }}>{c}</td>
                    <td className="mono">{t}</td>
                    <td style={{ color: COLORS.slate }}>{n}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p style={{ marginTop: 14, fontSize: 12.5, color: COLORS.slate, lineHeight: 1.55 }}>
              Column names are flexible — the upload response echoes what it found so the mapping
              can be confirmed before the pipeline switches from mock to real data.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
