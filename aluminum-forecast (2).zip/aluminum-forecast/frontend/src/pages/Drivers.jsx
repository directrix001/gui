import { useEffect, useState } from 'react'
import {
  ResponsiveContainer, ComposedChart, Area, Line, XAxis, YAxis,
  CartesianGrid, Tooltip,
} from 'recharts'
import { api } from '../api/client.js'
import { COLORS, Loading, ErrorBox, tooltipStyle } from '../components/ui.jsx'

function DriverCard({ d }) {
  const merged = [
    ...d.history.labels.map((m, i) => ({ month: m, actual: d.history.values[i] })),
    ...d.forecast.labels.map((m, i) => ({
      month: m, mean: d.forecast.mean[i],
      band: [d.forecast.lower_80[i], d.forecast.upper_80[i]],
    })),
  ]
  const up = d.yoy_pct >= 0
  return (
    <div className="card">
      <div className="card-head">
        <h3>{d.name}</h3>
        <div style={{ display: 'flex', gap: 8 }}>
          <span className={`badge ${d.effect === '+' ? 'info' : 'warn'}`}>
            {d.effect === '+' ? 'adds to price' : 'reduces price'}
          </span>
          <span className={`badge ${up ? 'ok' : 'err'}`}>
            {up ? '▲' : '▼'} {Math.abs(d.yoy_pct).toFixed(1)}% YoY
          </span>
        </div>
      </div>
      <div className="card-body">
        <div style={{ display: 'flex', gap: 20, alignItems: 'baseline', marginBottom: 8 }}>
          <span style={{
            fontFamily: 'Space Grotesk, sans-serif', fontSize: 24, fontWeight: 700,
          }}>{d.latest.toLocaleString('en-US')}</span>
          <span style={{ fontSize: 12, color: COLORS.slate }}>{d.desc}</span>
        </div>
        <div style={{ height: 190 }}>
          <ResponsiveContainer>
            <ComposedChart data={merged}>
              <CartesianGrid stroke={COLORS.grid} vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 10 }} minTickGap={40} />
              <YAxis tick={{ fontSize: 10 }} width={54} domain={['auto', 'auto']} />
              <Tooltip {...tooltipStyle}
                formatter={(v, name) =>
                  Array.isArray(v)
                    ? [`${v[0].toLocaleString()} – ${v[1].toLocaleString()}`, '80% band']
                    : [Number(v).toLocaleString(), name === 'actual' ? 'Actual' : 'Forecast']} />
              <Area dataKey="band" fill={COLORS.band} stroke="none" connectNulls />
              <Line dataKey="actual" stroke={COLORS.navy} strokeWidth={1.8} dot={false} />
              <Line dataKey="mean" stroke={COLORS.coral} strokeWidth={1.8}
                strokeDasharray="5 4" dot={false} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  )
}

export default function Drivers() {
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)

  useEffect(() => { api.drivers().then(setData).catch(setError) }, [])

  if (error) return <div className="page"><ErrorBox error={error} /></div>
  if (!data) return <div className="page"><Loading label="Loading drivers…" /></div>

  return (
    <div className="page">
      <div className="card" style={{ padding: '16px 20px' }}>
        <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontWeight: 600, marginBottom: 6 }}>
          All-in Aluminum Cost = LME + Midwest Premium + Gas Coefficient + Labour Index
          − Macro Factor (Supply − Demand) + External Factor
        </div>
        <span style={{ color: COLORS.slate }}>
          Only these components move the aluminum price. Each input below has historical data
          only — the pipeline first forecasts it 12 months out (dashed coral), then feeds those
          paths into the price model to predict the target column.
        </span>
      </div>
      <div className="grid-2e">
        {data.drivers.map(d => <DriverCard key={d.key} d={d} />)}
      </div>
    </div>
  )
}
