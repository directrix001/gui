import { useEffect, useState } from 'react'
import { api } from '../api/client.js'
import { COLORS, Loading, ErrorBox } from '../components/ui.jsx'

const STATUS = {
  linked: { cls: 'ok', label: 'Linked' },
  pending_validation: { cls: 'warn', label: 'Pending validation' },
  failed: { cls: 'err', label: 'Failed' },
  pass: { cls: 'ok', label: 'Pass' },
  warning: { cls: 'warn', label: 'Warning' },
  fail: { cls: 'err', label: 'Fail' },
}

export default function Validation() {
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)

  useEffect(() => { api.validation().then(setData).catch(setError) }, [])

  if (error) return <div className="page"><ErrorBox error={error} /></div>
  if (!data) return <div className="page"><Loading label="Checking sources…" /></div>

  return (
    <div className="page">
      <div className="card">
        <div className="card-head">
          <h3>Source links</h3>
          <span className="hint">Last checked {data.last_checked} · shared links from the kickoff</span>
        </div>
        <div className="card-body" style={{ overflowX: 'auto' }}>
          <table>
            <thead>
              <tr><th>Source</th><th>Feeds</th><th>URL</th><th>Status</th><th>Latency</th></tr>
            </thead>
            <tbody>
              {data.sources.map(s => (
                <tr key={s.name}>
                  <td style={{ fontWeight: 600 }}>{s.name}</td>
                  <td>{s.field}</td>
                  <td className="mono" style={{ color: COLORS.slate, maxWidth: 280, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{s.url}</td>
                  <td><span className={`badge ${STATUS[s.status].cls}`}>{STATUS[s.status].label}</span></td>
                  <td className="mono">{s.latency_ms != null ? `${s.latency_ms} ms` : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <h3>Validation rules</h3>
          <span className="hint">Automated checks run on every refresh</span>
        </div>
        <div className="card-body" style={{ overflowX: 'auto' }}>
          <table>
            <thead><tr><th>Rule</th><th>Status</th><th>Detail</th></tr></thead>
            <tbody>
              {data.rules.map(r => (
                <tr key={r.rule}>
                  <td style={{ fontWeight: 500 }}>{r.rule}</td>
                  <td><span className={`badge ${STATUS[r.status].cls}`}>{STATUS[r.status].label}</span></td>
                  <td style={{ color: COLORS.slate }}>{r.detail || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
