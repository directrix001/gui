import { useEffect, useState } from 'react'
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
} from 'recharts'
import { api } from '../api/client.js'
import { COLORS, Loading, ErrorBox, usd, tooltipStyle } from '../components/ui.jsx'

export default function ModelPerformance() {
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)

  useEffect(() => { api.modelMetrics().then(setData).catch(setError) }, [])

  if (error) return <div className="page"><ErrorBox error={error} /></div>
  if (!data) return <div className="page"><Loading label="Scoring models…" /></div>

  const bt = data.backtest.labels.map((m, i) => ({
    month: m, Actual: data.backtest.actual[i], Predicted: data.backtest.predicted[i],
  }))
  const m = data.metrics

  const KPIS = [
    ['MAPE', `${m.mape_pct}%`, 'Mean absolute % error'],
    ['RMSE', usd(m.rmse_usd), 'Root mean squared error'],
    ['MAE', usd(m.mae_usd), 'Mean absolute error'],
    ['R²', m.r2.toFixed(2), 'Variance explained'],
    ['Band coverage', `${m.coverage_80_pct}%`, 'Actuals inside 80% band'],
  ]

  return (
    <div className="page">
      <div className="grid-kpi">
        {KPIS.map(([label, value, sub]) => (
          <div className="card kpi" key={label}>
            <div className="label">{label}</div>
            <div className="value">{value}</div>
            <div className="delta flat">{sub}</div>
          </div>
        ))}
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="card-head">
            <h3>Backtest — last 12 months</h3>
            <span className="hint">{data.model} · all-in price, USD/t</span>
          </div>
          <div className="card-body" style={{ height: 330 }}>
            <ResponsiveContainer>
              <LineChart data={bt}>
                <CartesianGrid stroke={COLORS.grid} vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} minTickGap={26} />
                <YAxis tick={{ fontSize: 11 }} tickFormatter={usd} width={64}
                  domain={['auto', 'auto']} />
                <Tooltip {...tooltipStyle} formatter={(v) => usd(v)} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Line dataKey="Actual" stroke={COLORS.navy} strokeWidth={2.2} dot={false} />
                <Line dataKey="Predicted" stroke={COLORS.coral} strokeWidth={2.2}
                  strokeDasharray="6 4" dot={{ r: 2.5 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card">
          <div className="card-head"><h3>Model leaderboard</h3></div>
          <div className="card-body" style={{ overflowX: 'auto' }}>
            <table>
              <thead><tr><th>Model</th><th>MAPE</th><th>Status</th></tr></thead>
              <tbody>
                {data.candidates.map(c => (
                  <tr key={c.name}>
                    <td style={{ fontWeight: 500 }}>{c.name}</td>
                    <td className="mono">{c.mape_pct}%</td>
                    <td>
                      <span className={`badge ${
                        c.status === 'champion' ? 'ok' : c.status === 'baseline' ? 'info' : 'warn'
                      }`}>{c.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p style={{ marginTop: 14, fontSize: 12.5, color: COLORS.slate, lineHeight: 1.55 }}>
              The champion is re-evaluated each month against challengers. With only 4–5 quarters
              of clean driver history, expect wider bands early on — accuracy improves as more
              monthly data lands.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
