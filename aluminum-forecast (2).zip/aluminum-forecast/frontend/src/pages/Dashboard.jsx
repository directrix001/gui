import { useEffect, useState } from 'react'
import {
  ResponsiveContainer, ComposedChart, Area, Line, XAxis, YAxis,
  CartesianGrid, Tooltip, Legend,
} from 'recharts'
import { api } from '../api/client.js'
import { COLORS, Loading, ErrorBox, Delta, usd, tooltipStyle } from '../components/ui.jsx'

export default function Dashboard() {
  const [state, setState] = useState({ loading: true })
  const [months, setMonths] = useState(24)
  const [history, setHistory] = useState(null)

  useEffect(() => {
    Promise.all([api.summary(), api.importance()])
      .then(([summary, imp]) => setState({ loading: false, summary, imp }))
      .catch((error) => setState({ loading: false, error }))
  }, [])

  useEffect(() => {
    api.history(months).then(setHistory).catch(() => {})
  }, [months])

  if (state.loading) return <div className="page"><Loading /></div>
  if (state.error) return <div className="page"><ErrorBox error={state.error} /></div>

  const { summary, imp } = state
  const chartData = history
    ? history.labels.map((m, i) => ({
        month: m, LME: history.lme[i],
        'Midwest Premium': history.midwest_premium[i],
        'All-in': history.all_in[i],
      }))
    : []

  return (
    <div className="page">
      {/* Signature: the full pricing formula */}
      <section className="equation" aria-label="Aluminum pricing formula">
        <div className="eq-term">
          <span className="t-label">LME Base</span>
          <span className="t-value" style={{ fontSize: 24 }}>{usd(summary.lme.value)}</span>
        </div>
        <span className="eq-op">+</span>
        <div className="eq-term">
          <span className="t-label">Midwest Premium</span>
          <span className="t-value" style={{ fontSize: 24 }}>{usd(summary.midwest_premium.value)}</span>
        </div>
        <span className="eq-op">+</span>
        <div className="eq-term">
          <span className="t-label">Gas Coeff.</span>
          <span className="t-value" style={{ fontSize: 24 }}>{usd(summary.gas_coeff.value)}</span>
        </div>
        <span className="eq-op">+</span>
        <div className="eq-term">
          <span className="t-label">Labour Index</span>
          <span className="t-value" style={{ fontSize: 24 }}>{usd(summary.labour_index.value)}</span>
        </div>
        <span className="eq-op">−</span>
        <div className="eq-term">
          <span className="t-label">Macro (S−D)</span>
          <span className="t-value" style={{ fontSize: 24 }}>{usd(summary.macro_sd.value)}</span>
        </div>
        <span className="eq-op">+</span>
        <div className="eq-term">
          <span className="t-label">External</span>
          <span className="t-value" style={{ fontSize: 24 }}>{usd(summary.external.value)}</span>
        </div>
        <span className="eq-op">=</span>
        <div className="eq-term eq-result">
          <span className="t-label">All-in Aluminum Price</span>
          <span className="t-value" style={{ fontSize: 30 }}>{usd(summary.all_in.value)}</span>
          <span className="t-sub">As of {summary.as_of}</span>
        </div>
        <div className="eq-note">
          All-in cost = LME base + US Midwest Premium + gas coefficient + labour index − macro-economic
          factor (supply − demand) + external factor. Only these components move the aluminum price
          on this platform.
        </div>
      </section>

      <div className="grid-kpi">
        <div className="card kpi">
          <div className="label">LME Aluminum</div>
          <div className="value">{usd(summary.lme.value)} <small>/t</small></div>
          <Delta value={summary.lme.mom_pct} />
        </div>
        <div className="card kpi">
          <div className="label">Midwest Premium</div>
          <div className="value">{usd(summary.midwest_premium.value)} <small>/t</small></div>
          <Delta value={summary.midwest_premium.mom_pct} />
        </div>
        <div className="card kpi">
          <div className="label">12-Month Forecast Avg</div>
          <div className="value">{usd(summary.forecast_12m_avg)} <small>/t</small></div>
          <div className="delta flat">All-in, next 12 months</div>
        </div>
        <div className="card kpi">
          <div className="label">Forecast Peak</div>
          <div className="value">{usd(summary.forecast_peak.value)} <small>/t</small></div>
          <div className="delta flat">Expected {summary.forecast_peak.month}</div>
        </div>
        <div className="card kpi">
          <div className="label">Model Accuracy</div>
          <div className="value">{summary.model.mape_pct}% <small>MAPE</small></div>
          <div className="delta up">▲ {summary.model.name}</div>
        </div>
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="card-head">
            <h3>Price History — components and all-in</h3>
            <div className="seg" role="tablist" aria-label="History range">
              {[12, 24, 36].map(m => (
                <button key={m} className={months === m ? 'active' : ''}
                  onClick={() => setMonths(m)}>{m}M</button>
              ))}
            </div>
          </div>
          <div className="card-body" style={{ height: 340 }}>
            <ResponsiveContainer>
              <ComposedChart data={chartData}>
                <CartesianGrid stroke={COLORS.grid} vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} minTickGap={28} />
                <YAxis tick={{ fontSize: 11 }} tickFormatter={usd} width={64} />
                <Tooltip {...tooltipStyle} formatter={(v) => usd(v)} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Area dataKey="LME" fill="rgba(4,28,44,0.08)" stroke={COLORS.navy} strokeWidth={1.6} />
                <Line dataKey="Midwest Premium" stroke={COLORS.blue} strokeWidth={1.6} dot={false} />
                <Line dataKey="All-in" stroke={COLORS.coral} strokeWidth={2.4} dot={false} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <h3>What moves the price</h3>
            <span className="hint">{imp.model}</span>
          </div>
          <div className="card-body">
            {imp.importance.map((f) => (
              <div className="imp-row" key={f.feature}>
                <span className="f">{f.feature}</span>
                <div className="imp-bar"><span style={{ width: `${f.weight * 100 * 2.6}%` }} /></div>
                <span className="w">{(f.weight * 100).toFixed(0)}%</span>
              </div>
            ))}
            <p style={{ marginTop: 14, fontSize: 12.5, color: COLORS.slate, lineHeight: 1.55 }}>
              Feature weights from the champion model. Each driver is forecast for the next 12
              months first, then the target price column is predicted from those forecasts —
              exactly the two-step approach agreed in the kickoff.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
