import { useEffect, useRef, useState } from 'react'

const HELLO = {
  role: 'assistant',
  content: "Hi! I'm the platform assistant. Ask me anything — the pricing formula, the current price, how the 12-month forecast works, what the 80% bands mean, drivers, model accuracy, or general questions.",
}

export default function ChatWidget() {
  const [open, setOpen] = useState(false)
  const [mode, setMode] = useState(null)
  const [messages, setMessages] = useState([HELLO])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const bodyRef = useRef(null)

  useEffect(() => {
    fetch('/api/chat/status').then(r => r.json())
      .then(d => setMode(d.mode))
      .catch(() => setMode('basic'))
  }, [])

  useEffect(() => {
    if (bodyRef.current) bodyRef.current.scrollTop = bodyRef.current.scrollHeight
  }, [messages, open, busy])

  async function send() {
    const text = input.trim()
    if (!text || busy) return
    const next = [...messages, { role: 'user', content: text }]
    setMessages(next)
    setInput('')
    setBusy(true)
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: next.filter(m => m !== HELLO).map(({ role, content }) => ({ role, content })),
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.detail || 'Request failed')
      setMessages(m => [...m, { role: 'assistant', content: data.reply }])
    } catch (e) {
      setMessages(m => [...m, { role: 'assistant', content: `⚠️ ${e.message}`, error: true }])
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
      <button
        className="chat-fab"
        aria-label={open ? 'Close assistant' : 'Open assistant'}
        onClick={() => setOpen(o => !o)}
      >
        {open ? (
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2"
            strokeLinecap="round"><path d="M6 6l12 12M18 6L6 18" /></svg>
        ) : (
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9"
            strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 12a8 8 0 01-8 8H5l-2 2V12a8 8 0 018-8h2a8 8 0 018 8z" />
          </svg>
        )}
      </button>

      {open && (
        <div className="chat-panel" role="dialog" aria-label="Platform assistant">
          <div className="chat-head">
            <div>
              <div className="chat-title">Platform Assistant</div>
              <div className="chat-sub">
                {mode === null ? 'Checking connection…'
                  : mode === 'azure' ? 'Azure OpenAI · connected'
                  : 'Basic mode · platform Q&A (no key needed)'}
              </div>
            </div>
            <span className={`chat-dot ${mode === 'azure' ? 'on' : 'off'}`} />
          </div>

          {mode === 'basic' && (
            <div className="chat-notice">
              Running in basic mode — I can answer platform questions from live data. Add your
              Azure OpenAI key to <span className="mono">backend/.env</span> for full AI answers.
            </div>
          )}

          <div className="chat-body" ref={bodyRef}>
            {messages.map((m, i) => (
              <div key={i} className={`chat-msg ${m.role}${m.error ? ' err' : ''}`}>
                {m.content}
              </div>
            ))}
            {busy && (
              <div className="chat-msg assistant typing">
                <span /><span /><span />
              </div>
            )}
          </div>

          <div className="chat-input">
            <textarea
              rows={1}
              placeholder="Ask a question…"
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() }
              }}
            />
            <button className="btn" onClick={send} disabled={busy || !input.trim()}>
              Send
            </button>
          </div>
        </div>
      )}
    </>
  )
}
