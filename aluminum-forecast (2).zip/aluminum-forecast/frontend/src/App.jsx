import { NavLink, Link, Routes, Route, useLocation } from 'react-router-dom'
import Landing from './pages/Landing.jsx'
import Dashboard from './pages/Dashboard.jsx'
import Forecast from './pages/Forecast.jsx'
import Drivers from './pages/Drivers.jsx'
import Validation from './pages/Validation.jsx'
import ModelPerformance from './pages/ModelPerformance.jsx'
import DataManager from './pages/DataManager.jsx'
import ChatWidget from './components/ChatWidget.jsx'

const NAV = [
  { to: '/', label: 'Home', end: true },
  { to: '/dashboard', label: 'Dashboard' },
  { to: '/forecast', label: 'Forecast' },
  { to: '/drivers', label: 'Drivers' },
  { to: '/validation', label: 'Validation' },
  { to: '/model', label: 'Model' },
  { to: '/data', label: 'Data' },
]

const TITLES = {
  '/dashboard': ['Dashboard', 'Aluminum all-in price — six components, one number'],
  '/forecast': ['12-Month Forecast', 'Monthly ML forecast with 80% confidence bands'],
  '/drivers': ['Input Drivers', 'Historical inputs, each forecast before predicting the target'],
  '/validation': ['Data Validation', 'Source links and automated rule checks'],
  '/model': ['Model Performance', 'Backtest, error metrics and challenger models'],
  '/data': ['Data Manager', 'Upload real data to replace mock series'],
}

function Brand({ light }) {
  return (
    <Link to="/" className="brand-inline" aria-label="Home">
      <span className="brand-mark" style={light ? { color: '#fff' } : undefined}>
        genpact<span className="dot">•</span>
      </span>
      <span className="brand-tag">Aluminum Price Intelligence</span>
    </Link>
  )
}

export default function App() {
  const { pathname } = useLocation()
  const meta = TITLES[pathname]

  return (
    <div className="site">
      <header className="site-header">
        <Brand light />
        <nav className="site-nav" aria-label="Main">
          {NAV.map(n => (
            <NavLink key={n.to} to={n.to} end={n.end}
              className={({ isActive }) => `site-link${isActive ? ' active' : ''}`}>
              {n.label}
            </NavLink>
          ))}
        </nav>
        <Link to="/forecast" className="btn header-cta">View Forecast</Link>
      </header>

      {meta && (
        <div className="page-head">
          <div className="page-head-inner">
            <h1>{meta[0]}</h1>
            <span>{meta[1]}</span>
          </div>
        </div>
      )}

      <main className="site-main">
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/forecast" element={<Forecast />} />
          <Route path="/drivers" element={<Drivers />} />
          <Route path="/validation" element={<Validation />} />
          <Route path="/model" element={<ModelPerformance />} />
          <Route path="/data" element={<DataManager />} />
          <Route path="*" element={<Landing />} />
        </Routes>
      </main>

      <footer className="site-footer">
        <div className="foot-inner">
          <div className="foot-col foot-brand">
            <div className="brand-mark" style={{ color: '#fff' }}>
              genpact<span className="dot">•</span>
            </div>
            <p>
              Aluminum Price Intelligence — a Metals Analytics platform forecasting the
              all-in US aluminum purchase price 12 months ahead, monthly.
            </p>
            <p className="foot-tag">Transformation happens here.</p>
          </div>
          <div className="foot-col">
            <h4>Platform</h4>
            <Link to="/dashboard">Dashboard</Link>
            <Link to="/forecast">12-Month Forecast</Link>
            <Link to="/drivers">Input Drivers</Link>
            <Link to="/model">Model Performance</Link>
          </div>
          <div className="foot-col">
            <h4>Data</h4>
            <Link to="/validation">Data Validation</Link>
            <Link to="/data">Data Manager</Link>
            <a href="/docs" target="_blank" rel="noreferrer">API Docs</a>
          </div>
          <div className="foot-col">
            <h4>Pricing Formula</h4>
            <p className="foot-formula">
              All-in = LME + Midwest Premium + Gas Coefficient + Labour Index
              − Macro (Supply−Demand) + External Factor
            </p>
          </div>
        </div>
        <div className="foot-bar">
          <span>© {new Date().getFullYear()} Genpact · Metals Analytics engagement · Demo data</span>
          <span>Assistant available bottom-right — works with or without an Azure OpenAI key</span>
        </div>
      </footer>

      <ChatWidget />
    </div>
  )
}
