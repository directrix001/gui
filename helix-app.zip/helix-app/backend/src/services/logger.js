const fs = require("fs");
const path = require("path");
const XLSX = require("xlsx");
const { state, findEmployee, wdGet, cols } = require("./data");

let logFile = null;

function currentLogFile() {
  if (!logFile) {
    const stamp = new Date()
      .toISOString()
      .replace(/[-:T]/g, "")
      .slice(0, 14)
      .replace(/^(\d{8})(\d{6}).*/, "$1_$2");
    logFile = path.join(state.paths.logFolder, `generation_log_${stamp}.xlsx`);
  }
  return logFile;
}

function createLog({ outputFile, empId, managerName, generationMode, hroRow, passwordProtected }) {
  try {
    const employeeRow = findEmployee(empId) || {};
    const now = new Date();
    const p = (n) => String(n).padStart(2, "0");
    const record = {
      Timestamp: `${p(now.getDate())}-${p(now.getMonth() + 1)}-${now.getFullYear()} ${p(now.getHours())}:${p(now.getMinutes())}:${p(now.getSeconds())}`,
      "User ID": state.userId,
      "Generation Mode": generationMode,
      "Output Type": String(outputFile).toLowerCase().endsWith(".pdf") ? "PDF" : "Word",
      "Password Protected": passwordProtected ? "Yes" : "No",
      Forename: wdGet(employeeRow, "Forename") ?? "",
      Surname: wdGet(employeeRow, "Surname") ?? "",
      "Employee ID": empId,
      "Manager Name": managerName || "",
      "Email ID": wdGet(employeeRow, "Email ID") ?? "",
      Region: hroRow[cols.REGION_COL] ?? "",
      Entity: hroRow[cols.ENTITY_COL] ?? "",
      "Letter Category": hroRow[cols.CATEGORY_COL] ?? "",
      "Original Letter Name": hroRow[cols.LETTER_COL] ?? "",
      "Unique Letter Template Name": hroRow[cols.UNIQUE_TEMPLATE_COL] ?? "",
      "Generated File Name": path.basename(String(outputFile)),
    };

    const file = currentLogFile();
    let rows = [];
    if (fs.existsSync(file)) {
      const wb = XLSX.readFile(file);
      rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { defval: "" });
    }
    rows.push(record);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows), "Log");
    XLSX.writeFile(wb, file);
  } catch (e) {
    console.error("Log error:", e.message);
  }
}

module.exports = { createLog };
