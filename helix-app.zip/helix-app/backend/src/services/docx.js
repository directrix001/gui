const fs = require("fs");
const JSZip = require("jszip");
const sizeOf = require("image-size");
const { normalize } = require("./data");

const esc = (s) =>
  String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");

const unesc = (s) =>
  String(s)
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, "&");

const escRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

// Get the concatenated visible text of an XML fragment
function fragmentText(xml) {
  let out = "";
  const re = /<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>/g;
  let m;
  while ((m = re.exec(xml))) out += unesc(m[1]);
  return out;
}

// Replace all <w:t> contents in a fragment: first one gets `newText`, rest emptied
function setFragmentText(xml, newText) {
  let first = true;
  return xml.replace(/(<w:t)(\s[^>]*)?>([\s\S]*?)(<\/w:t>)/g, (all, open, attrs) => {
    const a = attrs && attrs.includes("xml:space") ? attrs : `${attrs || ""} xml:space="preserve"`;
    if (first) {
      first = false;
      return `${open}${a}>${esc(newText)}</w:t>`;
    }
    return `${open}${a}></w:t>`;
  });
}

function applyReplacementsToText(text, fieldValues) {
  let updated = text;
  for (const [field, value] of Object.entries(fieldValues)) {
    if (!field) continue;
    const v = value ?? "";
    // 1) {{ Field }} placeholders (case-insensitive)
    updated = updated.replace(new RegExp(`\\{\\{\\s*${escRe(field)}\\s*\\}\\}`, "gi"), v);
    // 2) plain field names (case-insensitive) — same behaviour as the original tool
    updated = updated.replace(new RegExp(escRe(field), "gi"), v);
  }
  return updated;
}

// Replace placeholders in every paragraph (covers body + table cell paragraphs)
function replaceInParagraphs(documentXml, fieldValues) {
  return documentXml.replace(/<w:p\b[\s\S]*?<\/w:p>/g, (para) => {
    const text = fragmentText(para);
    if (!text) return para;
    const updated = applyReplacementsToText(text, fieldValues);
    if (updated === text) return para;
    return setFragmentText(para, updated);
  });
}

// Table convention: left cell contains the field label, right cell receives the value
function replaceInTables(documentXml, fieldValues) {
  const entries = Object.entries(fieldValues).map(([k, v]) => [normalize(k), v ?? ""]);
  return documentXml.replace(/<w:tr\b[\s\S]*?<\/w:tr>/g, (row) => {
    const cells = row.match(/<w:tc\b[\s\S]*?<\/w:tc>/g);
    if (!cells || cells.length < 2) return row;
    const leftText = normalize(fragmentText(cells[0]).trim());
    const hit = entries.find(([k]) => k === leftText);
    if (!hit) return row;
    const newRight = /<w:t/.test(cells[1])
      ? setFragmentText(cells[1], hit[1])
      : cells[1].replace(/<\/w:p>/, `<w:r><w:t xml:space="preserve">${esc(hit[1])}</w:t></w:r></w:p>`);
    return row.replace(cells[1], newRight);
  });
}

// Insert (or clear) the signatory paragraph
async function insertSignatory(zip, documentXml, imagePath) {
  const paras = documentXml.match(/<w:p\b[\s\S]*?<\/w:p>/g) || [];
  const target = paras.find((p) => fragmentText(p).toLowerCase().includes("signatory"));
  if (!target) return documentXml;

  if (!imagePath || !fs.existsSync(imagePath)) {
    // No image: just remove the placeholder text
    return documentXml.replace(target, setFragmentText(target, ""));
  }

  const img = fs.readFileSync(imagePath);
  const dim = sizeOf(img);
  const ext = (dim.type === "jpg" ? "jpeg" : dim.type) || "png";
  const mediaName = `helix_signatory.${ext === "jpeg" ? "jpg" : ext}`;
  zip.file(`word/media/${mediaName}`, img);

  // Content types
  let ct = await zip.file("[Content_Types].xml").async("string");
  const need = ext === "jpeg" ? ["jpg", "image/jpeg"] : ["png", "image/png"];
  if (!ct.includes(`Extension="${need[0]}"`)) {
    ct = ct.replace("</Types>", `<Default Extension="${need[0]}" ContentType="${need[1]}"/></Types>`);
    zip.file("[Content_Types].xml", ct);
  }

  // Relationship
  const relsPath = "word/_rels/document.xml.rels";
  let rels = await zip.file(relsPath).async("string");
  const rid = "rIdHelixSig1";
  if (!rels.includes(rid)) {
    rels = rels.replace(
      "</Relationships>",
      `<Relationship Id="${rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/${mediaName}"/></Relationships>`
    );
    zip.file(relsPath, rels);
  }

  // 1.8 inch wide, height keeps aspect ratio (matches Inches(1.8) in the original)
  const cx = 1645920;
  const cy = Math.round(cx * (dim.height / dim.width));
  const drawing =
    `<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0" ` +
    `xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing">` +
    `<wp:extent cx="${cx}" cy="${cy}"/><wp:docPr id="9901" name="Signatory"/>` +
    `<a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">` +
    `<a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">` +
    `<pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">` +
    `<pic:nvPicPr><pic:cNvPr id="9901" name="Signatory"/><pic:cNvPicPr/></pic:nvPicPr>` +
    `<pic:blipFill><a:blip xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:embed="${rid}"/>` +
    `<a:stretch><a:fillRect/></a:stretch></pic:blipFill>` +
    `<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm>` +
    `<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>` +
    `</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>`;

  // Replace the paragraph's runs with the drawing run, keep paragraph properties
  const pPr = (target.match(/<w:pPr\b[\s\S]*?<\/w:pPr>/) || [""])[0];
  const openTag = (target.match(/^<w:p\b[^>]*>/) || ["<w:p>"])[0];
  const newPara = `${openTag}${pPr}${drawing}</w:p>`;
  return documentXml.replace(target, newPara);
}

/**
 * Render a template: replacements + tables + signatory. Returns a docx Buffer.
 */
async function renderDocx(templatePath, fieldValues, signatoryImagePath) {
  const zip = await JSZip.loadAsync(fs.readFileSync(templatePath));
  let xml = await zip.file("word/document.xml").async("string");
  xml = replaceInParagraphs(xml, fieldValues);
  xml = replaceInTables(xml, fieldValues);
  xml = await insertSignatory(zip, xml, signatoryImagePath);
  zip.file("word/document.xml", xml);
  return zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE" });
}

module.exports = { renderDocx };
