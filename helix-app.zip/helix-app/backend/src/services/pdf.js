const fs = require("fs");
const path = require("path");
const os = require("os");
const libre = require("libreoffice-convert");
const muhammara = require("muhammara");

if (process.env.LIBREOFFICE_PATH && process.env.LIBREOFFICE_PATH.trim()) {
  process.env.SOFFICE_BIN = process.env.LIBREOFFICE_PATH.trim();
}

function convertToPdf(docxBuffer) {
  return new Promise((resolve, reject) => {
    libre.convert(docxBuffer, ".pdf", undefined, (err, out) => {
      if (err) {
        reject(
          new Error(
            "Word → PDF conversion failed. Make sure LibreOffice is installed and " +
              "'soffice' is on your PATH (or set LIBREOFFICE_PATH in backend/.env). " +
              `Details: ${err.message}`
          )
        );
      } else resolve(out);
    });
  });
}

function encryptPdf(pdfBuffer, password) {
  if (!password) return pdfBuffer;
  const tmpIn = path.join(os.tmpdir(), `helix_${Date.now()}_${Math.random().toString(36).slice(2)}.pdf`);
  const tmpOut = tmpIn.replace(".pdf", "_enc.pdf");
  fs.writeFileSync(tmpIn, pdfBuffer);
  try {
    muhammara.recrypt(tmpIn, tmpOut, {
      userPassword: String(password),
      ownerPassword: String(password),
      userProtectionFlag: 4,
    });
    return fs.readFileSync(tmpOut);
  } finally {
    for (const f of [tmpIn, tmpOut]) {
      try { fs.unlinkSync(f); } catch (_) {}
    }
  }
}

async function docxToPdf(docxBuffer, password) {
  const pdf = await convertToPdf(docxBuffer);
  return encryptPdf(pdf, password);
}

module.exports = { docxToPdf };
