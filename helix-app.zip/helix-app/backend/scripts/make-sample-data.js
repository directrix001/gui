/**
 * Creates a sample HELIX data folder so you can try the app locally
 * without the Nissan OneDrive structure.
 *
 * Usage:  node scripts/make-sample-data.js [targetFolder]
 * Then set HELIX_ROOT in backend/.env to the printed path.
 */
const fs = require("fs");
const path = require("path");
const XLSX = require("xlsx");
const JSZip = require("jszip");

const root = path.resolve(process.argv[2] || path.join(__dirname, "..", "sample-data", "HELIX"));
const db = path.join(root, "Database");
const tpl = path.join(db, "Letter Template Docx");
fs.mkdirSync(tpl, { recursive: true });
fs.mkdirSync(path.join(root, "Output"), { recursive: true });
fs.mkdirSync(path.join(root, "Generation Logs"), { recursive: true });

// ---- All Templates Repository.xlsx (sheet: Letter Data) ----
const repoRows = [
  {
    Region: "AMIEO", Entity: "Nissan Digital India", Grouping: "Employment",
    "Original Letter Name": "Experience Letter",
    "Unique Letter Template Name": "NDI_Experience_Letter",
    Forename: "WORKDAY", Surname: "WORKDAY", "Employee ID": "WORKDAY",
    "Ms./Mr.": "WORKDAY", Designation: "MANUAL", "Date of Joining": "MANUAL",
    "Last Working Date": "MANUAL", "Letter Effective Date": "MANUAL",
    Signatory: "MANUAL",
  },
  {
    Region: "AMIEO", Entity: "Nissan Digital India", Grouping: "Compensation",
    "Original Letter Name": "Increment Letter",
    "Unique Letter Template Name": "NDI_Increment_Letter",
    Forename: "WORKDAY", Surname: "WORKDAY", "Employee ID": "WORKDAY",
    "Ms./Mr.": "WORKDAY", Designation: "MANUAL", "New Salary": "MANUAL",
    "Letter Effective Date": "MANUAL", Signatory: "MANUAL",
  },
];
const repoWb = XLSX.utils.book_new();
XLSX.utils.book_append_sheet(repoWb, XLSX.utils.json_to_sheet(repoRows), "Letter Data");
XLSX.writeFile(repoWb, path.join(db, "All Templates Repository.xlsx"));

// ---- Workday Input.xlsx ----
const wdRows = [
  { "Employee ID": "1001", Forename: "Aarav", Surname: "Sharma", Gender: "Male", " Date of Birth": new Date(1992, 4, 14), "Email ID": "aarav.sharma@example.com" },
  { "Employee ID": "1002", Forename: "Priya", Surname: "Nair", Gender: "Female", " Date of Birth": new Date(1995, 10, 2), "Email ID": "priya.nair@example.com" },
  { "Employee ID": "1003", Forename: "Rohan", Surname: "Verma", Gender: "Male", " Date of Birth": new Date(1990, 0, 25), "Email ID": "rohan.verma@example.com" },
];
const wdWb = XLSX.utils.book_new();
XLSX.utils.book_append_sheet(wdWb, XLSX.utils.json_to_sheet(wdRows, { cellDates: true }), "Sheet1");
XLSX.writeFile(wdWb, path.join(db, "Workday Input.xlsx"), { cellDates: true });

// ---- Minimal .docx templates ----
async function makeDocx(name, bodyParas) {
  const zip = new JSZip();
  zip.file("[Content_Types].xml",
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">` +
    `<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>` +
    `<Default Extension="xml" ContentType="application/xml"/>` +
    `<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>` +
    `</Types>`);
  zip.file("_rels/.rels",
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
    `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>` +
    `</Relationships>`);
  zip.file("word/_rels/document.xml.rels",
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"></Relationships>`);
  const paras = bodyParas
    .map((t) => `<w:p><w:r><w:t xml:space="preserve">${t}</w:t></w:r></w:p>`)
    .join("");
  zip.file("word/document.xml",
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">` +
    `<w:body>${paras}<w:sectPr/></w:body></w:document>`);
  const buf = await zip.generateAsync({ type: "nodebuffer" });
  fs.writeFileSync(path.join(tpl, `${name}.docx`), buf);
}

(async () => {
  await makeDocx("NDI_Experience_Letter", [
    "Date: {{Letter Effective Date}}",
    "",
    "TO WHOMSOEVER IT MAY CONCERN",
    "",
    "This is to certify that {{Ms./Mr.}} {{Forename}} {{Surname}} (ID: {{Employee ID}}) was employed with Nissan Digital India as {{Designation}} from {{Date of Joining}} to {{Last Working Date}}.",
    "",
    "We wish them success in their future endeavours.",
    "",
    "Signatory",
    "Human Resources, Nissan Motor Corporation",
  ]);
  await makeDocx("NDI_Increment_Letter", [
    "Date: {{Letter Effective Date}}",
    "",
    "Dear {{Ms./Mr.}} {{Forename}} {{Surname}},",
    "",
    "We are pleased to inform you that your revised annual salary as {{Designation}} will be {{New Salary}}, effective {{Letter Effective Date}}.",
    "",
    "Signatory",
    "Human Resources, Nissan Motor Corporation",
  ]);
  console.log("Sample data created at:\n  " + root);
  console.log("\nSet this in backend/.env:\n  HELIX_ROOT=" + root);
})();
