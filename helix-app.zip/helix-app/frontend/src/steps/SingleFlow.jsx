import React, { useState } from "react";
import { api } from "../api.js";

// ---------------------------------------------------- Employee + manager
export function EmployeeStep({ ctx, update, onBack, onNext }) {
  const [empId, setEmpId] = useState(ctx.empId);
  const [managerName, setManagerName] = useState(ctx.managerName);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const next = async () => {
    if (!empId.trim()) { setError("Please enter the Employee ID."); return; }
    if (!managerName.trim()) { setError("Please enter the Manager Name."); return; }
    setBusy(true); setError("");
    try {
      await api.employee(empId.trim()); // validates existence in Workday
      const pre = await api.singlePrefill(ctx.selection, empId.trim());
      update({
        empId: empId.trim(),
        managerName: managerName.trim(),
        fields: pre.fields,
        hasSignatory: pre.hasSignatory,
      });
      onNext();
    } catch (e) { setError(e.message); }
    finally { setBusy(false); }
  };

  return (
    <div className="card">
      <h2>Employee</h2>
      <p className="lede">Look up the employee in the Workday input file.</p>
      <div className="grid">
        <div className="field">
          <label>Employee ID</label>
          <input value={empId} autoFocus onChange={(e) => setEmpId(e.target.value)} />
        </div>
        <div className="field">
          <label>Manager name</label>
          <input value={managerName} onChange={(e) => setManagerName(e.target.value)} />
          <div className="hint">Used for the output folder structure</div>
        </div>
      </div>
      {error && <div className="alert error">{error}</div>}
      <div className="actions">
        <div className="left"><button className="btn ghost" onClick={onBack}>Back</button></div>
        <button className="btn primary" onClick={next} disabled={busy}>
          {busy ? "Checking…" : "Continue"}
        </button>
      </div>
    </div>
  );
}

// ---------------------------------------------------- Dynamic fields
export function FieldsStep({ ctx, update, onBack, onNext }) {
  const [values, setValues] = useState(() =>
    Object.fromEntries(ctx.fields.map((f) => [f.name, f.value ?? ""]))
  );
  const [signatoryFile, setSignatoryFile] = useState(ctx.signatoryFile);
  const [error, setError] = useState("");

  const setVal = (name, v) => setValues((s) => ({ ...s, [name]: v }));

  const next = () => {
    const missing = ctx.fields.filter((f) => !String(values[f.name] ?? "").trim());
    if (missing.length) {
      setError("Please fill all mandatory fields:\n" + missing.map((f) => f.name).join(", "));
      return;
    }
    const badDates = ctx.fields.filter((f) => {
      if (!f.name.toLowerCase().includes("date")) return false;
      return !/^\d{2}-\d{2}-\d{4}$/.test(String(values[f.name]).trim());
    });
    if (badDates.length) {
      setError("These date fields must be in DD-MM-YYYY format:\n" + badDates.map((f) => f.name).join(", "));
      return;
    }
    update({ fieldValues: values, signatoryFile });
    onNext();
  };

  return (
    <div className="card wide">
      <h2>Letter details</h2>
      <p className="lede">
        Workday fields are pre-filled. Fill the remaining fields — dates use DD-MM-YYYY.
      </p>
      <div className="grid cols-3">
        {ctx.fields.map((f) => (
          <div className="field" key={f.name}>
            <label>{f.name}{f.isDate ? " (DD-MM-YYYY)" : ""}</label>
            <input
              value={values[f.name] ?? ""}
              readOnly={f.readonly}
              onChange={(e) => setVal(f.name, e.target.value)}
            />
          </div>
        ))}
      </div>

      {ctx.hasSignatory && (
        <div style={{ marginTop: 26 }}>
          <div className="field">
            <label>Signatory image (PNG / JPG)</label>
            <input type="file" accept=".png,.jpg,.jpeg"
              onChange={(e) => setSignatoryFile(e.target.files[0] || null)} />
            <div className="hint">
              Optional — if no image is uploaded, the signatory placeholder is removed from the letter.
            </div>
            {signatoryFile && (
              <div className="file-pill"><span className="dot" />{signatoryFile.name}</div>
            )}
          </div>
        </div>
      )}

      {error && <div className="alert error">{error}</div>}
      <div className="actions">
        <div className="left"><button className="btn ghost" onClick={onBack}>Back</button></div>
        <button className="btn primary" onClick={next}>Continue</button>
      </div>
    </div>
  );
}

// ---------------------------------------------------- Output + generate
export function SingleOutputStep({ ctx, update, onBack, onDone }) {
  const [format, setFormat] = useState("pdf");
  const [passwordMode, setPasswordMode] = useState("system");
  const [customPassword, setCustomPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);

  const generate = async () => {
    if (format === "pdf" && passwordMode === "custom" && !customPassword.trim()) {
      setError("Please enter a custom password.");
      return;
    }
    setBusy(true); setError(""); setProgress(15);
    const tick = setInterval(() => setProgress((p) => Math.min(p + 7, 90)), 600);
    try {
      const res = await api.generateSingle(
        {
          selection: ctx.selection,
          empId: ctx.empId,
          managerName: ctx.managerName,
          fieldValues: ctx.fieldValues,
          isPdf: format === "pdf",
          passwordMode,
          customPassword,
        },
        ctx.signatoryFile
      );
      setProgress(100);
      onDone({ kind: "single", file: res.file });
    } catch (e) { setError(e.message); }
    finally { clearInterval(tick); setBusy(false); }
  };

  return (
    <div className="card">
      <h2>Output</h2>
      <p className="lede">Choose the file format and, for PDF, how the password is set.</p>

      <label className={"choice" + (format === "pdf" ? " selected" : "")}>
        <input type="radio" checked={format === "pdf"} onChange={() => setFormat("pdf")} />
        <div><b>PDF</b><span>Exact-layout PDF, protected with a password.</span></div>
      </label>
      <label className={"choice" + (format === "word" ? " selected" : "")}>
        <input type="radio" checked={format === "word"} onChange={() => setFormat("word")} />
        <div><b>Word (.docx)</b><span>Editable Word document, no password.</span></div>
      </label>

      {format === "pdf" && (
        <div style={{ marginTop: 20 }}>
          <label className={"choice" + (passwordMode === "system" ? " selected" : "")}>
            <input type="radio" checked={passwordMode === "system"}
              onChange={() => setPasswordMode("system")} />
            <div>
              <b>System-generated password</b>
              <span>First 4 letters of forename (uppercase) + birth year, from Workday.</span>
            </div>
          </label>
          <label className={"choice" + (passwordMode === "custom" ? " selected" : "")}>
            <input type="radio" checked={passwordMode === "custom"}
              onChange={() => setPasswordMode("custom")} />
            <div style={{ flex: 1 }}>
              <b>Custom password</b>
              {passwordMode === "custom" && (
                <div className="field" style={{ marginTop: 8, maxWidth: 280 }}>
                  <input type="password" value={customPassword}
                    onChange={(e) => setCustomPassword(e.target.value)}
                    placeholder="Enter password" />
                </div>
              )}
            </div>
          </label>
        </div>
      )}

      {busy && (
        <div className="progress-wrap">
          <div className="progress-track">
            <div className="progress-bar" style={{ width: `${progress}%` }} />
          </div>
          <div className="progress-label">
            <span>Generating letter — wait for confirmation…</span><span>{progress}%</span>
          </div>
        </div>
      )}
      {error && <div className="alert error">{error}</div>}

      <div className="actions">
        <div className="left">
          <button className="btn ghost" onClick={onBack} disabled={busy}>Back</button>
        </div>
        <button className="btn primary" onClick={generate} disabled={busy}>
          {busy ? "Generating…" : "Generate letter"}
        </button>
      </div>
    </div>
  );
}
