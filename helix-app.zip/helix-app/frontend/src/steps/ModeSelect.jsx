import React, { useState } from "react";

export default function ModeSelect({ ctx, update, onBack, onNext }) {
  const [mode, setMode] = useState(ctx.mode || "single");
  return (
    <div className="card">
      <h2>Generation mode</h2>
      <p className="lede">How do you want to generate letters?</p>

      <label className={"choice" + (mode === "single" ? " selected" : "")}>
        <input type="radio" name="mode" checked={mode === "single"}
          onChange={() => setMode("single")} />
        <div>
          <b>Single generation</b>
          <span>One employee — enter details on screen and generate one letter.</span>
        </div>
      </label>

      <label className={"choice" + (mode === "bulk" ? " selected" : "")}>
        <input type="radio" name="mode" checked={mode === "bulk"}
          onChange={() => setMode("bulk")} />
        <div>
          <b>Bulk generation</b>
          <span>Multiple employees — download the Excel input template, fill it, and upload it back.</span>
        </div>
      </label>

      <div className="actions">
        <div className="left">
          <button className="btn ghost" onClick={onBack}>Back</button>
        </div>
        <button className="btn primary"
          onClick={() => { update({ mode }); onNext(mode); }}>
          Continue
        </button>
      </div>
    </div>
  );
}
