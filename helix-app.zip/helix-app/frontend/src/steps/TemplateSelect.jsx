import React, { useState, useEffect } from "react";
import { api } from "../api.js";

export default function TemplateSelect({ ctx, update, onBack, onNext }) {
  const [region, setRegion] = useState(ctx.selection?.region || "");
  const [entity, setEntity] = useState(ctx.selection?.entity || "");
  const [category, setCategory] = useState(ctx.selection?.category || "");
  const [letter, setLetter] = useState(ctx.selection?.letter || "");
  const [opts, setOpts] = useState({ entities: [], categories: [], letters: [] });
  const [error, setError] = useState("");

  useEffect(() => {
    const params = {};
    if (region) params.region = region;
    if (entity) params.entity = entity;
    if (category) params.category = category;
    if (!region) { setOpts({ entities: [], categories: [], letters: [] }); return; }
    api.options(params).then(setOpts).catch((e) => setError(e.message));
  }, [region, entity, category]);

  const next = () => {
    if (!region || !entity || !category || !letter) {
      setError("Please choose the region, entity, letter category, and letter template.");
      return;
    }
    update({ selection: { region, entity, category, letter } });
    onNext();
  };

  const Select = ({ label, value, set, options, disabled, resetBelow }) => (
    <div className="field">
      <label>{label}</label>
      <select value={value} disabled={disabled}
        onChange={(e) => { set(e.target.value); resetBelow(); setError(""); }}>
        <option value="">Select…</option>
        {options.map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
    </div>
  );

  return (
    <div className="card">
      <h2>Choose the letter</h2>
      <p className="lede">Narrow down to the template you want to generate from.</p>
      <div className="grid">
        <Select label="Region" value={region} set={setRegion}
          options={ctx.regions}
          resetBelow={() => { setEntity(""); setCategory(""); setLetter(""); }} />
        <Select label="Entity" value={entity} set={setEntity}
          options={opts.entities} disabled={!region}
          resetBelow={() => { setCategory(""); setLetter(""); }} />
        <Select label="Letter category" value={category} set={setCategory}
          options={opts.categories} disabled={!entity}
          resetBelow={() => setLetter("")} />
        <Select label="Letter template" value={letter} set={setLetter}
          options={opts.letters} disabled={!category} resetBelow={() => {}} />
      </div>
      {error && <div className="alert error">{error}</div>}
      <div className="actions">
        <div className="left">
          <button className="btn ghost" onClick={onBack}>Back</button>
        </div>
        <button className="btn primary" onClick={next}>Continue</button>
      </div>
    </div>
  );
}
