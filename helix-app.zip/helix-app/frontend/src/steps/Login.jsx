import React, { useState } from "react";
import { api } from "../api.js";

export default function Login({ ctx, update, onNext }) {
  const [userId, setUserId] = useState(ctx.userId);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!userId.trim()) { setError("Please enter a valid User ID"); return; }
    setBusy(true); setError("");
    try {
      const res = await api.session(userId.trim());
      update({ userId: userId.trim(), regions: res.regions });
      onNext();
    } catch (e) { setError(e.message); }
    finally { setBusy(false); }
  };

  return (
    <div className="card">
      <h2>Sign in</h2>
      <p className="lede">
        Enter your User ID. HELIX uses it to locate your Nissan OneDrive HELIX
        folder with the templates repository and Workday input file.
      </p>
      <div className="grid cols-1" style={{ maxWidth: 380 }}>
        <div className="field">
          <label htmlFor="uid">User ID</label>
          <input id="uid" value={userId} autoFocus
            onChange={(e) => setUserId(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && submit()} />
          <div className="hint">Example: your OHR / network ID</div>
        </div>
      </div>
      {error && <div className="alert error">{error}</div>}
      <div className="actions">
        <button className="btn primary" onClick={submit} disabled={busy}>
          {busy ? "Loading data…" : "Continue"}
        </button>
      </div>
    </div>
  );
}
