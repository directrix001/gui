import React from "react";

export default function Welcome({ onStart }) {
  return (
    <div className="card">
      <div className="welcome">
        <div className="roundel-lg" aria-hidden="true"><span>HELIX</span></div>
        <h2>Welcome to HELIX</h2>
        <p className="lede">
          Generate employee letters — singly or in bulk — from approved Nissan
          templates, with Workday data, signatory images, and password-protected PDFs.
        </p>
        <button className="btn primary" onClick={onStart}>Let's get started</button>
      </div>
    </div>
  );
}
