import React from "react";

export default function Done({ ctx, onRestart }) {
  const r = ctx.result || {};
  const bulk = r.kind === "bulk";

  return (
    <div className="card">
      <h2>{bulk && r.errors?.length ? "Completed with errors" : "Generation complete"}</h2>

      {!bulk && (
        <>
          <p className="lede">Your letter has been generated.</p>
          <div className="alert ok">File saved to:{"\n"}{r.file}</div>
        </>
      )}

      {bulk && (
        <>
          <p className="lede">
            Letters generated successfully: <b>{r.successCount}</b>
          </p>
          {r.zips?.length > 0 && (
            <>
              <div className="alert ok">ZIP files created:</div>
              <ul className="done-list">
                {r.zips.map((z) => <li key={z}>{z}</li>)}
              </ul>
            </>
          )}
          {r.errors?.length > 0 && (
            <div className="alert error">
              {r.errors.slice(0, 10).join("\n")}
              {r.errors.length > 10 ? `\n…and ${r.errors.length - 10} more` : ""}
            </div>
          )}
        </>
      )}

      <div className="actions">
        <button className="btn primary" onClick={onRestart}>Start a new run</button>
      </div>
    </div>
  );
}
