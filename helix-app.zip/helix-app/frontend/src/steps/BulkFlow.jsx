import React, { useState, useEffect, useRef } from "react";
import { api } from "../api.js";

// ------------------------------------------- Template download / upload
export function BulkTemplateStep({ ctx, update, onBack, onNext }) {
  const [file, setFile] = useState(null);
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");
  const [busy, setBusy] = useState(false);

  const download = async () => {
    setError("");
    try { await api.downloadBulkTemplate(ctx.selection); }
    catch (e) { setError(e.message); }
  };

  const next = async () => {
    if (!file) { setError("Please upload the filled bulk template first."); return; }
    setBusy(true); setError(""); setOk("");
    try {
      // Validate columns now; missing-details check is re-run at Output step
      const res = await api.validateBulk(file, ctx.selection, true);
      update({ bulkToken: res.token, bulkFileName: file.name, bulkMissing: res.missingDetails, bulkFile: file });
      setOk(`Template validated — ${res.rowCount} employee row(s) found.`);
      onNext();
    } catch (e) { setError(e.message); }
    finally { setBusy(false); }
  };

  return (
    <div className="card">
      <h2>Bulk input</h2>
      <p className="lede">
        Download the bulk input template, fill in employee data, and upload it back.
        Column headings and order must stay exactly as downloaded.
      </p>

      <div className="grid">
        <div className="field">
          <label>Step 1 — Template</label>
          <button className="btn" onClick={download}>Download bulk template</button>
          <div className="hint">Contains Employee ID, Manager Name, Output Folder Name, Folder Password, and the letter's manual fields.</div>
        </div>
        <div className="field">
          <label>Step 2 — Filled file (.xlsx)</label>
          <input type="file" accept=".xlsx"
            onChange={(e) => { setFile(e.target.files[0] || null); setError(""); }} />
          {file && <div className="file-pill"><span className="dot" />{file.name}</div>}
        </div>
      </div>

      {error && <div className="alert error">{error}</div>}
      {ok && <div className="alert ok">{ok}</div>}

      <div className="actions">
        <div className="left"><button className="btn ghost" onClick={onBack}>Back</button></div>
        <button className="btn primary" onClick={next} disabled={busy || !file}>
          {busy ? "Validating…" : "Validate & continue"}
        </button>
      </div>
    </div>
  );
}

// ------------------------------------------------------------ Signatory
export function BulkSignatoryStep({ ctx, update, onBack, onNext }) {
  const [file, setFile] = useState(ctx.signatoryFile);
  return (
    <div className="card">
      <h2>Signatory</h2>
      <p className="lede">
        Upload one signature image to place on every letter in this run. Optional —
        without an image, the signatory placeholder is removed.
      </p>
      <div className="field" style={{ maxWidth: 420 }}>
        <label>Signature image (PNG / JPG)</label>
        <input type="file" accept=".png,.jpg,.jpeg"
          onChange={(e) => setFile(e.target.files[0] || null)} />
        {file && <div className="file-pill"><span className="dot" />{file.name}</div>}
      </div>
      <div className="actions">
        <div className="left"><button className="btn ghost" onClick={onBack}>Back</button></div>
        <button className="btn primary"
          onClick={() => { update({ signatoryFile: file }); onNext(); }}>
          Continue
        </button>
      </div>
    </div>
  );
}

// ------------------------------------------------------- Output options
export function BulkOutputStep({ ctx, update, onBack, onNext }) {
  const [format, setFormat] = useState(ctx.bulkIsPdf ? "pdf" : "word");
  const [pwdEnabled, setPwdEnabled] = useState(true);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const next = async () => {
    const isPdf = format === "pdf";
    setBusy(true); setError("");
    try {
      // Re-validate to get accurate missing-details list for the chosen format
      const res = await api.validateBulk(ctx.bulkFile, ctx.selection, isPdf);
      update({ bulkToken: res.token, bulkIsPdf: isPdf, bulkPwdEnabled: isPdf && pwdEnabled, bulkMissing: res.missingDetails });
      const needsUncat = isPdf && res.missingDetails.length > 0;
      onNext(needsUncat);
    } catch (e) { setError(e.message); }
    finally { setBusy(false); }
  };

  return (
    <div className="card">
      <h2>Bulk output</h2>
      <p className="lede">Choose the file format for the whole run.</p>

      <label className={"choice" + (format === "pdf" ? " selected" : "")}>
        <input type="radio" checked={format === "pdf"} onChange={() => setFormat("pdf")} />
        <div><b>PDF</b><span>Letters are zipped per output folder under Entity / Manager.</span></div>
      </label>
      <label className={"choice" + (format === "word" ? " selected" : "")}>
        <input type="radio" checked={format === "word"} onChange={() => setFormat("word")} />
        <div><b>Word (.docx)</b><span>Editable documents, no passwords.</span></div>
      </label>

      {format === "pdf" && (
        <div style={{ marginTop: 20 }}>
          <label className={"choice" + (pwdEnabled ? " selected" : "")}>
            <input type="radio" checked={pwdEnabled} onChange={() => setPwdEnabled(true)} />
            <div>
              <b>Password-protected PDFs</b>
              <span>Uses the Folder Password column; blanks fall back to the system password (forename + birth year).</span>
            </div>
          </label>
          <label className={"choice" + (!pwdEnabled ? " selected" : "")}>
            <input type="radio" checked={!pwdEnabled} onChange={() => setPwdEnabled(false)} />
            <div><b>PDFs without a password</b></div>
          </label>
        </div>
      )}

      {error && <div className="alert error">{error}</div>}
      <div className="actions">
        <div className="left">
          <button className="btn ghost" onClick={onBack} disabled={busy}>Back</button>
        </div>
        <button className="btn primary" onClick={next} disabled={busy}>
          {busy ? "Checking…" : "Continue"}
        </button>
      </div>
    </div>
  );
}

// ------------------------------------- Uncategorized details (PDF only)
export function UncategorizedStep({ ctx, update, onBack, onNext }) {
  const [selected, setSelected] = useState(null);
  const [folderName, setFolderName] = useState("");
  const [password, setPassword] = useState("");
  const [overrides, setOverrides] = useState(ctx.overrides || {});
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");

  const pick = (emp) => {
    setSelected(emp);
    const saved = overrides[emp.empId] || {};
    setFolderName(saved.folderName || "");
    setPassword(saved.password || "");
    setOk(""); setError("");
  };

  const save = () => {
    if (!selected) { setError("Select an employee from the list first."); return; }
    if (!folderName.trim() || !password.trim()) {
      setError("Enter both the output folder name and the PDF password."); return;
    }
    const next = { ...overrides, [selected.empId]: { folderName: folderName.trim(), password: password.trim() } };
    setOverrides(next);
    setOk(`Details saved for ${selected.name}.`);
    setError(""); setFolderName(""); setPassword(""); setSelected(null);
  };

  const proceed = (skip) => {
    if (!skip) {
      const missing = ctx.bulkMissing.filter((e) => !overrides[e.empId]);
      if (missing.length) {
        setError("Please fill details for:\n" + missing.map((m) => `${m.empId} – ${m.name}`).join("\n"));
        return;
      }
    }
    update({ overrides: skip ? {} : overrides });
    onNext();
  };

  return (
    <div className="card wide">
      <h2>Missing output details</h2>
      <p className="lede">
        Some employees are missing an output folder name or PDF password in the
        uploaded template. Add them here — or skip to use the "Uncategorized"
        folder and the system password.
      </p>

      <div className="uncat">
        <div className="panel">
          <h3>How this works</h3>
          <ol>
            <li>Select an employee from the list</li>
            <li>Enter the output folder name</li>
            <li>Enter the PDF password</li>
            <li>Save, then repeat for each employee</li>
            <li>Continue when every employee is saved</li>
          </ol>
          <p style={{ marginTop: 12, fontSize: 13, color: "var(--graphite)" }}>
            If you skip: files go to an <b>Uncategorized</b> ZIP and each PDF uses
            the system password (first 4 letters of forename + birth year).
          </p>
        </div>

        <div className="panel">
          <h3>Employees ({ctx.bulkMissing.length})</h3>
          <div className="emp-list">
            {ctx.bulkMissing.map((e) => (
              <div key={e.empId}
                className={"emp-item" + (selected?.empId === e.empId ? " selected" : "")}
                onClick={() => pick(e)}>
                <span>{e.empId} — {e.name}</span>
                {overrides[e.empId] && <span className="tick">✓</span>}
              </div>
            ))}
          </div>
        </div>

        <div className="panel">
          <h3>Update details</h3>
          <div className="field" style={{ marginBottom: 14 }}>
            <label>Output folder name</label>
            <input value={folderName} onChange={(e) => setFolderName(e.target.value)} />
          </div>
          <div className="field" style={{ marginBottom: 14 }}>
            <label>PDF password</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          <button className="btn" onClick={save}>Save employee details</button>
        </div>
      </div>

      {error && <div className="alert error">{error}</div>}
      {ok && <div className="alert ok">{ok}</div>}

      <div className="actions">
        <div className="left">
          <button className="btn ghost" onClick={onBack}>Back</button>
          <button className="btn" onClick={() => proceed(true)}>Skip</button>
        </div>
        <button className="btn primary" onClick={() => proceed(false)}>Continue</button>
      </div>
    </div>
  );
}

// ------------------------------------------------------------- Progress
export function BulkProgressStep({ ctx, onDone }) {
  const [job, setJob] = useState({ percent: 0, message: "Starting…" });
  const [error, setError] = useState("");
  const started = useRef(false);

  useEffect(() => {
    if (started.current) return;
    started.current = true;
    let timer;
    (async () => {
      try {
        const { jobId } = await api.generateBulk(
          {
            selection: ctx.selection,
            fileToken: ctx.bulkToken,
            isPdf: ctx.bulkIsPdf,
            pdfPasswordEnabled: !!ctx.bulkPwdEnabled,
            overrides: ctx.overrides || {},
          },
          ctx.signatoryFile
        );
        timer = setInterval(async () => {
          const j = await api.bulkProgress(jobId);
          setJob(j);
          if (j.done) {
            clearInterval(timer);
            if (j.status === "error") setError(j.message);
            else onDone({ kind: "bulk", ...j });
          }
        }, 800);
      } catch (e) { setError(e.message); }
    })();
    return () => timer && clearInterval(timer);
  }, []);

  return (
    <div className="card">
      <h2>Generating bulk letters</h2>
      <p className="lede">Please wait until you get confirmation — do not close this window.</p>
      <div className="progress-wrap">
        <div className="progress-track">
          <div className="progress-bar" style={{ width: `${job.percent}%` }} />
        </div>
        <div className="progress-label">
          <span>{job.message}</span><span>{job.percent}%</span>
        </div>
      </div>
      {error && <div className="alert error">{error}</div>}
    </div>
  );
}
