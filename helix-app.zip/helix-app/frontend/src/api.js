async function handle(res) {
  if (!res.ok) {
    let msg = `Request failed (${res.status})`;
    try { msg = (await res.json()).error || msg; } catch (_) {}
    throw new Error(msg);
  }
  return res.json();
}

export const api = {
  session: (userId) =>
    fetch("/api/session", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId }),
    }).then(handle),

  options: (params) =>
    fetch("/api/options?" + new URLSearchParams(params)).then(handle),

  employee: (id) => fetch(`/api/employee/${encodeURIComponent(id)}`).then(handle),

  singlePrefill: (selection, empId) =>
    fetch("/api/single/prefill", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ selection, empId }),
    }).then(handle),

  generateSingle: (payload, signatoryFile) => {
    const fd = new FormData();
    fd.append("payload", JSON.stringify(payload));
    if (signatoryFile) fd.append("signatory", signatoryFile);
    return fetch("/api/generate/single", { method: "POST", body: fd }).then(handle);
  },

  downloadBulkTemplate: async (selection) => {
    const res = await fetch("/api/bulk/template", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(selection),
    });
    if (!res.ok) {
      let msg = "Download failed";
      try { msg = (await res.json()).error || msg; } catch (_) {}
      throw new Error(msg);
    }
    const blob = await res.blob();
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "HELIX_Bulk_Input_Template.xlsx";
    a.click();
    URL.revokeObjectURL(a.href);
  },

  validateBulk: (file, selection, isPdf) => {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("selection", JSON.stringify(selection));
    fd.append("isPdf", String(isPdf));
    return fetch("/api/bulk/validate", { method: "POST", body: fd }).then(handle);
  },

  generateBulk: (payload, signatoryFile) => {
    const fd = new FormData();
    fd.append("payload", JSON.stringify(payload));
    if (signatoryFile) fd.append("signatory", signatoryFile);
    return fetch("/api/bulk/generate", { method: "POST", body: fd }).then(handle);
  },

  bulkProgress: (jobId) => fetch(`/api/bulk/progress/${jobId}`).then(handle),
};
